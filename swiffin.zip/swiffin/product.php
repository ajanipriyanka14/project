
	<?php

	session_start();

	include("config.php");


	/* =====================================================
	   GET ALL CAKES
	===================================================== */

	$sql = "SELECT * FROM cake ORDER BY id DESC";	

	$result = mysqli_query($conn, $sql);

	if (!$result) {

		die(
			"Cake Database Error: " .
			mysqli_error($conn)
		);

	}

	?>

	<!DOCTYPE html>

	<html lang="en">

	<head>

	<meta charset="utf-8">

	<title>
	Products | SWIFFIN CAKE SHOP
	</title>

	<meta
		name="viewport"
		content="width=device-width, initial-scale=1.0"
	>


	<!-- FAVICON -->

	<link
	href="img/favicon.ico"
	rel="icon"
	>


	<!-- GOOGLE FONTS -->

	<link
	rel="preconnect"
	href="https://fonts.googleapis.com"
	>

	<link
	rel="preconnect"
	href="https://fonts.gstatic.com"
	crossorigin
	>

	<link
	href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Oswald:wght@500;600;700&family=Pacifico&display=swap"
	rel="stylesheet"
	>


	<!-- FONT AWESOME -->

	<link
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
	rel="stylesheet"
	>


	<!-- BOOTSTRAP ICONS -->

	<link
	href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
	rel="stylesheet"
	>


	<!-- BOOTSTRAP -->

	<link
	href="css/bootstrap.min.css"
	rel="stylesheet"
	>


	<!-- TEMPLATE CSS -->

	<link
	href="css/style.css"
	rel="stylesheet"
	>


	<style>

	*{
		box-sizing:border-box;
	}


	body{

		margin:0;

		padding:0;

		background:#000;

		color:#fff;

		font-family:Arial, Helvetica, sans-serif;

	}


	/* =====================================================
	   TOPBAR
	===================================================== */

	.container-fluid{

		margin-top:0 !important;

		padding:0 !important;

	}


	/* =====================================================
	   NAVBAR
	===================================================== */

	.navbar{

		background:#fff !important;

	}


	.navbar .nav-link{

		font-weight:bold;

	}


	.navbar .btn-primary{

		background:#E88F2A !important;

		border-color:#E88F2A !important;

		color:#fff !important;

		font-weight:bold;

	}


	.navbar .btn-primary:hover{

		background:#d67d18 !important;

		border-color:#d67d18 !important;

	}


	/* =====================================================
	   HERO
	===================================================== */

	.hero{

		background:#111;

		padding:90px 0;

	}


	.hero h5{

		color:#E88F2A !important;

	}


	/* =====================================================
	   PRODUCT CARD
	===================================================== */

	.product-card{

		background:#1b1b1b;

		border-radius:20px;

		overflow:hidden;

		transition:.4s;

		color:#fff;

		border:1px solid #333 !important;

	}


	.product-card:hover{

		transform:translateY(-10px);

		box-shadow:
		0 15px 35px rgba(232,143,42,.35);

	}


	/* =====================================================
	   IMAGE
	===================================================== */

	.product-card img{

		width:100%;

		height:260px;

		object-fit:cover;

	}


	/* =====================================================
	   CARD BODY
	===================================================== */

	.product-card .card-body{

		padding:25px;

	}


	.product-card h4{

		color:#E88F2A;

		font-weight:bold;

	}


	.product-card p{

		color:#ddd;

	}


	/* =====================================================
	   NORMAL PRICE
	===================================================== */

	.price{

		color:#E88F2A;

		font-size:28px;

		font-weight:bold;

	}


	/* =====================================================
	   OLD PRICE
	===================================================== */

	.old-price{

		color:#888;

		font-size:19px;

		text-decoration:line-through;

		margin-right:8px;

	}


	/* =====================================================
	   OFFER BADGE
	===================================================== */

	.offer-badge{

		display:inline-block;

		background:#dc3545;

		color:#fff;

		padding:7px 14px;

		border-radius:20px;

		font-size:14px;

		font-weight:bold;

		margin-bottom:10px;

	}


	/* =====================================================
	   OFFER BOX
	===================================================== */

	.offer-box{

		background:#351b08;

		border:1px solid #E88F2A;

		border-radius:12px;

		padding:12px;

		margin-top:12px;

		margin-bottom:12px;

	}


	.offer-title{

		color:#E88F2A;

		font-size:17px;

		font-weight:bold;

	}


	.offer-description{

		color:#ddd;

		font-size:14px;

		margin-top:5px;

	}


	.offer-date{

		color:#aaa;

		font-size:12px;

		margin-top:5px;

	}


	/* =====================================================
	   ADD TO CART
	===================================================== */

	.btn-order{

		background:#E88F2A;

		color:#fff;

		width:100%;

		border-radius:30px;

		font-weight:bold;

		border:none;

		padding:12px;

	}


	.btn-order:hover{

		background:#d67d18;

		color:#fff;

	}


	/* =====================================================
	   OUT OF STOCK
	===================================================== */

	.out-stock{

		background:#dc3545;

		color:#fff;

		width:100%;

		border-radius:30px;

		font-weight:bold;

		padding:12px;

		border:none;

	}


	/* =====================================================
	   MOBILE
	===================================================== */

	@media(max-width:600px){

		.hero{

			padding:60px 0;

		}


		.hero h1{

			font-size:32px;

		}


		.product-card img{

			height:230px;

		}

	}

	</style>

	</head>


	<body>


	<!-- =====================================================
		 TOPBAR
	===================================================== -->

	<div class="container-fluid bg-white px-5">

	<div class="row align-items-center">


	<!-- WELCOME -->

	<div class="col-lg-2">

	<h5 class="m-1 fw-bold">

	<?php

	if(isset($_SESSION['name'])){

		echo "Welcome " .
			 htmlspecialchars($_SESSION['name']);

	}
	else{

		echo "Welcome";

	}

	?>

	</h5>

	</div>


	<!-- SWIFFIN LOGO -->

	<div class="col-lg-5 text-center py-2">

	<a
	href="index1.php"
	class="navbar-brand d-flex justify-content-center align-items-center"
	>

	<img
	src="img/logo.png"
	alt="SWIFFIN Logo"
	width="60"
	height="60"
	>

	<h1 class="m-0 ms-2 text-uppercase">

	<span style="color:#ff9800;">

	SWIFFIN

	</span>

	</h1>

	</a>

	</div>


	<!-- CALL US -->

	<div class="col-lg-4 text-end">

	<div class="d-inline-flex align-items-center">

	<i
	class="bi bi-phone-vibrate fs-1 me-3"
	style="color:#E88F2A;"
	></i>

	<div class="text-start">

	<h6 class="text-uppercase mb-1">

	CALL US

	</h6>

	<span>

	+91 9876543210

	</span>

	</div>

	</div>

	</div>


	</div>

	</div>


	<!-- =====================================================
		 NAVBAR
	===================================================== -->

	<nav
	class="navbar navbar-expand-lg navbar-light shadow-sm sticky-top py-3"
	>

	<div class="container">


	<button
	class="navbar-toggler"
	type="button"
	data-bs-toggle="collapse"
	data-bs-target="#navbar"
	>

	<span class="navbar-toggler-icon"></span>

	</button>


	<div
	class="collapse navbar-collapse"
	id="navbar"
	>

	<ul class="navbar-nav ms-auto">


	<li class="nav-item">

	<a
	href="index1.php"
	class="nav-link"
	>

	Home

	</a>

	</li>


	<li class="nav-item">

	<a
	href="about.php"
	class="nav-link"
	>

	About

	</a>

	</li>


	<li class="nav-item">

	<a
	href="product.php"
	class="nav-link active"
	>

	Cakes

	</a>

	</li>


	<li class="nav-item">

	<a
	href="gallery.php"
	class="nav-link"
	>

	Gallery

	</a>

	</li>


	<li class="nav-item">

	<a
	href="contact.php"
	class="nav-link"
	>

	Contact

	</a>

	</li>


	<li class="nav-item">

	<a
	href="login.php"
	class="btn btn-primary rounded-circle ms-3 px-4"
	>

	Login

	</a>

	</li>


	<li class="nav-item">

	<a
	href="register.php"
	class="btn btn-primary rounded-circle ms-3 px-4"
	>

	Register

	</a>

	</li>


	<li class="nav-item">

	<a
	href="logout.php"
	class="btn btn-primary rounded-circle ms-3 px-4"
	>

	Logout

	</a>

	</li>


	</ul>

	</div>

	</div>

	</nav>


	<!-- =====================================================
		 HERO
	===================================================== -->

	<section class="hero">

	<div class="container text-center">

	<h5 class="fw-bold">

	OUR PRODUCTS

	</h5>


	<h1 class="display-4 text-white fw-bold">

	Fresh & Delicious Cakes

	</h1>


	<p class="text-light">

	Choose your favourite cake for every celebration.

	</p>

	</div>

	</section>


	<!-- =====================================================
		 PRODUCTS
	===================================================== -->

	<section class="py-5">

	<div class="container">

	<div class="row">


	<?php

	while($row = mysqli_fetch_assoc($result)){

		/* ================================================
		   CAKE DATA
		================================================ */

		$cake_id = intval($row['id']);

		$cake_price = floatval($row['price']);


		/* ================================================
		   DEFAULT OFFER
		================================================ */

		$offer = false;


		/* ================================================
		   TODAY DATE
		================================================ */

		$today = date("Y-m-d");


		/* ================================================
		   GET OFFER ONLY FOR THIS CAKE
		================================================ */

		$offer_sql = "

			SELECT *

			FROM offers

			WHERE cake_id = '$cake_id'

			AND status = 'Active'

			AND start_date <= '$today'

			AND end_date >= '$today'

			ORDER BY id DESC

			LIMIT 1

		";


		$offer_query = mysqli_query(
			$conn,
			$offer_sql
		);


		if(
			$offer_query &&
			mysqli_num_rows($offer_query) > 0
		){

			$offer =
				mysqli_fetch_assoc(
					$offer_query
				);

		}


		/* ================================================
		   CALCULATE DISCOUNT
		================================================ */

		$final_price = $cake_price;

		$discount = 0;


		if($offer){

			$discount =
				intval(
					$offer['discount']
				);


			$discount_amount =
				($cake_price * $discount) / 100;


			$final_price =
				$cake_price -
				$discount_amount;

		}

	?>


	<div class="col-lg-4 col-md-6 mb-4">


	<div class="card product-card h-100">


	<!-- CAKE IMAGE -->

	<img
	src="img/<?php echo htmlspecialchars($row['image']); ?>"
	class="card-img-top"
	alt="<?php echo htmlspecialchars($row['cake_name']); ?>"
	>


	<div class="card-body text-center">


	<!-- CAKE NAME -->

	<h4>

	<?php

	echo htmlspecialchars(
		$row['cake_name']
	);

	?>

	</h4>


	<!-- CATEGORY -->

	<p>

	<b>Category :</b>

	<?php

	echo htmlspecialchars(
		$row['category']
	);

	?>

	</p>


	<!-- FLAVOUR -->

	<p>

	<b>Flavour :</b>

	<?php

	echo htmlspecialchars(
		$row['flavour']
	);

	?>

	</p>


	<!-- WEIGHT -->

	<p>

	<b>Weight :</b>

	<?php

	echo htmlspecialchars(
		$row['weight']
	);

	?>

	</p>


	<!-- DESCRIPTION -->

	<p>

	<?php

	echo htmlspecialchars(
		$row['description']
	);

	?>

	</p>


	<!-- STOCK -->

	<p>

	<b>Stock :</b>

	<span class="text-warning fw-bold">

	<?php

	echo intval(
		$row['stock']
	);

	?>

	</span>

	</p>


	<!-- STATUS -->

	<p>

	<b>Status :</b>

	<?php

	if(
		$row['status'] == "Available" &&
		intval($row['stock']) > 0
	){

		echo "
		<span class='text-success fw-bold'>
		Available
		</span>
		";

	}
	else{

		echo "
		<span class='text-danger fw-bold'>
		Out of Stock
		</span>
		";

	}

	?>

	</p>


	<!-- =================================================
		 OFFER
	================================================= -->

	<?php

	if($offer){

	?>


	<div class="offer-badge">

	🔥

	<?php

	echo intval(
		$offer['discount']
	);

	?>% OFF

	</div>


	<div class="offer-box">


	<div class="offer-title">

	<?php

	echo htmlspecialchars(
		$offer['offer_title']
	);

	?>

	</div>


	<div class="offer-description">

	<?php

	echo htmlspecialchars(
		$offer['description']
	);

	?>

	</div>


	<div class="offer-date">

	Valid:

	<?php

	echo date(
		"d-m-Y",
		strtotime($offer['start_date'])
	);

	?>

	&nbsp; to &nbsp;

	<?php

	echo date(
		"d-m-Y",
		strtotime($offer['end_date'])
	);

	?>

	</div>


	</div>


	<!-- PRICE WITH DISCOUNT -->

	<div class="price">

	<span class="old-price">

	₹<?php

	echo number_format(
		$cake_price,
		2
	);

	?>

	</span>


	₹<?php

	echo number_format(
		$final_price,
		2
	);

	?>

	</div>


	<?php

	}
	else{

	?>


	<!-- NORMAL PRICE -->

	<div class="price">

	₹<?php

	echo number_format(
		$cake_price,
		2
	);

	?>

	</div>


	<?php

	}

	?>


	<!-- =================================================
		 ADD TO CART
	================================================= -->

	<?php

	if(
		intval($row['stock']) > 0 &&
		$row['status'] == "Available"
	){

	?>


	<form
	method="POST"
	action="cart_insert.php"
	>


	<input
	type="hidden"
	name="cake_id"
	value="<?php echo $cake_id; ?>"
	>


	<input
	type="hidden"
	name="quantity"
	value="1"
	>


	<button
	type="submit"
	name="add_to_cart"
	class="btn btn-order mt-3"
	>

	<i class="fas fa-shopping-cart"></i>

	&nbsp; Add To Cart

	</button>


	</form>


	<?php

	}
	else{

	?>


	<button
	class="out-stock mt-3"
	disabled
	>

	Out of Stock

	</button>


	<?php

	}

	?>


	</div>

	</div>

	</div>


	<?php

	}

	?>


	</div>

	</div>

	</section>


	<script
	src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
	></script>


	</body>

	</html>

