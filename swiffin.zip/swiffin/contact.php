
<?php

session_start();

include("config.php");


/* =====================================================
   SEND ENQUIRY
===================================================== */

if (isset($_POST['send_enquiry'])) {

    $name = mysqli_real_escape_string(
        $conn,
        trim($_POST['name'])
    );

    $email = mysqli_real_escape_string(
        $conn,
        trim($_POST['email'])
    );

    $mobile = mysqli_real_escape_string(
        $conn,
        trim($_POST['mobile'])
    );

    $subject = mysqli_real_escape_string(
        $conn,
        trim($_POST['subject'])
    );

    $message = mysqli_real_escape_string(
        $conn,
        trim($_POST['message'])
    );


    $sql = "INSERT INTO enquiry
    (
        name,
        email,
        mobile,
        subject,
        message,
        status,
        enquiry_date
    )
    VALUES
    (
        '$name',
        '$email',
        '$mobile',
        '$subject',
        '$message',
        'Pending',
        NOW()
    )";


    if (mysqli_query($conn, $sql)) {

        echo "<script>
                alert('Enquiry Sent Successfully');
                window.location='contact.php';
              </script>";

        exit();

    } else {

        die(
            "Enquiry Insert Error: " .
            mysqli_error($conn)
        );

    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="utf-8">

<title>
Contact | SWIFFIN CAKE SHOP
</title>

<meta
content="width=device-width, initial-scale=1.0"
name="viewport"
>

<meta
content="Swiffin Cake Shop Contact"
name="keywords"
>

<meta
content="Contact Swiffin Cake Shop"
name="description"
>


<!-- FAVICON -->

<link
href="img/favicon.ico"
rel="icon"
>


<!-- GOOGLE FONTS -->

<link
rel="preconnect"
href="https://fonts.googleapis.com"
>

<link
rel="preconnect"
href="https://fonts.googleapis.com"
crossorigin
>

<link
href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Oswald:wght@500;600;700&family=Pacifico&display=swap"
rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
rel="stylesheet"
>


<!-- BOOTSTRAP ICONS -->

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
rel="stylesheet"
>


<!-- LIBRARY -->

<link
href="lib/owlcarousel/assets/owl.carousel.min.css"
rel="stylesheet"
>


<!-- BOOTSTRAP -->

<link
href="css/bootstrap.min.css"
rel="stylesheet"
>


<!-- TEMPLATE CSS -->

<link
href="css/style.css"
rel="stylesheet"
>


<style>

/* =====================================================
   GENERAL
===================================================== */

*{
    box-sizing:border-box;
}


body{

    margin:0;

    padding:0;

    background:#000;

    color:#fff;

}


/* =====================================================
   TOPBAR
===================================================== */

.container-fluid{

    margin-top:0 !important;

    padding-top:0 !important;

}


.container-fluid.px-5{

    background:#fff;

}


/* =====================================================
   NAVBAR
===================================================== */

.navbar{

    background:#fff !important;

}


.navbar .nav-link{

    color:#222 !important;

    font-weight:bold;

}


.navbar .nav-link:hover{

    color:#E88F2A !important;

}


.navbar .nav-link.active{

    color:#E88F2A !important;

}


.btn-primary{

    background:#E88F2A !important;

    border-color:#E88F2A !important;

    color:#fff !important;

    font-weight:bold;

}


.btn-primary:hover{

    background:#d67d18 !important;

    border-color:#d67d18 !important;

}


/* =====================================================
   CONTACT HERO
===================================================== */

.contact-hero{

    min-height:420px;

    background:
    linear-gradient(
        rgba(0,0,0,.65),
        rgba(0,0,0,.65)
    ),
    url("img/ca.jpg");

    background-size:cover;

    background-position:center;

}


.contact-hero h5{

    color:#E88F2A !important;

}


.contact-hero p{

    color:#eee;

    font-size:18px;

}


/* =====================================================
   CONTACT INFO
===================================================== */

.contact-info{

    background:#000;

}


.contact-box{

    background:#111;

    border:1px solid #333;

    border-radius:18px;

    padding:30px 20px;

    height:100%;

    transition:.3s;

}


.contact-box:hover{

    border-color:#E88F2A;

    transform:translateY(-5px);

    box-shadow:
    0 10px 25px
    rgba(232,143,42,.20);

}


.contact-box i{

    color:#E88F2A;

    font-size:40px;

    margin-bottom:15px;

}


.contact-box h4{

    font-weight:bold;

}


.contact-box p{

    color:#ccc;

    margin:0;

}


/* =====================================================
   CONTACT FORM SECTION
===================================================== */

.contact-section{

    background:#000;

}


.contact-form{

    background:#111;

    border:1px solid #333;

    border-radius:20px;

    padding:35px;

    box-shadow:
    0 0 25px
    rgba(232,143,42,.10);

}


.contact-form h2{

    color:#E88F2A !important;

    font-weight:bold;

}


/* =====================================================
   FORM
===================================================== */

.contact-form .form-control{

    background:#000 !important;

    border:1px solid #444 !important;

    color:#fff !important;

    padding:13px 15px;

}


.contact-form .form-control:focus{

    border-color:#E88F2A !important;

    box-shadow:
    0 0 8px
    rgba(232,143,42,.25) !important;

}


.contact-form .form-control::placeholder{

    color:#888;

}


/* =====================================================
   SEND BUTTON
===================================================== */

.send-btn{

    background:#E88F2A;

    color:#fff;

    border:none;

    border-radius:30px;

    padding:13px 30px;

    font-weight:bold;

}


.send-btn:hover{

    background:#d67d18;

    color:#fff;

}


/* =====================================================
   IMAGE
===================================================== */

.contact-image{

    padding:20px;

}


.contact-image img{

    width:100%;

    max-height:380px;

    object-fit:cover;

    border-radius:20px;

    border:2px solid #333;

}


.contact-image h3{

    color:#E88F2A !important;

    font-weight:bold;

}


/* =====================================================
   MAP
===================================================== */

.map-section{

    background:#000;

}


.map-section iframe{

    width:100%;

    height:400px;

    border:0;

    border-radius:15px;

}


/* =====================================================
   MOBILE
===================================================== */

@media(max-width:768px){

    .contact-hero{

        min-height:350px;

    }


    .contact-hero h1{

        font-size:40px;

    }


    .contact-form{

        padding:25px 18px;

    }

}

</style>

</head>


<body>


<!-- =====================================================
     TOPBAR
===================================================== -->

<div class="container-fluid px-5">

<div class="row align-items-center">


<!-- WELCOME -->

<div class="col-lg-2">

<h5 class="m-1 fw-bold">

<?php

if(isset($_SESSION['name'])){

    echo "Welcome " .
         htmlspecialchars(
             $_SESSION['name']
         );

}
else{

    echo "Welcome";

}

?>

</h5>

</div>


<!-- SWIFFIN LOGO -->

<div class="col-lg-5 text-center py-2">

<a
href="index1.php"
class="navbar-brand d-flex justify-content-center align-items-center"
>

<img
src="img/logo.png"
alt="SWIFFIN Logo"
width="60"
height="60"
>

<h1 class="m-0 ms-2 text-uppercase">

<span style="color:#ff9800;">

SWIFFIN

</span>

</h1>

</a>

</div>


<!-- CALL US -->

<div class="col-lg-4 text-end">

<div class="d-inline-flex align-items-center">

<i
class="bi bi-phone-vibrate fs-1 me-3"
style="color:#E88F2A;"
></i>

<div class="text-start">

<h6 class="text-uppercase mb-1">

CALL US

</h6>

<span>

+91 9876543210

</span>

</div>

</div>

</div>


</div>

</div>


<!-- =====================================================
     NAVBAR
===================================================== -->

<nav
class="navbar navbar-expand-lg navbar-light shadow-sm sticky-top py-3"
>

<div class="container">


<button
class="navbar-toggler"
type="button"
data-bs-toggle="collapse"
data-bs-target="#navbar"
>

<span class="navbar-toggler-icon"></span>

</button>


<div
class="collapse navbar-collapse"
id="navbar"
>

<ul class="navbar-nav ms-auto">


<li class="nav-item">

<a
href="index1.php"
class="nav-link"
>

Home

</a>

</li>


<li class="nav-item">

<a
href="about.php"
class="nav-link"
>

About

</a>

</li>


<li class="nav-item">

<a
href="product.php"
class="nav-link"
>

Cakes

</a>

</li>


<li class="nav-item">

<a
href="gallery.php"
class="nav-link"
>

Gallery

</a>

</li>


<li class="nav-item">

<a
href="contact.php"
class="nav-link active"
>

Contact

</a>

</li>


<li class="nav-item">

<a
href="login.php"
class="btn btn-primary rounded-circle ms-3 px-4 fw-bold"
>

Login

</a>

</li>


<li class="nav-item">

<a
href="register.php"
class="btn btn-primary rounded-circle ms-3 px-4 fw-bold"
>

Register

</a>

</li>


<li class="nav-item">

<a
href="logout.php"
class="btn btn-primary rounded-circle ms-3 px-4 fw-bold"
>

Logout

</a>

</li>


</ul>

</div>

</div>

</nav>


<!-- =====================================================
     HERO
===================================================== -->

<section
class="contact-hero d-flex align-items-center"
>

<div class="container text-center text-white">

<h5 class="fw-bold">

CONTACT US

</h5>


<b class="display-3  fw-bold">

Get In Touch With Swiffin

</b>


<p class="lead">

We'd love to hear from you.
Contact us for custom cakes,
orders, or any questions.

</p>

</div>

</section>


<!-- =====================================================
     CONTACT INFO
===================================================== -->

<section class="contact-info py-5">

<div class="container">

<div class="row g-4">


<!-- ADDRESS -->

<div class="col-lg-4">

<div class="contact-box text-center">

<i class="fas fa-map-marker-alt"></i>

<h4 style="color:#fff !important;">OUR ADDRESS</h4>

<p>

Swiffin Cake Shop<br>
Amreli, Gujarat

</p>

</div>

</div>


<!-- PHONE -->

<div class="col-lg-4">

<div class="contact-box text-center">

<i class="fas fa-phone"></i>

<h4>

<h4 style="color:#fff !important;">CALL US</h4>

</h4>

<p>

+91 98765 43210<br>
+91 98765 43211

</p>

</div>

</div>


<!-- EMAIL -->

<div class="col-lg-4">

<div class="contact-box text-center">

<i class="fas fa-envelope"></i>

<h4>

<h4 style="color:#fff !important;">EMAIL</h4>

</h4>

<p>

swiffin10@gmail.com<br>


</p>

</div>

</div>


</div>

</div>

</section>


<!-- =====================================================
     CONTACT FORM
===================================================== -->

<section class="contact-section py-5">

<div class="container">

<div class="row align-items-center">


<!-- FORM -->

<div class="col-lg-7">

<div class="contact-form">


<h2 class="mb-4">

Send Us A Message

</h2>


<form
method="POST"
action="contact.php"
>


<!-- NAME + EMAIL -->

<div class="row">


<div class="col-md-6 mb-3">

<input
type="text"
name="name"
class="form-control"
placeholder="Your Name"
required
>

</div>


<div class="col-md-6 mb-3">

<input
type="email"
name="email"
class="form-control"
placeholder="Your Email"
required
>

</div>


</div>


<!-- MOBILE -->

<div class="mb-3">

<input
type="text"
name="mobile"
class="form-control"
placeholder="Your Mobile Number"
maxlength="15"
required
>

</div>


<!-- SUBJECT -->

<div class="mb-3">

<input
type="text"
name="subject"
class="form-control"
placeholder="Subject"
required
>

</div>


<!-- MESSAGE -->

<div class="mb-3">

<textarea
name="message"
class="form-control"
rows="6"
placeholder="Write Your Message"
required
></textarea>

</div>


<!-- SEND -->

<button
type="submit"
name="send_enquiry"
class="send-btn"
>

<i class="fas fa-paper-plane"></i>

&nbsp; Send Message

</button>


</form>


</div>

</div>


<!-- RIGHT SIDE -->

<div class="col-lg-5">

<div class="contact-image text-center">


<img
src="img/ca.jpg"
class="img-fluid"
alt="Cake"
>


<h3 class="mt-4">

Fresh Cakes Every Day

</h3>


<p class="text-light">

We bake happiness for birthdays,
anniversaries, weddings and every
special celebration.

</p>


</div>

</div>


</div>

</div>

</section>


<!-- =====================================================
     MAP
===================================================== -->

<section class="map-section py-5">

<div class="container">


<div class="text-center mb-4">

<h2 class="text-white">

Find Us On Map

</h2>

</div>


<iframe
src="https://www.google.com/maps?q=Amreli,Gujarat&output=embed"
loading="lazy"
>
</iframe>


</div>

</section>


<!-- =====================================================
     JAVASCRIPT
===================================================== -->

<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>


</body>

</html>

