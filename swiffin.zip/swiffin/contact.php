<?php

session_start();

include("config.php");


/* =====================================================
   CUSTOMER LOGIN SESSION
===================================================== */

$customer_logged_in = false;
$customer_name = "";
$customer_email = "";

if (
    isset($_SESSION['customer']) &&
    $_SESSION['customer'] === true
) {

    $customer_logged_in = true;

    $customer_name =
        $_SESSION['customer_name'] ?? "";

    $customer_email =
        $_SESSION['customer_email'] ?? "";
}


/* =====================================================
   DYNAMIC PARENT CATEGORIES
===================================================== */

$parent_categories = [];

$cat_sql = "
    SELECT id, category_name, parent_id, status
    FROM category
    WHERE parent_id = 0
    AND status = 'Active'
    ORDER BY category_name ASC
";

$cat_result = mysqli_query($conn, $cat_sql);

if ($cat_result) {

    while ($cat = mysqli_fetch_assoc($cat_result)) {

        $parent_categories[] = $cat;

    }

}


/* =====================================================
   GET SUB CATEGORIES
===================================================== */

function getSubCategories($conn, $parent_id)
{

    $sub_categories = [];

    $parent_id = intval($parent_id);

    $sql = "
        SELECT id, category_name, parent_id, status
        FROM category
        WHERE parent_id = $parent_id
        AND status = 'Active'
        ORDER BY category_name ASC
    ";

    $result = mysqli_query($conn, $sql);

    if ($result) {

        while ($row = mysqli_fetch_assoc($result)) {

            $sub_categories[] = $row;

        }

    }

    return $sub_categories;
}


/* =====================================================
   SEND ENQUIRY
===================================================== */

if (isset($_POST['send_enquiry'])) {

    $name = mysqli_real_escape_string(
        $conn,
        trim($_POST['name'])
    );

    $email = mysqli_real_escape_string(
        $conn,
        trim($_POST['email'])
    );

    $mobile = mysqli_real_escape_string(
        $conn,
        trim($_POST['mobile'])
    );

    $subject = mysqli_real_escape_string(
        $conn,
        trim($_POST['subject'])
    );

    $message = mysqli_real_escape_string(
        $conn,
        trim($_POST['message'])
    );


    $sql = "
        INSERT INTO enquiry
        (
            name,
            email,
            mobile,
            subject,
            message,
            status,
            enquiry_date
        )
        VALUES
        (
            '$name',
            '$email',
            '$mobile',
            '$subject',
            '$message',
            'Pending',
            NOW()
        )
    ";


    if (mysqli_query($conn, $sql)) {

        echo "
        <script>
            alert('Enquiry Sent Successfully');
            window.location='contact.php';
        </script>
        ";

        exit();

    } else {

        die(
            "Enquiry Insert Error: " .
            mysqli_error($conn)
        );

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="utf-8">

<title>
Contact | SWIFFIN CAKE SHOP
</title>

<meta
content="width=device-width, initial-scale=1.0"
name="viewport"
>

<meta
content="Swiffin Cake Shop Contact"
name="keywords"
>

<meta
content="Contact Swiffin Cake Shop"
name="description"
>


<!-- FAVICON -->

<link
href="img/favicon.ico"
rel="icon"
>


<!-- GOOGLE FONTS -->

<link
rel="preconnect"
href="https://fonts.googleapis.com"
>

<link
rel="preconnect"
href="https://fonts.googleapis.com"
crossorigin
>

<link
href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Oswald:wght@500;600;700&family=Pacifico&display=swap"
rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
rel="stylesheet"
>


<!-- BOOTSTRAP ICONS -->

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
rel="stylesheet"
>


<!-- LIBRARY -->

<link
href="lib/owlcarousel/assets/owl.carousel.min.css"
rel="stylesheet"
>


<!-- BOOTSTRAP -->

<link
href="css/bootstrap.min.css"
rel="stylesheet"
>


<!-- TEMPLATE CSS -->

<link
href="css/style.css"
rel="stylesheet"
>


<style>

/* =====================================================
   ORIGINAL GLOBAL
===================================================== */

html {
    scroll-behavior: smooth;
}

body {

    margin: 0;

    padding: 0;

    color: #fff;

    font-family:
        "Open Sans",
        Arial,
        Helvetica,
        sans-serif;

}

.container-fluid {

    margin-top: 0 !important;

}


/* =====================================================
   COLORS
===================================================== */

:root {

    --orange: #E88F2A;

    --orange-dark: #d67d18;

    --black: #111111;

    --dark: #181818;

    --light: #FAF3EB;

}


/* =====================================================
   TOPBAR - ORIGINAL
===================================================== */

.topbar {

    background: #fff !important;

}

.topbar h6 {

    color: #222 !important;

}

.topbar span {

    color: #222 !important;

}

.topbar .navbar-brand {

    text-decoration: none;

}


/* =====================================================
   WELCOME USER - ORIGINAL
===================================================== */

.welcome-user {

    display: flex;

    align-items: center;

    gap: 10px;

}


.user-icon {

    width: 42px;

    height: 42px;

    border-radius: 50%;

    background: var(--orange);

    color: #fff;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 18px;

    box-shadow:
        0 4px 12px rgba(232,143,42,0.30);

}


.welcome-text {

    display: flex;

    flex-direction: column;

    line-height: 1.2;

}


.welcome-text small {

    color: #888;

    font-size: 10px;

    text-transform: uppercase;

    letter-spacing: 1px;

}


.welcome-text strong {

    color: #222;

    font-size: 14px;

    max-width: 140px;

    overflow: hidden;

    text-overflow: ellipsis;

    white-space: nowrap;

}


/* =====================================================
   GUEST - ORIGINAL
===================================================== */

.welcome-guest {

    display: flex;

    align-items: center;

    gap: 8px;

    color: #555;

    font-weight: 600;

}


.welcome-guest i {

    font-size: 28px;

    color: var(--orange);

}


/* =====================================================
   NAVBAR - ORIGINAL
===================================================== */

.navbar {

    background: #fff !important;

}


.navbar .nav-link {

    color: #222 !important;

    font-weight: 700 !important;

    transition: 0.3s;

}


.navbar .nav-link:hover {

    color: var(--orange) !important;

}


.navbar .nav-link.active {

    color: var(--orange) !important;

}


.navbar-nav .nav-link {

    font-weight: 700 !important;

}


/* =====================================================
   PRIMARY BUTTON - ORIGINAL
===================================================== */

.btn-primary {

    background: var(--orange) !important;

    border-color: var(--orange) !important;

    color: #fff !important;

}


.btn-primary:hover {

    background: var(--orange-dark) !important;

    border-color: var(--orange-dark) !important;

}


/* =====================================================
   SIGN IN - ORIGINAL
===================================================== */

.signin-btn {

    display: inline-flex;

    align-items: center;

    gap: 7px;

    background: var(--orange) !important;

    color: #fff !important;

    border-radius: 25px !important;

    padding: 9px 18px !important;

    font-weight: 700;

    border: 1px solid var(--orange) !important;

    transition: 0.3s;

}


.signin-btn:hover {

    background: #fff !important;

    color: var(--orange) !important;

}


/* =====================================================
   REGISTER - ORIGINAL
===================================================== */

.register-btn {

    display: inline-flex;

    align-items: center;

    gap: 7px;

    border: 1px solid var(--orange) !important;

    color: var(--orange) !important;

    background: #fff !important;

    border-radius: 25px !important;

    padding: 9px 18px !important;

    font-weight: 700;

    transition: 0.3s;

}


.register-btn:hover {

    background: var(--orange) !important;

    color: #fff !important;

}


/* =====================================================
   USER DROPDOWN - ORIGINAL
===================================================== */

.user-dropdown-btn {

    border: none;

    background: transparent;

    display: flex;

    align-items: center;

    gap: 8px;

    color: #222;

    font-weight: 600;

    cursor: pointer;

    padding: 7px 12px;

    border-radius: 25px;

    transition: 0.3s;

}


.user-dropdown-btn:hover {

    background: var(--light);

    color: var(--orange);

}


.user-dropdown-btn i {

    color: var(--orange);

    font-size: 21px;

}


.user-menu {

    min-width: 230px;

    padding: 10px;

    border: none;

    border-radius: 13px;

    box-shadow:
        0 10px 30px rgba(0,0,0,0.16);

}


.user-menu .user-info {

    padding: 12px;

    border-bottom: 1px solid #eee;

    margin-bottom: 5px;

}


.user-menu .user-info strong {

    display: block;

    color: #222;

    font-size: 15px;

}


.user-menu .user-info small {

    color: #888;

    font-size: 11px;

    word-break: break-all;

}


.user-menu .dropdown-item {

    border-radius: 8px;

    padding: 10px 12px;

}


.user-menu .logout-item {

    color: #dc3545;

}


.user-menu .logout-item:hover {

    background: #fff0f0;

    color: #dc3545;

}


/* =====================================================
   CART - ORIGINAL
===================================================== */

.cart-link {

    display: inline-flex !important;

    align-items: center;

    gap: 6px;

}


.cart-link i {

    color: var(--orange);

    font-size: 18px;

}


/* =====================================================
   CATEGORY DROPDOWN - ORIGINAL
===================================================== */

.dropdown-submenu {

    position: relative;

}


.dropdown-submenu > .dropdown-menu {

    top: 0;

    left: 100%;

    margin-top: 0;

    display: none;

}


.dropdown-submenu:hover > .dropdown-menu {

    display: block;

}


.dropdown-menu {

    min-width: 220px;

    border: none;

    border-radius: 10px;

    box-shadow:
        0 10px 30px rgba(0,0,0,0.15);

}


.dropdown-item {

    padding: 10px 15px;

    font-size: 14px;

    font-weight: 600;

}


.dropdown-item:hover {

    color: var(--orange);

    background: var(--light);

}


/* =====================================================
   =====================================================
   CONTACT PAGE NEW STYLISH DESIGN
   =====================================================
===================================================== */


/* =====================================================
   HERO
===================================================== */

.contact-hero {

    min-height: 440px;

    position: relative;

    display: flex;

    align-items: center;

    overflow: hidden;

    background:
        linear-gradient(
            90deg,
            rgba(0,0,0,.82),
            rgba(0,0,0,.58),
            rgba(0,0,0,.68)
        ),
        url("img/ca.jpg");

    background-size: cover;

    background-position: center;

}


/* subtle overlay */

.contact-hero::before {

    content: "";

    position: absolute;

    inset: 0;

    background:
        radial-gradient(
            circle at 50% 50%,
            rgba(232,143,42,.12),
            transparent 55%
        );

    pointer-events: none;

}


.contact-hero-content {

    position: relative;

    z-index: 2;

    max-width: 850px;

    margin: auto;

}


.contact-small-title {

    color: var(--orange);

    font-size: 14px;

    font-weight: 700;

    letter-spacing: 4px;

    text-transform: uppercase;

    margin-bottom: 15px;

}


.contact-hero h1 {

    color: #fff;

    font-family: "Oswald", sans-serif;

    font-size: 58px;

    font-weight: 700;

    line-height: 1.1;

    margin-bottom: 20px;

}


.contact-hero h1 span {

    color: var(--orange);

}


.contact-hero p {

    color: #e7e7e7;

    font-size: 17px;

    line-height: 1.8;

    max-width: 700px;

    margin: auto;

}


/* decorative line */

.hero-line {

    width: 70px;

    height: 3px;

    background: var(--orange);

    margin: 22px auto;

    border-radius: 5px;

}


/* =====================================================
   CONTACT INFO SECTION
===================================================== */

.contact-info {

    background: #050505;

    padding: 70px 0 !important;

}


.contact-section-title {

    text-align: center;

    margin-bottom: 45px;

}


.contact-section-title small {

    color: var(--orange);

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 3px;

    text-transform: uppercase;

}


.contact-section-title h2 {

    color: #fff;

    font-family: "Oswald", sans-serif;

    font-size: 38px;

    margin: 8px 0 0;

}


.contact-card {

    position: relative;

    background:
        linear-gradient(
            145deg,
            #181818,
            #0d0d0d
        );

    border: 1px solid #2d2d2d;

    border-radius: 18px;

    padding: 34px 25px;

    height: 100%;

    text-align: center;

    overflow: hidden;

    transition: .35s;

}


.contact-card::before {

    content: "";

    position: absolute;

    top: 0;

    left: 0;

    right: 0;

    height: 3px;

    background: var(--orange);

    transform: scaleX(0);

    transform-origin: center;

    transition: .35s;

}


.contact-card:hover {

    transform: translateY(-8px);

    border-color: rgba(232,143,42,.55);

    box-shadow:
        0 18px 40px rgba(0,0,0,.45);

}


.contact-card:hover::before {

    transform: scaleX(1);

}


.contact-icon {

    width: 70px;

    height: 70px;

    display: flex;

    align-items: center;

    justify-content: center;

    margin: 0 auto 20px;

    border-radius: 50%;

    background: rgba(232,143,42,.09);

    border: 1px solid rgba(232,143,42,.22);

    color: var(--orange);

    font-size: 25px;

    transition: .35s;

}


.contact-card:hover .contact-icon {

    background: var(--orange);

    color: #fff;

    transform: rotateY(180deg);

}


.contact-card h4 {

    color: #fff;

    font-family: "Oswald", sans-serif;

    font-size: 21px;

    margin-bottom: 12px;

}


.contact-card p {

    color: #aaa;

    font-size: 14px;

    line-height: 1.8;

    margin: 0;

}


/* =====================================================
   MESSAGE SECTION
===================================================== */

.message-section {

    background: #000;

    padding: 75px 0;

}


.message-wrapper {

    background:
        linear-gradient(
            135deg,
            #161616,
            #0b0b0b
        );

    border: 1px solid #292929;

    border-radius: 24px;

    padding: 10px;

    box-shadow:
        0 20px 60px rgba(0,0,0,.35);

}


.message-inner {

    border: 1px solid #242424;

    border-radius: 18px;

    padding: 38px;

}


.message-heading small {

    color: var(--orange);

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 3px;

    text-transform: uppercase;

}


.message-heading h2 {

    color: #fff;

    font-family: "Oswald", sans-serif;

    font-size: 36px;

    margin: 8px 0 10px;

}


.message-heading p {

    color: #999;

    font-size: 14px;

    margin-bottom: 28px;

}


/* =====================================================
   FORM
===================================================== */

.contact-form .form-label {

    color: #bbb;

    font-size: 12px;

    font-weight: 700;

    margin-bottom: 7px;

}


.contact-form .form-control {

    background: #070707 !important;

    border: 1px solid #343434 !important;

    color: #fff !important;

    border-radius: 10px;

    padding: 13px 15px;

    font-size: 14px;

    transition: .3s;

}


.contact-form .form-control:focus {

    border-color: var(--orange) !important;

    box-shadow:
        0 0 0 3px rgba(232,143,42,.10) !important;

}


.contact-form .form-control::placeholder {

    color: #666;

}


.contact-form textarea {

    resize: none;

}


/* =====================================================
   SEND BUTTON
===================================================== */

.send-btn {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 9px;

    background: var(--orange);

    color: #fff;

    border: 1px solid var(--orange);

    border-radius: 30px;

    padding: 13px 28px;

    font-size: 14px;

    font-weight: 700;

    transition: .3s;

}


.send-btn:hover {

    background: var(--orange-dark);

    border-color: var(--orange-dark);

    color: #fff;

    transform: translateY(-2px);

    box-shadow:
        0 8px 20px rgba(232,143,42,.18);

}


/* =====================================================
   RIGHT CAKE SHOWCASE
===================================================== */

.cake-showcase {

    position: relative;

    height: 100%;

    min-height: 500px;

    border-radius: 20px;

    overflow: hidden;

    background: #111;

    border: 1px solid #303030;

}


.cake-showcase img {

    width: 100%;

    height: 100%;

    min-height: 500px;

    object-fit: cover;

    display: block;

    transition: .5s;

}


.cake-showcase:hover img {

    transform: scale(1.04);

}


.cake-overlay {

    position: absolute;

    left: 0;

    right: 0;

    bottom: 0;

    padding: 35px 25px 25px;

    background:
        linear-gradient(
            transparent,
            rgba(0,0,0,.94)
        );

}


.cake-overlay .mini-title {

    color: var(--orange);

    font-size: 11px;

    font-weight: 700;

    letter-spacing: 2px;

    text-transform: uppercase;

}


.cake-overlay h3 {

    color: #fff;

    font-family: "Oswald", sans-serif;

    font-size: 29px;

    margin: 5px 0 8px;

}


.cake-overlay p {

    color: #ccc;

    font-size: 13px;

    line-height: 1.7;

    margin: 0;

}


/* =====================================================
   QUICK CONTACT
===================================================== */

.quick-contact {

    display: flex;

    align-items: center;

    gap: 12px;

    margin-top: 22px;

}


.quick-contact-icon {

    width: 42px;

    height: 42px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 50%;

    background: var(--orange);

    color: #fff;

}


.quick-contact-text small {

    display: block;

    color: #777;

    font-size: 10px;

    letter-spacing: 1px;

    text-transform: uppercase;

}


.quick-contact-text strong {

    color: #fff;

    font-size: 13px;

}


/* =====================================================
   MAP SECTION
===================================================== */

.map-section {

    background: #050505;

    padding: 75px 0 !important;

}


.map-heading {

    text-align: center;

    margin-bottom: 35px;

}


.map-heading small {

    color: var(--orange);

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 3px;

    text-transform: uppercase;

}


.map-heading h2 {

    color: #fff;

    font-family: "Oswald", sans-serif;

    font-size: 38px;

    margin: 8px 0;

}


.map-heading p {

    color: #888;

    font-size: 14px;

}


.map-wrapper {

    padding: 8px;

    background: #111;

    border: 1px solid #292929;

    border-radius: 20px;

}


.map-wrapper iframe {

    width: 100%;

    height: 400px;

    border: 0;

    border-radius: 14px;

    display: block;

}


/* =====================================================
   MOBILE
===================================================== */

@media(max-width:991px){

    .navbar .navbar-nav {

        align-items: stretch !important;

        padding-top: 10px;

    }

    .navbar .nav-link {

        padding: 10px 15px !important;

    }

    .navbar .signin-btn,
    .navbar .register-btn {

        margin: 5px 10px !important;

    }

    .dropdown-submenu > .dropdown-menu {

        position: static !important;

        margin-left: 15px !important;

        box-shadow: none !important;

    }


    .contact-hero {

        min-height: 380px;

    }


    .contact-hero h1 {

        font-size: 45px;

    }


    .cake-showcase {

        min-height: 430px;

    }


    .cake-showcase img {

        min-height: 430px;

    }

}


@media(max-width:768px){

    .contact-hero {

        min-height: 350px;

        padding: 50px 15px;

    }


    .contact-hero h1 {

        font-size: 38px;

    }


    .contact-hero p {

        font-size: 15px;

    }


    .contact-info,
    .message-section,
    .map-section {

        padding: 55px 0 !important;

    }


    .contact-section-title h2,
    .map-heading h2 {

        font-size: 31px;

    }


    .message-inner {

        padding: 25px 18px;

    }


    .message-heading h2 {

        font-size: 30px;

    }


    .cake-showcase {

        min-height: 400px;

        margin-top: 20px;

    }


    .cake-showcase img {

        min-height: 400px;

    }

}


@media(max-width:576px){

    .topbar {

        padding-left: 15px !important;

        padding-right: 15px !important;

    }


    .contact-hero h1 {

        font-size: 32px;

    }


    .contact-small-title {

        font-size: 11px;

        letter-spacing: 2.5px;

    }


    .contact-card {

        padding: 28px 18px;

    }


    .message-wrapper {

        padding: 5px;

        border-radius: 18px;

    }


    .message-inner {

        padding: 22px 15px;

    }


    .cake-showcase {

        min-height: 350px;

    }


    .cake-showcase img {

        min-height: 350px;

    }


    .map-wrapper iframe {

        height: 330px;

    }

}

</style>

</head>


<body>


<!-- =====================================================
     TOPBAR
     ORIGINAL - NO CHANGE
===================================================== -->

<div class="container-fluid px-5">

    <div class="row align-items-center">


        <!-- WELCOME -->

        <div class="col-lg-3">

            <?php if ($customer_logged_in) { ?>

                <div class="welcome-user">

                    <div class="user-icon">

                        <i class="fas fa-user"></i>

                    </div>

                    <div class="welcome-text">

                        <small>
                            Welcome
                        </small>

                        <strong>

                            <?php

                            echo htmlspecialchars(
                                $customer_name
                            );

                            ?>

                        </strong>

                    </div>

                </div>

            <?php } else { ?>

                <div class="welcome-guest">

                    <i class="fas fa-user-circle"></i>

                    <span>
                        Welcome Guest
                    </span>

                </div>

            <?php } ?>

        </div>


        <!-- LOGO -->

        <div class="col-lg-5 text-center py-2">

            <a
                href="index1.php"
                class="navbar-brand d-flex justify-content-center align-items-center"
            >

                <img
                    src="img/logo.png"
                    alt="SWIFFIN Logo"
                    width="60"
                    height="60"
                >

                <h1 class="m-0 ms-2 text-uppercase">

                    <span style="color:#ff9800;">
                        SWIFFIN
                    </span>

                </h1>

            </a>

        </div>


        <!-- CALL -->

        <div class="col-lg-4 text-end pe-4">

            <div class="d-inline-flex align-items-center">

                <i
                    class="bi bi-phone-vibrate fs-1 text-primary me-3"
                ></i>

                <div class="text-start">

                    <h6 class="text-uppercase mb-1">

                        CALL US

                    </h6>

                    <span
                        style="
                            color:#222 !important;
                            display:block !important;
                            visibility:visible !important;
                            opacity:1 !important;
                        "
                    >

                        +91 9876543210

                    </span>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =====================================================
     NAVBAR
     ORIGINAL - NO CHANGE
===================================================== -->

<nav
    class="navbar navbar-expand-lg bg-white navbar-light shadow-sm sticky-top py-3"
>

    <div class="container">


        <!-- MOBILE -->

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbar"
            aria-controls="navbar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >

            <span class="navbar-toggler-icon"></span>

        </button>


        <div
            class="collapse navbar-collapse"
            id="navbar"
        >

            <ul class="navbar-nav ms-auto align-items-center">


                <!-- HOME -->

                <li class="nav-item">

                    <a
                        href="index1.php"
                        class="nav-link"
                    >
                        Home
                    </a>

                </li>


                <!-- ABOUT -->

                <li class="nav-item">

                    <a
                        href="about.php"
                        class="nav-link"
                    >
                        About
                    </a>

                </li>
				

                <!-- CAKES -->

                <li class="nav-item dropdown">

                    <div class="d-flex align-items-center">

                        <a
                            href="product.php"
                            class="nav-link"
                            style="padding-right:2px;"
                        >
                            Cakes
                        </a>

                        <a
                            href="#"
                            class="nav-link dropdown-toggle"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            style="padding-left:2px;"
                        ></a>


                        <!-- CATEGORY DROPDOWN -->

                        <ul class="dropdown-menu">

                            <?php foreach (
                                $parent_categories
                                as $parent
                            ) { ?>

                                <?php

                                $parent_id =
                                    intval(
                                        $parent['id']
                                    );

                                $sub_categories =
                                    getSubCategories(
                                        $conn,
                                        $parent_id
                                    );

                                ?>


                                <?php if (
                                    count(
                                        $sub_categories
                                    ) > 0
                                ) { ?>

                                    <li
                                        class="dropdown-submenu"
                                    >

                                        <a
                                            href="product.php?category=<?php echo $parent_id; ?>"
                                            class="dropdown-item dropdown-toggle"
                                        >

                                            <?php

                                            echo htmlspecialchars(
                                                $parent['category_name']
                                            );

                                            ?>

                                        </a>


                                        <ul class="dropdown-menu">

                                            <?php foreach (
                                                $sub_categories
                                                as $sub
                                            ) { ?>

                                                <li>

                                                    <a
                                                        href="product.php?category=<?php echo intval($sub['id']); ?>"
                                                        class="dropdown-item"
                                                    >

                                                        <?php

                                                        echo htmlspecialchars(
                                                            $sub['category_name']
                                                        );

                                                        ?>

                                                    </a>

                                                </li>

                                            <?php } ?>

                                        </ul>

                                    </li>

                                <?php } else { ?>

                                    <li>

                                        <a
                                            href="product.php?category=<?php echo $parent_id; ?>"
                                            class="dropdown-item"
                                        >

                                            <?php

                                            echo htmlspecialchars(
                                                $parent['category_name']
                                            );

                                            ?>

                                        </a>

                                    </li>

                                <?php } ?>

                            <?php } ?>

                        </ul>

                    </div>

                </li>
				  <!-- GALLERY -->

                <li class="nav-item">

                    <a
                        href="gallery.php"
                        class="nav-link fw-bold"
                    >
                        Gallery
                    </a>

                </li>


                <!-- CONTACT -->

                <li class="nav-item">

                    <a
                        href="contact.php"
                        class="nav-link active"
                    >
                        Contact
                    </a>

                </li>


                <!-- CART -->

                <?php if ($customer_logged_in) { ?>

                    <li class="nav-item">

                        <a
                            href="carts.php"
                            class="nav-link cart-link"
                        >

                            <i class="fas fa-shopping-cart"></i>

                            Cart

                        </a>

                    </li>

                <?php } ?>


                <!-- LOGGED IN USER -->

                <?php if ($customer_logged_in) { ?>

                    <li class="nav-item dropdown ms-2">

                        <button
                            class="user-dropdown-btn dropdown-toggle"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                        >

                            <i class="fas fa-user-circle"></i>

                            <span>

                                <?php

                                echo htmlspecialchars(
                                    $customer_name
                                );

                                ?>

                            </span>

                        </button>


                        <ul
                            class="dropdown-menu dropdown-menu-end user-menu"
                        >

                            <li>

                                <div class="user-info">

                                    <strong>

                                        <?php

                                        echo htmlspecialchars(
                                            $customer_name
                                        );

                                        ?>

                                    </strong>

                                    <small>

                                        <?php

                                        echo htmlspecialchars(
                                            $customer_email
                                        );

                                        ?>

                                    </small>

                                </div>

                            </li>


                            <li>

                                <a
                                    href="#"
                                    class="dropdown-item"
                                >

                                    <i class="fas fa-user me-2"></i>

                                    My Profile

                                </a>

                            </li>


                            <li>

                                <a
                                    href="carts.php"
                                    class="dropdown-item"
                                >

                                    <i class="fas fa-shopping-cart me-2"></i>

                                    My Cart

                                </a>

                            </li>


                            <li>

                                <hr class="dropdown-divider">

                            </li>


                            <li>

                                <a
                                    href="logout.php"
                                    class="dropdown-item logout-item"
                                >

                                    <i class="fas fa-sign-out-alt me-2"></i>

                                    Sign Out

                                </a>

                            </li>

                        </ul>

                    </li>


                <?php } else { ?>


                    <!-- SIGN IN -->

                    <li class="nav-item ms-2">

                        <a
                            href="login.php"
                            class="btn signin-btn"
                        >

                            <i class="fas fa-sign-in-alt"></i>

                            Sign In

                        </a>

                    </li>


                    <!-- REGISTER -->

                    <li class="nav-item ms-2">

                        <a
                            href="register.php"
                            class="btn register-btn"
                        >

                            <i class="fas fa-user-plus"></i>

                            Register

                        </a>

                    </li>


                <?php } ?>


            </ul>

        </div>

    </div>

</nav>


<!-- =====================================================
     HERO
===================================================== -->

<section class="contact-hero">

    <div class="container text-center">

        <div class="contact-hero-content">

            <div class="contact-small-title">
                Contact Swiffin
            </div>

            <h1>
                Let's Make Something
                <span>Sweet</span>
            </h1>

            <div class="hero-line"></div>

            <p>

                Have a question, special request or
                custom cake idea? We'd love to hear from you.
                Our team is always happy to help.

            </p>

        </div>

    </div>

</section>


<!-- =====================================================
     CONTACT INFORMATION
===================================================== -->

<section class="contact-info">

    <div class="container">


        <div class="contact-section-title">

            <small>
                Get In Touch
            </small>

            <h2>
                We'd Love To Hear From You
            </h2>

        </div>


        <div class="row g-4">


            <!-- ADDRESS -->

            <div class="col-lg-4 col-md-6">

                <div class="contact-card">

                    <div class="contact-icon">

                        <i class="fas fa-map-marker-alt"></i>

                    </div>

                    <h4>
                        Visit Our Shop
                    </h4>

                    <p>

                        Swiffin Cake Shop<br>
                        Amreli, Gujarat

                    </p>

                </div>

            </div>


            <!-- PHONE -->

            <div class="col-lg-4 col-md-6">

                <div class="contact-card">

                    <div class="contact-icon">

                        <i class="fas fa-phone-alt"></i>

                    </div>

                    <h4>
                        Call Us
                    </h4>

                    <p>

                        +91 98765 43210<br>
                        +91 98765 43211

                    </p>

                </div>

            </div>


            <!-- EMAIL -->

            <div class="col-lg-4 col-md-6 mx-auto">

                <div class="contact-card">

                    <div class="contact-icon">

                        <i class="fas fa-envelope"></i>

                    </div>

                    <h4>
                        Email Us
                    </h4>

                    <p>

                        swiffin10@gmail.com<br>
                        We reply as soon as possible.

                    </p>

                </div>

            </div>


        </div>

    </div>

</section>


<!-- =====================================================
     MESSAGE SECTION
===================================================== -->

<section class="message-section">

    <div class="container">

        <div class="message-wrapper">

            <div class="message-inner">

                <div class="row align-items-stretch g-4">


                    <!-- FORM -->

                    <div class="col-lg-7">

                        <div class="contact-form">

                            <div class="message-heading">

                                <small>
                                    Send A Message
                                </small>

                                <h2>
                                    Tell Us What You Need
                                </h2>

                                <p>

                                    Whether it's a custom cake,
                                    an order enquiry or simply
                                    a question, send us a message.

                                </p>

                            </div>


                            <form
                                method="POST"
                                action="contact.php"
                            >


                                <!-- NAME + EMAIL -->

                                <div class="row">


                                    <div class="col-md-6 mb-3">

                                        <label class="form-label">
                                            Your Name
                                        </label>

                                        <input
                                            type="text"
                                            name="name"
                                            class="form-control"
                                            placeholder="Enter your name"
                                            required
                                        >

                                    </div>


                                    <div class="col-md-6 mb-3">

                                        <label class="form-label">
                                            Email Address
                                        </label>

                                        <input
                                            type="email"
                                            name="email"
                                            class="form-control"
                                            placeholder="Enter your email"
                                            required
                                        >

                                    </div>


                                </div>


                                <!-- MOBILE -->

                                <div class="mb-3">

                                    <label class="form-label">
                                        Mobile Number
                                    </label>

                                    <input
                                        type="text"
                                        name="mobile"
                                        class="form-control"
                                        placeholder="Enter your mobile number"
                                        maxlength="15"
                                        required
                                    >

                                </div>


                                <!-- SUBJECT -->

                                <div class="mb-3">

                                    <label class="form-label">
                                        Subject
                                    </label>

                                    <input
                                        type="text"
                                        name="subject"
                                        class="form-control"
                                        placeholder="What can we help you with?"
                                        required
                                    >

                                </div>


                                <!-- MESSAGE -->

                                <div class="mb-4">

                                    <label class="form-label">
                                        Message
                                    </label>

                                    <textarea
                                        name="message"
                                        class="form-control"
                                        rows="5"
                                        placeholder="Write your message here..."
                                        required
                                    ></textarea>

                                </div>


                                <!-- BUTTON -->

                                <button
                                    type="submit"
                                    name="send_enquiry"
                                    class="send-btn"
                                >

                                    <i class="fas fa-paper-plane"></i>

                                    Send Message

                                </button>


                            </form>

                        </div>

                    </div>


                    <!-- IMAGE -->

                    <div class="col-lg-5">

                        <div class="cake-showcase">

                            <img
                                src="img/ca.jpg"
                                alt="Swiffin Fresh Cake"
                            >


                            <div class="cake-overlay">

                                <div class="mini-title">
                                    Made With Love
                                </div>

                                <h3>
                                    Fresh Cakes Every Day
                                </h3>

                                <p>

                                    Beautiful cakes made fresh
                                    for birthdays, anniversaries,
                                    weddings and every special moment.

                                </p>


                                <div class="quick-contact">

                                    <div class="quick-contact-icon">

                                        <i class="fas fa-phone"></i>

                                    </div>

                                    <div class="quick-contact-text">

                                        <small>
                                            Quick Contact
                                        </small>

                                        <strong>
                                            +91 9876543210
                                        </strong>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                </div>

            </div>

        </div>

    </div>

</section>


<!-- =====================================================
     MAP
===================================================== -->

<section class="map-section">

    <div class="container">


        <div class="map-heading">

            <small>
                Find Us
            </small>

            <h2>
                Visit Swiffin Cake Shop
            </h2>

            <p>
                Come visit us and discover your favourite cake.
            </p>

        </div>


        <div class="map-wrapper">

            <iframe
                src="https://www.google.com/maps?q=Amreli,Gujarat&output=embed"
                loading="lazy"
                allowfullscreen
            ></iframe>

        </div>


    </div>

</section>


<!-- =====================================================
     JAVASCRIPT
===================================================== -->

<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"
></script>


<script>

/* =====================================================
   SUBMENU HOVER
===================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const submenuItems =
            document.querySelectorAll(
                ".dropdown-submenu"
            );


        submenuItems.forEach(
            function (item) {

                item.addEventListener(
                    "mouseenter",
                    function () {

                        const menu =
                            item.querySelector(
                                ":scope > .dropdown-menu"
                            );

                        if (menu) {

                            menu.style.display =
                                "block";

                        }

                    }
                );


                item.addEventListener(
                    "mouseleave",
                    function () {

                        const menu =
                            item.querySelector(
                                ":scope > .dropdown-menu"
                            );

                        if (menu) {

                            menu.style.display =
                                "";

                        }

                    }
                );

            }
        );

    }
);

</script>


</body>

</html> 