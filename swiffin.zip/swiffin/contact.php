<?php include("config.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>login</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Oswald:wght@500;600;700&family=Pacifico&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<style>
<body>{
	margin:0;
	padding:0;
}
.container-fluid
{
	margin-top:0!important;
	padding:0!important;
}
</style>
    <!-- Topbar Start -->

	<div class="container-fluid px-5">
    <div class="row align-items-center">

        <!-- Welcome Left -->
        <div class="col-lg-2">
            <h5 class="m-1 fw-bold">
			<?php
			if(isset($_SESSION['name'])){
               echo "Welcome ". $_SESSION['name']; 
			}
			else
			{
				echo "welcome";
			}
			?>		
            </h5>
        </div>

     <!-- SWIFFIN Center -->
<div class="col-lg-5 text-center  py-2">
    <a href="index1.php" class="navbar-brand d-flex justify-content-center align-items-center">
        <img src="img/logo.png" alt="Logo" width="60" height="60" >
        <h1 class="m-0  ms-2 text-uppercase ">
		<span style ="color:#ff9800;">SWIFFIN</span>
		</h1>
    </a>
</div>
        <!-- CALL US Right -->
        <div class="col-lg-4 text-end">
            <div class="d-inline-flex align-items-center ">
                <i class="bi bi-phone-vibrate fs-1 text-primary me-3"></i>
                <div class="text-start">
                    <h6 class="text-uppercase mb-1">CALL US</h6>
                    <span>+91 9876543210</span>
                </div>
            </div>
        </div>

    </div>
</div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm sticky-top py-3">
    <div class="container">

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbar">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a href="index1.php" class="nav-link ">Home</a></li>
                <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
                <li class="nav-item"><a href="product.php" class="nav-link">Cakes</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link">Gallery</a></li>
                <li class="nav-item"><a href="contact.php" class="nav-link active">Contact</a></li>
                <li class="nav-item"><a href="login.php" class="btn btn-primary rounded-circle ms-3 px-4">Login</a></li>
				<li class="nav-item"><a href="register.php" class="btn btn-primary  rounded-circle ms-3 px-4">Register</a></li>
				<li class="nav-item"><a href="admin.php" class="btn btn-primary rounded-circle  ms-3 px-4">Admin</a></li>
				<li class="nav-item"><a href="logout.php" class="btn btn-primary rounded-circle ms-3 px-4">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
    <!-- Navbar End -->


<!-- Hero Start -->
<section class="contact-hero d-flex align-items-center">
    <div class="container text-center text-white">
        <h5 class="text-warning fw-bold">CONTACT US</h5>
        <b class="display-3 fw-bold">Get In Touch With Swiffin</b>
        <p class="lead">
            We'd love to hear from you. Contact us for custom cakes,
            orders, or any questions.
        </p>
    </div>
</section>
<!-- Hero End -->


<!-- Contact Info Start -->
<section class="contact-info py-5">
    <div class="container">

        <div class="row g-4">

            <!-- Address -->
            <div class="col-lg-4">
                <div class="contact-box text-center">
                   <i class="fas fa-map-marker-alt"></i>
                    <h4 style="color:#E88F2A;">Our Address</h4>
                    <p>
                        Swiffin Cake Shop<br>
                        Rajkot, Gujarat
                    </p>
                </div>
            </div>

            <!-- Phone -->
            <div class="col-lg-4">
                <div class="contact-box text-center">
                    <i class="fas fa-phone"></i>
                     <h4 style="color:#E88F2A;">Call Us</h4>
                    <p>
                        +91 98765 43210<br>
                        +91 98765 43211
                    </p>
                </div>
            </div>

            <!-- Email -->
            <div class="col-lg-4">
                <div class="contact-box text-center">
                    <i class="fas fa-envelope"></i>
                    <h4 style="color:#E88F2A;">Email</h4>
                    <p>
                        swiffin10@gmail.com<br>
                        support@swiffin.com
                    </p>
                </div>
            </div>

        </div>

    </div>
</section>
<!-- Contact Info End -->


<!-- Contact Form Start -->
<section class="contact-section py-5">
    <div class="container">

        <div class="row align-items-center">

            <!-- Form -->
            <div class="col-lg-7">

                <div class="contact-form">

                    <h2 class="text-white mb-4">
                        Send Us A Message
                    </h2>

                    <form>

                        <div class="row">

                            <div class="col-md-6 mb-3">
                                <input type="text"
                                       class="form-control"
                                       placeholder="Your Name">
                            </div>

                            <div class="col-md-6 mb-3">
                                <input type="email"
                                       class="form-control"
                                       placeholder="Your Email">
                            </div>

                        </div>

                        <div class="mb-3">
                            <input type="text"
                                   class="form-control"
                                   placeholder="Subject">
                        </div>

                        <div class="mb-3">
                            <textarea class="form-control"
                                      rows="6"
                                      placeholder="Write Your Message"></textarea>
                        </div>

                        <button class="btn btn-warning px-5 py-3 fw-bold">
                            Send Message
                        </button>

                    </form>

                </div>

            </div>

            <!-- Right Side -->
            <div class="col-lg-5">

                <div class="contact-image text-center">

                    <img src="img/ca.jpg"
                         class="img-fluid"
                         alt="Cake">

                    <h3 class="text-warning mt-4">
                        Fresh Cakes Every Day
                    </h3>

                    <p class="text-light">
                        We bake happiness for birthdays,
                        anniversaries, weddings and every
                        special celebration.
                    </p>

                </div>

            </div>

        </div>

    </div>
</section>
<!-- Contact Form End -->


<!-- Google Map -->
<section class="map-section py-5">
    <div class="container">

        <div class="text-center mb-4">
            <h2 class="text-white">Find Us On Map</h2>
        </div>

        <iframe
            src="https://www.google.com/maps?q=Amreli,Gujarat&output=embed"
            loading="lazy">
        </iframe>

    </div>
</section>
