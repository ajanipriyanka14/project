<?php
session_start();
include "config.php";

$message = "";
$message_type = "";


// =====================================================
// GET ORDER ID
// =====================================================

$order_id = 0;

if (isset($_GET['order_id'])) {
    $order_id = intval($_GET['order_id']);
}

if (isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);
}

if ($order_id <= 0) {
    die("
    <!DOCTYPE html>
    <html>
    <head>
    <title>Order Not Found</title>
    <style>
        body{
            margin:0;
            background:#000;
            color:#fff;
            font-family:Arial,sans-serif;
            min-height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
            text-align:center;
        }

        .error-box{
            background:#111;
            border:1px solid #E88F2A;
            padding:40px;
            border-radius:20px;
            width:90%;
            max-width:450px;
            box-shadow:0 0 30px rgba(232,143,42,.20);
        }

        h2{
            color:#E88F2A;
        }

        p{
            color:#999;
        }

        a{
            display:inline-block;
            margin-top:15px;
            padding:12px 25px;
            background:#E88F2A;
            color:#fff;
            text-decoration:none;
            border-radius:25px;
            font-weight:bold;
        }

        a:hover{
            background:#d67d18;
        }
    </style>
    </head>

    <body>

    <div class='error-box'>

        <h2>
            <i class='fa-solid fa-circle-exclamation'></i>
            Order ID Not Found
        </h2>

        <p>
            Please open the review page from your delivered order.
        </p>

        <a href='index1.php'>
            Back to Home
        </a>

    </div>

    </body>
    </html>
    ");
}


// =====================================================
// GET DELIVERY RECORD
// =====================================================

$delivery_sql = "
    SELECT *
    FROM delivery
    WHERE order_id = ?
    LIMIT 1
";

$delivery_stmt = mysqli_prepare($conn, $delivery_sql);

if (!$delivery_stmt) {
    die("Database Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param(
    $delivery_stmt,
    "i",
    $order_id
);

mysqli_stmt_execute($delivery_stmt);

$delivery_result = mysqli_stmt_get_result($delivery_stmt);


// =====================================================
// CHECK DELIVERY
// =====================================================

if (!$delivery_result || mysqli_num_rows($delivery_result) == 0) {

    die("
    <!DOCTYPE html>
    <html>
    <head>
    <title>Order Not Found</title>

    <style>

    body{
        margin:0;
        background:#000;
        color:#fff;
        font-family:Arial,sans-serif;
        min-height:100vh;
        display:flex;
        justify-content:center;
        align-items:center;
        text-align:center;
    }

    .error-box{
        background:#111;
        border:1px solid #E88F2A;
        padding:40px;
        border-radius:20px;
        width:90%;
        max-width:450px;
        box-shadow:0 0 30px rgba(232,143,42,.20);
    }

    h2{
        color:#E88F2A;
    }

    p{
        color:#999;
    }

    a{
        display:inline-block;
        margin-top:15px;
        padding:12px 25px;
        background:#E88F2A;
        color:#fff;
        text-decoration:none;
        border-radius:25px;
        font-weight:bold;
    }

    </style>

    </head>

    <body>

    <div class='error-box'>

        <h2>Order Not Found</h2>

        <p>
            Delivery record for Order #$order_id was not found.
        </p>

        <a href='index1.php'>
            Back to Home
        </a>

    </div>

    </body>
    </html>
    ");

}

$delivery = mysqli_fetch_assoc($delivery_result);


// =====================================================
// CHECK DELIVERY STATUS
// =====================================================

if ($delivery['delivery_status'] != "Delivered") {

    die("
    <!DOCTYPE html>
    <html>
    <head>

    <title>Review Not Available</title>

    <style>

    body{
        margin:0;
        background:#000;
        color:#fff;
        font-family:Arial,sans-serif;
        min-height:100vh;
        display:flex;
        justify-content:center;
        align-items:center;
        text-align:center;
    }

    .error-box{
        background:#111;
        border:1px solid #E88F2A;
        padding:40px;
        border-radius:20px;
        width:90%;
        max-width:450px;
    }

    h2{
        color:#E88F2A;
    }

    p{
        color:#999;
    }

    a{
        display:inline-block;
        margin-top:15px;
        padding:12px 25px;
        background:#E88F2A;
        color:#fff;
        text-decoration:none;
        border-radius:25px;
        font-weight:bold;
    }

    </style>

    </head>

    <body>

    <div class='error-box'>

        <h2>Review Not Available</h2>

        <p>
            You can submit a review only after your order is delivered.
        </p>

        <a href='index1.php'>
            Back to Home
        </a>

    </div>

    </body>
    </html>
    ");

}


// =====================================================
// GET ORDER FROM ORDERS TABLE
// =====================================================

$order_sql = "
    SELECT *
    FROM orders
    WHERE id = ?
    LIMIT 1
";

$order_stmt = mysqli_prepare($conn, $order_sql);

if (!$order_stmt) {
    die("Database Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param(
    $order_stmt,
    "i",
    $order_id
);

mysqli_stmt_execute($order_stmt);

$order_result = mysqli_stmt_get_result($order_stmt);


// =====================================================
// ORDER DETAILS
// =====================================================

if ($order_result && mysqli_num_rows($order_result) > 0) {

    $order = mysqli_fetch_assoc($order_result);

    $customer_name = $order['customer_name'] ?? $delivery['customer_name'];
    $cake_name = $order['cake_name'] ?? "Cake";

} else {

    // If orders record is missing,
    // use delivery table information

    $customer_name = $delivery['customer_name'] ?? "Customer";
    $cake_name = "Cake";
}


// =====================================================
// CHECK ALREADY REVIEWED
// =====================================================

$already_reviewed = false;

$check_sql = "
    SELECT id
    FROM feedback
    WHERE order_id = ?
    LIMIT 1
";

$check_stmt = mysqli_prepare(
    $conn,
    $check_sql
);

if ($check_stmt) {

    mysqli_stmt_bind_param(
        $check_stmt,
        "i",
        $order_id
    );

    mysqli_stmt_execute($check_stmt);

    $check_result = mysqli_stmt_get_result(
        $check_stmt
    );

    if (
        $check_result &&
        mysqli_num_rows($check_result) > 0
    ) {

        $already_reviewed = true;
    }
}


// =====================================================
// SUBMIT FEEDBACK
// =====================================================

if (
    isset($_POST['submit_feedback']) &&
    !$already_reviewed
) {

    $rating = intval(
        $_POST['rating'] ?? 0
    );

    $email = trim(
        $_POST['email'] ?? ""
    );

    $review = trim(
        $_POST['message'] ?? ""
    );


    // =================================================
    // VALIDATION
    // =================================================

    if ($rating < 1 || $rating > 5) {

        $message = "Please select your rating.";
        $message_type = "error";

    }

    elseif ($email == "") {

        $message = "Please enter your email.";
        $message_type = "error";

    }

    elseif (!filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )) {

        $message = "Please enter a valid email address.";
        $message_type = "error";

    }

    elseif ($review == "") {

        $message = "Please write your review.";
        $message_type = "error";

    }

    else {

        // =================================================
        // INSERT FEEDBACK
        // =================================================

        $insert_sql = "
            INSERT INTO feedback
            (
                order_id,
                customer_name,
                email,
                cake_name,
                rating,
                message,
                feedback_date
            )
            VALUES
            (?, ?, ?, ?, ?, ?, NOW())
        ";

        $insert_stmt = mysqli_prepare(
            $conn,
            $insert_sql
        );

        if (!$insert_stmt) {

            $message =
                "Database Error: " .
                mysqli_error($conn);

            $message_type = "error";

        } else {

            mysqli_stmt_bind_param(
                $insert_stmt,
                "isssis",
                $order_id,
                $customer_name,
                $email,
                $cake_name,
                $rating,
                $review
            );

            if (
                mysqli_stmt_execute(
                    $insert_stmt
                )
            ) {

                $message =
                    "Thank you! Your review has been submitted successfully.";

                $message_type = "success";

                $already_reviewed = true;

            } else {

                $message =
                    "Feedback Error: " .
                    mysqli_stmt_error(
                        $insert_stmt
                    );

                $message_type = "error";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Rate & Review | SWIFFIN Cake Shop
</title>


<!-- GOOGLE FONT -->

<link
rel="preconnect"
href="https://fonts.googleapis.com"
>

<link
rel="preconnect"
href="https://fonts.gstatic.com"
crossorigin
>

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
rel="stylesheet"
>


<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}


body{

    min-height:100vh;

    background:#000;

    color:#fff;

    font-family:
    'Poppins',
    Arial,
    sans-serif;

    display:flex;

    justify-content:center;

    align-items:center;

    padding:30px 15px;

    position:relative;

    overflow-x:hidden;
}


/* BACKGROUND GLOW */

body::before{

    content:"";

    position:fixed;

    width:500px;

    height:500px;

    background:#E88F2A;

    border-radius:50%;

    filter:blur(180px);

    opacity:.10;

    top:-300px;

    left:-250px;

    pointer-events:none;
}


body::after{

    content:"";

    position:fixed;

    width:450px;

    height:450px;

    background:#E88F2A;

    border-radius:50%;

    filter:blur(180px);

    opacity:.08;

    bottom:-250px;

    right:-220px;

    pointer-events:none;
}


/* CONTAINER */

.container{

    width:100%;

    max-width:680px;

    position:relative;

    z-index:5;
}


/* CARD */

.feedback-box{

    background:#111;

    border:1px solid #E88F2A;

    border-radius:22px;

    padding:35px;

    box-shadow:
        0 0 25px rgba(232,143,42,.25),
        0 0 60px rgba(232,143,42,.08);
}


/* LOGO */

.logo{

    text-align:center;

    color:#E88F2A;

    font-size:30px;

    font-weight:700;

    letter-spacing:4px;

    margin-bottom:5px;
}


/* TITLE */

.title{

    text-align:center;

    color:#fff;

    font-size:27px;

    font-weight:700;

    margin-bottom:7px;
}


/* SUBTITLE */

.subtitle{

    text-align:center;

    color:#888;

    font-size:14px;

    margin-bottom:25px;
}


/* LINE */

.orange-line{

    width:65px;

    height:3px;

    background:#E88F2A;

    margin:0 auto 25px;

    border-radius:10px;
}


/* MESSAGE */

.success{

    background:#0d2819;

    color:#5ee28a;

    border:1px solid #198754;

    padding:14px;

    border-radius:10px;

    text-align:center;

    font-size:14px;

    margin-bottom:20px;
}


.error{

    background:#2a0b0b;

    color:#ff7070;

    border:1px solid #dc3545;

    padding:14px;

    border-radius:10px;

    text-align:center;

    font-size:14px;

    margin-bottom:20px;
}


/* ORDER CARD */

.order-card{

    background:#181818;

    border:1px solid #333;

    border-radius:15px;

    padding:20px;

    margin-bottom:25px;
}


.order-title{

    color:#E88F2A;

    font-size:17px;

    font-weight:600;

    margin-bottom:15px;
}


.order-row{

    display:flex;

    justify-content:space-between;

    gap:20px;

    padding:11px 0;

    border-bottom:1px solid #2d2d2d;
}


.order-row:last-child{

    border-bottom:none;

    padding-bottom:0;
}


.order-label{

    color:#888;

    font-size:14px;
}


.order-value{

    color:#fff;

    font-weight:600;

    text-align:right;

    font-size:14px;
}


/* LABEL */

.form-label{

    display:block;

    color:#E88F2A;

    font-size:14px;

    font-weight:600;

    margin-bottom:8px;
}


/* INPUT */

.form-input{

    width:100%;

    height:48px;

    background:#050505;

    color:#fff;

    border:1px solid #444;

    border-radius:9px;

    padding:0 14px;

    outline:none;

    font-size:14px;

    margin-bottom:23px;

    transition:.3s;
}


.form-input::placeholder{

    color:#666;
}


.form-input:focus{

    border-color:#E88F2A;

    box-shadow:
        0 0 8px rgba(232,143,42,.25);
}


/* RATING */

.rating-heading{

    color:#E88F2A;

    font-size:17px;

    font-weight:600;

    margin-bottom:12px;
}


.rating{

    display:flex;

    flex-direction:row-reverse;

    justify-content:center;

    gap:8px;

    margin-bottom:25px;
}


.rating input{

    display:none;
}


.rating label{

    font-size:43px;

    color:#3b3b3b;

    cursor:pointer;

    transition:.2s;
}


.rating label:hover,
.rating label:hover ~ label,
.rating input:checked ~ label{

    color:#ffc107;

    text-shadow:
        0 0 10px rgba(255,193,7,.25);
}


/* REVIEW */

.review-heading{

    color:#E88F2A;

    font-size:17px;

    font-weight:600;

    margin-bottom:10px;
}


textarea{

    width:100%;

    min-height:130px;

    resize:vertical;

    background:#050505;

    color:#fff;

    border:1px solid #444;

    border-radius:10px;

    padding:14px;

    outline:none;

    font-family:inherit;

    font-size:14px;

    transition:.3s;
}


textarea::placeholder{

    color:#666;
}


textarea:focus{

    border-color:#E88F2A;

    box-shadow:
        0 0 8px rgba(232,143,42,.25);
}


/* SUBMIT */

.submit-btn{

    width:100%;

    height:52px;

    margin-top:20px;

    background:#E88F2A;

    color:#fff;

    border:none;

    border-radius:10px;

    font-size:16px;

    font-weight:700;

    cursor:pointer;

    transition:.3s;
}


.submit-btn:hover{

    background:#fff;

    color:#000;

    transform:translateY(-2px);

    box-shadow:
        0 5px 20px rgba(232,143,42,.25);
}


/* REVIEWED */

.reviewed{

    background:#181818;

    border:1px solid #333;

    border-radius:15px;

    padding:30px;

    text-align:center;
}


.reviewed-icon{

    width:70px;

    height:70px;

    margin:0 auto 15px;

    border-radius:50%;

    background:#12351f;

    border:1px solid #198754;

    display:flex;

    justify-content:center;

    align-items:center;

    color:#5ee28a;

    font-size:30px;
}


.reviewed h3{

    color:#E88F2A;

    font-size:22px;

    margin-bottom:8px;
}


.reviewed p{

    color:#888;

    font-size:14px;
}


/* BACK */

.back-btn{

    display:block;

    width:100%;

    text-align:center;

    margin-top:15px;

    padding:12px;

    border:1px solid #333;

    border-radius:10px;

    color:#aaa;

    text-decoration:none;

    font-size:14px;

    transition:.3s;
}


.back-btn:hover{

    color:#E88F2A;

    border-color:#E88F2A;

    background:#151515;
}


/* MOBILE */

@media(max-width:600px){

    body{
        padding:20px 12px;
    }

    .feedback-box{
        padding:25px 18px;
        border-radius:18px;
    }

    .logo{
        font-size:25px;
    }

    .title{
        font-size:23px;
    }

    .order-row{
        flex-direction:column;
        gap:4px;
    }

    .order-value{
        text-align:left;
    }

    .rating label{
        font-size:35px;
    }

}

</style>

</head>


<body>


<div class="container">

<div class="feedback-box">


<div class="logo">
    SWIFFIN
</div>


<div class="title">

    <i class="fa-solid fa-star"></i>
    Rate & Review

</div>


<div class="subtitle">

    Share your experience with your purchased cake

</div>


<div class="orange-line"></div>


<?php if ($message != "") { ?>

<div class="<?php echo $message_type; ?>">

    <?php echo htmlspecialchars($message); ?>

</div>

<?php } ?>


<!-- ORDER DETAILS -->

<div class="order-card">

<div class="order-title">

    <i class="fa-solid fa-receipt"></i>
    Order Details

</div>


<div class="order-row">

<span class="order-label">
    Order ID
</span>

<span class="order-value">

    #<?php echo $order_id; ?>

</span>

</div>


<div class="order-row">

<span class="order-label">
    Customer Name
</span>

<span class="order-value">

<?php
echo htmlspecialchars($customer_name);
?>

</span>

</div>


<div class="order-row">

<span class="order-label">
    Cake
</span>

<span class="order-value">

<?php
echo htmlspecialchars($cake_name);
?>

</span>

</div>


<div class="order-row">

<span class="order-label">
    Delivery Status
</span>

<span
class="order-value"
style="color:#5ee28a;"
>

    <i class="fa-solid fa-circle-check"></i>
    Delivered

</span>

</div>


</div>


<!-- REVIEW FORM -->

<?php if (!$already_reviewed) { ?>


<form method="POST" action="">


<input
type="hidden"
name="order_id"
value="<?php echo $order_id; ?>"
>


<!-- EMAIL -->

<label class="form-label">

    <i class="fa-solid fa-envelope"></i>
    Email

</label>


<input
type="email"
name="email"
class="form-input"
placeholder="Enter your email"
required
>


<!-- RATING -->

<div class="rating-heading">

    <i class="fa-solid fa-star"></i>
    Your Rating

</div>


<div class="rating">


<input
type="radio"
name="rating"
value="5"
id="star5"
required
>

<label for="star5">★</label>


<input
type="radio"
name="rating"
value="4"
id="star4"
>

<label for="star4">★</label>


<input
type="radio"
name="rating"
value="3"
id="star3"
>

<label for="star3">★</label>


<input
type="radio"
name="rating"
value="2"
id="star2"
>

<label for="star2">★</label>


<input
type="radio"
name="rating"
value="1"
id="star1"
>

<label for="star1">★</label>


</div>


<!-- REVIEW -->

<div class="review-heading">

    <i class="fa-solid fa-comment"></i>
    Your Review

</div>


<textarea
name="message"
placeholder="Write your review about this cake..."
required
></textarea>


<!-- SUBMIT -->

<button
type="submit"
name="submit_feedback"
class="submit-btn"
>

    <i class="fa-solid fa-paper-plane"></i>
    Submit Review

</button>


</form>


<?php } else { ?>


<div class="reviewed">

<div class="reviewed-icon">

    <i class="fa-solid fa-check"></i>

</div>


<h3>
    Review Submitted
</h3>


<p>
    Thank you for sharing your experience with SWIFFIN Cake Shop.
</p>


</div>


<?php } ?>


<a
href="index1.php"
class="back-btn"
>

    <i class="fa-solid fa-arrow-left"></i>
    Back to Home

</a>


</div>

</div>


</body>

</html>