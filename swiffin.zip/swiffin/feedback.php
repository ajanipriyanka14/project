
<?php

include "config.php";

$message = "";
$message_type = "";

/* ================= CHECK ORDER ID ================= */

if (!isset($_GET['order_id']) && !isset($_POST['order_id'])) {
    die("Order ID Not Found");
}

if (isset($_POST['order_id'])) {
    $order_id = intval($_POST['order_id']);
} else {
    $order_id = intval($_GET['order_id']);
}

if ($order_id <= 0) {
    die("Invalid Order ID");
}


/* ================= GET ORDER ================= */

$query = mysqli_query(
    $conn,
    "SELECT * FROM orders WHERE id='$order_id' LIMIT 1"
);

if (!$query) {
    die("Database Error: " . mysqli_error($conn));
}

if (mysqli_num_rows($query) == 0) {
    die("Order Record Not Found");
}

$order = mysqli_fetch_assoc($query);

$customer_name = $order['customer_name'];
$cake_name     = $order['cake_name'];


/* ================= CHECK ALREADY REVIEWED ================= */

$check_review = mysqli_query(
    $conn,
    "SELECT * FROM feedback
     WHERE order_id='$order_id'
     LIMIT 1"
);

$already_reviewed = false;

if ($check_review && mysqli_num_rows($check_review) > 0) {
    $already_reviewed = true;
}


/* ================= SUBMIT REVIEW ================= */

if (isset($_POST['submit_feedback']) && !$already_reviewed) {

    $rating = isset($_POST['rating'])
        ? intval($_POST['rating'])
        : 0;

    $message_text = isset($_POST['message'])
        ? trim($_POST['message'])
        : "";

    $email = isset($_POST['email'])
        ? trim($_POST['email'])
        : "";


    /* CHECK RATING */

    if ($rating < 1 || $rating > 5) {

        $message = "Please select your rating.";
        $message_type = "error";

    }

    /* CHECK REVIEW */

    elseif ($message_text == "") {

        $message = "Please write your review.";
        $message_type = "error";

    }

    else {

        /* ESCAPE DATA */

        $customer_name_safe = mysqli_real_escape_string(
            $conn,
            $customer_name
        );

        $email_safe = mysqli_real_escape_string(
            $conn,
            $email
        );

        $cake_name_safe = mysqli_real_escape_string(
            $conn,
            $cake_name
        );

        $message_safe = mysqli_real_escape_string(
            $conn,
            $message_text
        );


        /* INSERT FEEDBACK */

        $insert = mysqli_query(
            $conn,

            "INSERT INTO feedback
            (
                order_id,
                customer_name,
                email,
                cake_name,
                rating,
                message,
                feedback_date
            )
            VALUES
            (
                '$order_id',
                '$customer_name_safe',
                '$email_safe',
                '$cake_name_safe',
                '$rating',
                '$message_safe',
                NOW()
            )"
        );


        if ($insert) {

            $message =
                "Thank you! Your rating and review has been submitted successfully.";

            $message_type = "success";

            $already_reviewed = true;

        } else {

            $message =
                "Feedback Error: " . mysqli_error($conn);

            $message_type = "error";
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Rate & Review | Swiffin Cake Shop</title>


<style>

*{
    box-sizing:border-box;
}

body{

    margin:0;

    padding:0;

    background:#000;

    color:#fff;

    font-family:Arial,sans-serif;

}

.container{

    width:92%;

    max-width:650px;

    margin:60px auto;

}

.feedback-box{

    background:#111;

    border:2px solid #E88F2A;

    border-radius:25px;

    padding:35px;

    box-shadow:
    0 0 25px rgba(232,143,42,.35),
    0 0 60px rgba(232,143,42,.10);

}

.title{

    text-align:center;

    color:#E88F2A;

    font-size:32px;

    font-weight:bold;

    margin-bottom:10px;

}

.subtitle{

    text-align:center;

    color:#aaa;

    margin-bottom:30px;

}


/* ================= MESSAGE ================= */

.success{

    background:#12351f;

    border:1px solid #198754;

    color:#5ee28a;

    padding:15px;

    border-radius:10px;

    text-align:center;

    margin-bottom:20px;

}

.error{

    background:#3a1111;

    border:1px solid #dc3545;

    color:#ff6b6b;

    padding:15px;

    border-radius:10px;

    text-align:center;

    margin-bottom:20px;

}


/* ================= PRODUCT ================= */

.product-box{

    background:#1b1b1b;

    border:1px solid #333;

    border-radius:15px;

    padding:20px;

    margin-bottom:25px;

}

.product-row{

    display:flex;

    justify-content:space-between;

    padding:11px 0;

    border-bottom:1px solid #333;

}

.product-row:last-child{

    border-bottom:none;

}

.label{

    color:#999;

}

.value{

    color:#fff;

    font-weight:bold;

}


/* ================= EMAIL ================= */

.form-label{

    display:block;

    color:#E88F2A;

    font-weight:bold;

    margin-bottom:8px;

}

.email-input{

    width:100%;

    padding:13px;

    background:#1b1b1b;

    color:#fff;

    border:1px solid #444;

    border-radius:10px;

    margin-bottom:25px;

}

.email-input:focus{

    outline:none;

    border-color:#E88F2A;

}


/* ================= RATING ================= */

.rating-title{

    color:#E88F2A;

    font-size:20px;

    font-weight:bold;

    margin-bottom:15px;

}

.rating{

    display:flex;

    flex-direction:row-reverse;

    justify-content:center;

    gap:8px;

    margin-bottom:25px;

}

.rating input{

    display:none;

}

.rating label{

    font-size:45px;

    color:#444;

    cursor:pointer;

    transition:.2s;

}

.rating label:hover,

.rating label:hover ~ label,

.rating input:checked ~ label{

    color:#ffc107;

}


/* ================= REVIEW ================= */

.review-title{

    color:#E88F2A;

    font-size:20px;

    font-weight:bold;

    margin-bottom:10px;

}

textarea{

    width:100%;

    min-height:130px;

    background:#1b1b1b;

    color:#fff;

    border:1px solid #444;

    border-radius:12px;

    padding:15px;

    resize:vertical;

    outline:none;

}

textarea:focus{

    border-color:#E88F2A;

}

textarea::placeholder{

    color:#777;

}


/* ================= BUTTON ================= */

.submit-btn{

    width:100%;

    margin-top:20px;

    padding:15px;

    border:none;

    border-radius:30px;

    background:#E88F2A;

    color:#fff;

    font-size:18px;

    font-weight:bold;

    cursor:pointer;

}

.submit-btn:hover{

    background:#d67d18;

}


/* ================= REVIEWED ================= */

.reviewed{

    text-align:center;

    padding:25px;

    background:#1b1b1b;

    border-radius:15px;

    border:1px solid #333;

}

.reviewed-icon{

    font-size:50px;

    margin-bottom:10px;

}

.reviewed h3{

    color:#E88F2A;

}

.reviewed p{

    color:#aaa;

}


/* ================= MOBILE ================= */

@media(max-width:600px){

    .feedback-box{

        padding:25px 20px;

    }

    .title{

        font-size:27px;

    }

    .rating label{

        font-size:36px;

    }

    .product-row{

        flex-direction:column;

        gap:5px;

    }

}

</style>

</head>


<body>


<div class="container">

<div class="feedback-box">


<div class="title">

⭐ Rate & Review

</div>


<div class="subtitle">

Share your experience with your purchased cake

</div>


<?php

if ($message != "") {

?>

<div class="<?php echo $message_type; ?>">

<?php

echo htmlspecialchars($message);

?>

</div>

<?php

}

?>


<!-- ================= PRODUCT DETAILS ================= -->

<div class="product-box">


<div class="product-row">

<span class="label">
Order ID
</span>

<span class="value">

#<?php echo $order_id; ?>

</span>

</div>


<div class="product-row">

<span class="label">
Customer Name
</span>

<span class="value">

<?php

echo htmlspecialchars(
    $customer_name
);

?>

</span>

</div>


<div class="product-row">

<span class="label">
Cake
</span>

<span class="value">

<?php

echo htmlspecialchars(
    $cake_name
);

?>

</span>

</div>


</div>


<?php

if (!$already_reviewed) {

?>


<form method="POST">


<input
type="hidden"
name="order_id"
value="<?php echo $order_id; ?>"
>


<!-- ================= EMAIL ================= -->

<label class="form-label">

Email

</label>

<input
type="email"
name="email"
class="email-input"
placeholder="Enter your email"
required
>


<!-- ================= RATING ================= -->

<div class="rating-title">

⭐ Your Rating

</div>


<div class="rating">


<input
type="radio"
name="rating"
value="5"
id="star5"
required
>

<label for="star5">★</label>


<input
type="radio"
name="rating"
value="4"
id="star4"
>

<label for="star4">★</label>


<input
type="radio"
name="rating"
value="3"
id="star3"
>

<label for="star3">★</label>


<input
type="radio"
name="rating"
value="2"
id="star2"
>

<label for="star2">★</label>


<input
type="radio"
name="rating"
value="1"
id="star1"
>

<label for="star1">★</label>


</div>


<!-- ================= REVIEW ================= -->

<div class="review-title">

Your Review

</div>


<textarea
name="message"
placeholder="Write your review about this cake..."
required
></textarea>


<!-- ================= SUBMIT ================= -->

<button
type="submit"
name="submit_feedback"
class="submit-btn"
>

⭐ Submit Review

</button>


</form>


<?php

}
else {

?>


<div class="reviewed">

<div class="reviewed-icon">

✅

</div>

<h3>

Review Submitted

</h3>

<p>

Thank you for reviewing this cake!

</p>

</div>


<?php

}

?>


</div>

</div>


</body>

</html>

