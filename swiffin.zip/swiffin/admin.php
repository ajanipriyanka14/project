<?php
session_start();

$error = "";

if (isset($_POST['login'])) {

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Admin Login Details
    $admin_name = "Admin";
    $admin_email = "admin@gmail.com";
    $admin_password = "admin";

    if (
        $name === $admin_name &&
        $email === $admin_email &&
        $password === $admin_password
    ) {

        // Store Admin Details in Session
        $_SESSION['admin'] = $email;
        $_SESSION['admin_name'] = $name;

        // Open Dashboard
        header("Location: admin_dashboard.php");
        exit();

    } else {

        $error = "Invalid Name, Email or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Admin Login | Swiffin Cake Shop</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #000;
            min-height: 100vh;

            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Login Box */

        .login-box {
            width: 400px;
            background: #111;

            padding: 40px;

            border-radius: 15px;

            border: 1px solid #333;

            box-shadow:
                0 0 15px rgba(232, 143, 42, 0.3),
                0 0 35px rgba(232, 143, 42, 0.15);
        }

        /* Logo */

        .logo {
            text-align: center;

            color: #E88F2A;

            font-size: 34px;

            font-weight: bold;

            letter-spacing: 2px;

            margin-bottom: 8px;
        }

        /* Title */

        .title {
            text-align: center;

            color: #fff;

            font-size: 22px;

            font-weight: bold;

            margin-bottom: 30px;
        }

        /* Error */

        .error {
            background: #2b0000;

            color: #ff5555;

            border: 1px solid #ff3333;

            padding: 12px;

            border-radius: 6px;

            text-align: center;

            margin-bottom: 20px;

            font-size: 14px;
        }

        /* Label */

        label {
            display: block;

            color: #fff;

            font-size: 15px;

            font-weight: bold;

            margin-bottom: 8px;
        }

        /* Input */

        input[type="text"],
        input[type="email"],
        input[type="password"] {

            width: 100%;

            height: 48px;

            padding: 0 14px;

            background: #000;

            color: #fff;

            border: 1px solid #444;

            border-radius: 6px;

            outline: none;

            font-size: 15px;

            margin-bottom: 20px;
        }

        input::placeholder {
            color: #777;
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus {

            border-color: #E88F2A;

            box-shadow:
                0 0 6px rgba(232, 143, 42, 0.3);
        }

        /* Login Button */

        input[type="submit"] {

            width: 100%;

            height: 48px;

            background: #E88F2A;

            color: #fff;

            border: none;

            border-radius: 6px;

            font-size: 17px;

            font-weight: bold;

            cursor: pointer;

            transition: 0.3s;
        }

        input[type="submit"]:hover {

            background: #fff;

            color: #000;

            box-shadow:
                0 0 15px rgba(232, 143, 42, 0.5);
        }

        /* Back */

        .back {
            text-align: center;

            margin-top: 25px;
        }

        .back a {

            color: #E88F2A;

            text-decoration: none;

            font-size: 14px;
        }

        .back a:hover {

            color: #fff;

            text-decoration: underline;
        }

        /* Mobile */

        @media (max-width: 500px) {

            .login-box {
                width: 90%;
                padding: 30px 25px;
            }

            .logo {
                font-size: 28px;
            }

            .title {
                font-size: 20px;
            }
        }

    </style>

</head>

<body>

<div class="login-box">

    <!-- Logo -->

    <div class="logo">
        SWIFFIN
    </div>

    <!-- Title -->

    <div class="title">
        Admin Login
    </div>

    <!-- Error -->

    <?php if ($error != "") { ?>

        <div class="error">
            <?php echo htmlspecialchars($error); ?>
        </div>

    <?php } ?>

    <!-- Form -->

    <form method="POST" action="">

        <!-- Name -->

        <label>Admin Name</label>

        <input
            type="text"
            name="name"
            placeholder="Enter Admin Name"
            required
        >

        <!-- Email -->

        <label>Admin Email</label>

        <input
            type="email"
            name="email"
            placeholder="Enter Admin Email"
            required
        >

        <!-- Password -->

        <label>Admin Password</label>

        <input
            type="password"
            name="password"
            placeholder="Enter Admin Password"
            required
        >

        <!-- Login -->

        <input
            type="submit"
            name="login"
            value="Login"
        >

    </form>

    <!-- Back Home -->

    <div class="back">

        <a href="index.php">
            ← Back to Home
        </a>

    </div>

</div>

</body>

</html>

