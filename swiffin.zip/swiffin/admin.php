<?php
session_start();
include("config.php");

if(isset($_POST['login']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM admin WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result) > 0)
    {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['admin'] = $row['name'];
        header("Location: admin_dashboard.php");
        exit();
    }
    else
    {
        $error = "Invalid Email or Password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
</head>
<body>

<h2 align="center">Admin Login</h2>

<form method="post" align="center">

    <input type="email" name="email" placeholder="Enter Email" required><br><br>

    <input type="password" name="password" placeholder="Enter Password" required><br><br>

    <input type="submit" name="login" value="Login">

</form>

<?php
if(isset($error))
{
    echo "<p align='center' style='color:red;'>$error</p>";
}
?>

</body>
</html>