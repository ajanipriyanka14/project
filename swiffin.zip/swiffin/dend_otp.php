<?php
include "config.php";

$customer_name = $_POST['customer_name'];
$email = $_POST['email'];
$cake_name = $_POST['cake_name'];
$quantity = $_POST['quantity'];
$price = $_POST['price'];
$otp = $_POST['otp'];

$total = $quantity * $price;
$otp_status = "Verified";

$query = "INSERT INTO cart
(customer_name,email,cake_name,quantity,price,total,otp,otp_status)
VALUES
('$customer_name','$email','$cake_name','$quantity','$price','$total','$otp','$otp_status')";

mysqli_query($conn,$query);
echo "Cart Added Successfully";
?>