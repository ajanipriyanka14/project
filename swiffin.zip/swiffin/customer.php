<?php
include "config.php";

if(isset($_POST['submit']))
{
    $customer_name = $_POST['customer_name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];

    $query = "INSERT INTO customer(customer_name,email,mobile,address)
              VALUES('$customer_name','$email','$mobile','$address')";

    if(mysqli_query($conn,$query))
    {
        echo "<script>alert('Customer Added Successfully');</script>";
    }
    else
    {
        echo "Error : ".mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer | Swiffin Cake Shop</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

    body{
        background:#000;
        font-family:Arial, sans-serif;
    }

    .customer-box{
        max-width:600px;
        margin:60px auto;
        background:#1b1b1b;
        padding:35px;
        border-radius:20px;
        box-shadow:0 0 20px rgba(232,143,42,.35);
    }

    h2{
        color:#E88F2A;
        text-align:center;
        margin-bottom:30px;
        font-weight:bold;
    }

    label{
        color:#fff;
        font-weight:bold;
    }

    .form-control{
        background:#2b2b2b;
        border:1px solid #555;
        color:#fff;
    }

    .form-control:focus{
        background:#2b2b2b;
        color:#fff;
        border-color:#E88F2A;
        box-shadow:none;
    }

    textarea{
        resize:none;
    }

    .btn-save{
        width:100%;
        background:#E88F2A;
        color:#fff;
        font-weight:bold;
        border:none;
        padding:12px;
        border-radius:30px;
    }

    .btn-save:hover{
        background:#d67d18;
    }

    </style>

</head>

<body>

<div class="container">

<div class="customer-box">

<h2>Customer Details</h2>

<form method="post">

<div class="mb-3">
<label>Customer Name</label>
<input type="text" name="customer_name" class="form-control" required>
</div>

<div class="mb-3">
<label>Email</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="mb-3">
<label>Mobile</label>
<input type="text" name="mobile" maxlength="10" class="form-control" required>
</div>

<div class="mb-3">
<label>Address</label>
<textarea name="address" rows="4" class="form-control" required></textarea>
</div>

<button type="submit" name="submit" class="btn btn-save">
Save Customer
</button>

</form>

</div>

</div>

</body>
</html>