<?php
session_start();

if(isset($_POST['otp']))
{
    $enter_otp = $_POST['otp'];

    if(isset($_SESSION['otp']))
    {
        if($enter_otp == $_SESSION['otp'])
        {
            echo "OTP Verified";
        }
        else
        {
            echo "Invalid OTP";
        }
    }
    else
    {
        echo "OTP Not Generated";
    }
}
else
{
    echo "OTP Required";
}

?>