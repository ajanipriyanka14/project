<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>About</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Oswald:wght@500;600;700&family=Pacifico&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<style>
<body>
{
	margin:0;
	padding:0;
}
.container-fluid
{
	margin-top:0!important;
	padding:0!important;
}


</style>
    <!-- Topbar Start -->

	<div class="container-fluid px-5">
    <div class="row align-items-center">

        <!-- Welcome Left -->
        <div class="col-lg-2">
            <h5 class="m-1 fw-bold">
			<?php
			if(isset($_SESSION['name'])){
               echo "Welcome ". $_SESSION['name']; 
			}
			else
			{
				echo "welcome";
			}
			?>		
            </h5>
        </div>

     <!-- SWIFFIN Center -->
<div class="col-lg-5 text-center  py-2">
    <a href="index1.php" class="navbar-brand d-flex justify-content-center align-items-center">
        <img src="img/logo.png" alt="Logo" width="60" height="60" >
        <h1 class="m-0  ms-2 text-uppercase ">
		<span style ="color:#ff9800;">SWIFFIN</span>
		</h1>
    </a>
</div>
        <!-- CALL US Right -->
        <div class="col-lg-4 text-end">
            <div class="d-inline-flex align-items-center ">
                <i class="bi bi-phone-vibrate fs-1 text-primary me-3"></i>
                <div class="text-start">
                    <h6 class="text-uppercase mb-1">CALL US</h6>
                    <span>+91 9876543210</span>
                </div>
            </div>
        </div>

    </div>
</div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm sticky-top py-3">
    <div class="container">

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbar">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a href="index1.php" class="nav-link ">Home</a></li>
                <li class="nav-item"><a href="about.php" class="nav-link active">About</a></li>
                <li class="nav-item"><a href="product.php" class="nav-link">Cakes</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link">Gallery</a></li>
                <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
                <li class="nav-item"><a href="login.php" class="btn btn-primary rounded-circle ms-3 px-4">Login</a></li>
				<li class="nav-item"><a href="register.php" class="btn btn-primary  rounded-circle ms-3 px-4">Register</a></li>
				<li class="nav-item"><a href="admin.php" class="btn btn-primary rounded-circle  ms-3 px-4">Admin</a></li>
				<li class="nav-item"><a href="logout.php" class="btn btn-primary rounded-circle ms-3 px-4">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
    <!-- Navbar End -->


<!-- Hero -->

<section class="hero">

<div class="container">

<h1>About Swiffin Cake Shop</h1>

<p>
Freshly Baked Happiness for Every Celebration
</p>

<a href="product.php" class="btn btn-primary rounded-circle ms-3 px-4 shop">
Order Now
</a>

</div>

</section>

<!-- About -->

<section class="py-5">

<div class="container">

<div class="row align-items-center">

<div class="col-lg-6">

<img src="img/about.jpg"
class="img-fluid about-img">

</div>

<div class="col-lg-6">

<h5 class="text-warning">
WELCOME TO SWIFFIN
</h5>

<h2 class="section-title mb-4">
We Bake Happiness Every Day
</h2>

<p class="text-muted">

Swiffin Cake Shop is passionate about creating
beautiful and delicious cakes for birthdays,
anniversaries, weddings and every special occasion.
Our expert bakers use only premium ingredients to
deliver unforgettable taste and quality.

</p>

<div class="feature-box">

<i class="fas fa-cake-candles"></i>

<h5>Premium Quality Cakes</h5>

<p>
Freshly baked using high-quality ingredients.
</p>

</div>

<div class="feature-box">

<i class="fas fa-truck"></i>

<h5>Fast Home Delivery</h5>

<p>
Quick and safe delivery at your doorstep.
</p>

</div>

</div>

</div>

</div>

</section>

<!-- Bootstrap -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Why Choose Us Start -->
<section class="py-5 bg-light">
    <div class="container">

        <div class="text-center mb-5">
            <h5 class="text-warning fw-bold">WHY CHOOSE US</h5>
            <b class="display-5 fw-bold">Why Customers Love Swiffin</b>
            <p class="text-muted">
                Freshly baked cakes made with love for every special moment.
            </p>
        </div>

        <div class="row g-4">

            <!-- Card 1 -->
            <div class="col-lg-4 col-md-6">
                <div class="card border-0 shadow-lg h-100 text-center p-3">
                    <img src="img/fresh.jpg" class="img-fluid mx-auto mb-3"
                        style="width:150px;height:150px;object-fit:contain;">

                    <h4 class="fw-bold">Freshly Baked</h4>

                    <p class="text-muted">
                        Every cake is baked daily using premium ingredients for
                        delicious taste and perfect softness.
                    </p>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="col-lg-4 col-md-6">
                <div class="card border-0 shadow-lg h-100 text-center p-3">
                    <img src="img/custom.jpg" class="img-fluid mx-auto mb-3"
                        style="width:150px;height:150px;object-fit:contain;">

                    <h4 class="fw-bold">Custom Designs</h4>

                    <p class="text-muted">
                        Birthday, Anniversary, Wedding or Theme Cakes
                        customized exactly as you imagine.
                    </p>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="col-lg-4 col-md-6 mx-auto">
                <div class="card border-0 shadow-lg h-100 text-center p-3">
                    <img src="img/fast.jpg" class="img-fluid mx-auto mb-3"
                        style="width:150px;height:150px;object-fit:contain;">

                    <h4 class="fw-bold">Fast Delivery</h4>

                    <p class="text-muted">
                        Fresh cakes delivered safely to your doorstep with
                        secure packaging and on-time service.
                    </p>
                </div>
            </div>

        </div>

    </div>
</section>
<!-- Why Choose Us End -->

<!-- Statistics Start -->
<section class="py-5">
    <div class="container">

        <div class="row g-4">

            <div class="col-md-3">
                <div class="feature-box text-center">
                    <h2 class="text-warning fw-bold">5000+</h2>
                    <h5>Happy Customers</h5>
                </div>
            </div>

            <div class="col-md-3">
                <div class="feature-box text-center">
                    <h2 class="text-warning fw-bold">250+</h2>
                    <h5>Cake Designs</h5>
                </div>
            </div>

            <div class="col-md-3">
                <div class="feature-box text-center">
                    <h2 class="text-warning fw-bold">10+</h2>
                    <h5>Years Experience</h5>
                </div>
            </div>

            <div class="col-md-3">
                <div class="feature-box text-center">
                    <h2 class="text-warning fw-bold">4.9 ★</h2>
                    <h5>Customer Rating</h5>
                </div>
            </div>

        </div>

    </div>
</section>
<!-- Statistics End -->

<!-- Our Services Start -->
<section class="py-5 bg-light">
    <div class="container">

        <div class="text-center mb-5">
            <h5 class="text-warning fw-bold">OUR SERVICES</h5>
            <b class="display-5 fw-bold">What We Offer</b>
            <p class="text-muted">
                We create delicious cakes and desserts for every celebration with
                premium quality and timely delivery.
            </p>
        </div>

        <div class="row g-4">

            <div class="col-lg-4 col-md-6">
                <div class="service-box text-center p-4">
                    <img src="img/Birthday.png" class="img-fluid mb-3 service-img" alt="">
                     <b style="color:#E88F2A;">Birthday Cakes</b>
                    <p>Beautiful birthday cakes with custom themes and fresh flavors.</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="service-box text-center p-4">
                    <img src="img/wedding-cake.png" class="img-fluid mb-3 service-img" alt="">
                   <b style="color:#E88F2A;">Wedding Cakes</b>
                    <p>Elegant multi-tier wedding cakes designed for your special day.</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="service-box text-center p-4">
                    <img src="img/chocolate-cake.png" class="img-fluid mb-3 service-img" alt="">
                     <b style="color:#E88F2A;">Chocolate Cakes</b>
                    <p>Rich chocolate cakes made with premium cocoa ingredients.</p>
                </div>
            </div>

        </div>

    </div>
</section>
<!-- Our Services End -->
<!-- Our Bakers End -->
</body>
</html>