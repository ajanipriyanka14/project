
<?php
session_start();
include("config.php");

/* =====================================================
   CUSTOMER SESSION
===================================================== */

$customer_logged_in = false;
$customer_name = "";
$customer_email = "";

if (
    isset($_SESSION['customer']) &&
    $_SESSION['customer'] === true
) {
    $customer_logged_in = true;

    $customer_name = $_SESSION['customer_name'] ?? "";
    $customer_email = $_SESSION['customer_email'] ?? "";
}


/* =====================================================
   CATEGORY DATA
===================================================== */

$parent_categories = [];

$cat_sql = "
    SELECT *
    FROM category
    WHERE parent_id = 0
    AND status = 'Active'
    ORDER BY category_name ASC
";

$cat_result = mysqli_query($conn, $cat_sql);

if ($cat_result) {
    while ($cat = mysqli_fetch_assoc($cat_result)) {
        $parent_categories[] = $cat;
    }
}


/* =====================================================
   SUB CATEGORIES
===================================================== */

function getSubCategoriesAbout($conn, $parent_id)
{
    $sub_categories = [];

    $parent_id = intval($parent_id);

    $sql = "
        SELECT *
        FROM category
        WHERE parent_id = $parent_id
        AND status = 'Active'
        ORDER BY category_name ASC
    ";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $sub_categories[] = $row;
        }
    }

    return $sub_categories;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <title>About - SWIFFIN Cake Shop</title>

    <meta
        content="width=device-width, initial-scale=1.0"
        name="viewport"
    >

    <meta
        content="SWIFFIN Cake Shop"
        name="keywords"
    >

    <meta
        content="Fresh and delicious cakes"
        name="description"
    >

    <link href="img/favicon.ico" rel="icon">

    <!-- Google Fonts -->

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
        crossorigin
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Oswald:wght@500;600;700&family=Pacifico&display=swap"
        rel="stylesheet"
    >

    <!-- Font Awesome -->

    <link
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <!-- Owl Carousel -->

    <link
        href="lib/owlcarousel/assets/owl.carousel.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap -->

    <link
        href="css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Main CSS -->

    <link
        href="css/style.css"
        rel="stylesheet"
    >


<style>

/* =====================================================
   GLOBAL
===================================================== */

html {
    scroll-behavior: smooth;
}

body {
    margin: 0;
    padding: 0;
    color: #fff;
    font-family:
        "Open Sans",
        Arial,
        Helvetica,
        sans-serif;
}

.container-fluid {
    margin-top: 0 !important;
}


/* =====================================================
   COLORS
===================================================== */

:root {
    --orange: #E88F2A;
    --orange-dark: #d67d18;
    --black: #111111;
    --dark: #181818;
    --light: #FAF3EB;
}


/* =====================================================
   TOPBAR
===================================================== */

.topbar {
    background: #fff !important;
}

.topbar h6 {
    color: #222 !important;
}

.topbar span {
    color: #222 !important;
}

.topbar .navbar-brand {
    text-decoration: none;
}


/* =====================================================
   WELCOME USER
===================================================== */

.welcome-user {
    display: flex;
    align-items: center;
    gap: 10px;
}

.user-icon {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background: var(--orange);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    box-shadow:
        0 4px 12px rgba(232,143,42,0.30);
}

.welcome-text {
    display: flex;
    flex-direction: column;
    line-height: 1.2;
}

.welcome-text small {
    color: #888;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.welcome-text strong {
    color: #222;
    font-size: 14px;
    max-width: 140px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}


/* =====================================================
   GUEST
===================================================== */

.welcome-guest {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #555;
    font-weight: 600;
}

.welcome-guest i {
    font-size: 28px;
    color: var(--orange);
}


/* =====================================================
   NAVBAR
===================================================== */

.navbar {
    background: #fff !important;
}

.navbar .nav-link {
    color: #222 !important;
    font-weight: 900 !important;
    -webkit-text-stroke: 0.4px #222;
    transition: 0.3s;
}

.navbar .nav-link:hover {
    color: var(--orange) !important;
    -webkit-text-stroke: 0.4px var(--orange);
}

.navbar .nav-link.active {
    color: var(--orange) !important;
    font-weight: 900 !important;
    -webkit-text-stroke: 0.4px var(--orange);
}

.navbar-nav .nav-link {
    font-weight: 900 !important;
}


/* =====================================================
   CAKES DROPDOWN BUTTON
===================================================== */

.cakes-main-link {
    padding-right: 2px !important;
    font-weight: 900 !important;
}

.cakes-dropdown-btn {
    padding-left: 2px !important;
    font-weight: 900 !important;
}


/* =====================================================
   CATEGORY DROPDOWN
===================================================== */

.dropdown-submenu {
    position: relative;
}

.dropdown-submenu > .dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: 0;
    display: none;
}

.dropdown-submenu:hover > .dropdown-menu {
    display: block;
}

.dropdown-menu {
    min-width: 220px;
    border: none;
    border-radius: 10px;
    box-shadow:
        0 10px 30px rgba(0,0,0,0.15);
}

.dropdown-item {
    padding: 10px 15px;
    font-size: 14px;
    font-weight: 800 !important;
}

.dropdown-item:hover {
    color: var(--orange);
    background: var(--light);
}


/* =====================================================
   USER DROPDOWN
===================================================== */

.user-dropdown {
    position: relative;
}

.user-dropdown-btn {
    border: none;
    background: transparent;
    display: flex;
    align-items: center;
    gap: 8px;
    color: #222;
    font-weight: 900 !important;
    -webkit-text-stroke: 0.3px #222;
    cursor: pointer;
    padding: 7px 12px;
    border-radius: 25px;
    transition: 0.3s;
}

.user-dropdown-btn:hover {
    background: #FAF3EB;
    color: #E88F2A;
}

.user-dropdown-btn i {
    color: #E88F2A;
    font-size: 20px;
}


/* =====================================================
   USER MENU
===================================================== */

.user-menu {
    min-width: 220px;
    padding: 10px;
    border: none;
    border-radius: 12px;
    box-shadow:
        0 8px 25px rgba(0,0,0,0.15);
}

.user-menu .user-info {
    padding: 12px;
    border-bottom: 1px solid #eee;
    margin-bottom: 5px;
}

.user-menu .user-info strong {
    display: block;
    color: #222;
    font-size: 15px;
}

.user-menu .user-info small {
    color: #888;
    font-size: 12px;
    word-break: break-all;
}

.user-menu .dropdown-item {
    border-radius: 7px;
    padding: 10px 12px;
    font-size: 14px;
    font-weight: 800 !important;
}

.user-menu .dropdown-item:hover {
    background: #FAF3EB;
    color: #E88F2A;
}

.user-menu .logout-item {
    color: #dc3545;
}

.user-menu .logout-item:hover {
    background: #fff0f0;
    color: #dc3545;
}


/* =====================================================
   CART
===================================================== */

.cart-link {
    display: inline-flex !important;
    align-items: center;
    gap: 6px;
    font-weight: 900 !important;
}

.cart-link i {
    font-size: 18px;
    color: #E88F2A;
}


/* =====================================================
   SIGN IN
===================================================== */

.signin-btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: #E88F2A !important;
    color: #fff !important;
    border-radius: 25px !important;
    padding: 9px 18px !important;
    font-weight: 900 !important;
    -webkit-text-stroke: 0.3px #fff;
    border: 1px solid #E88F2A !important;
    transition: 0.3s;
}

.signin-btn:hover {
    background: #fff !important;
    color: #E88F2A !important;
    -webkit-text-stroke: 0.3px #E88F2A;
}


/* =====================================================
   REGISTER
===================================================== */

.register-btn {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    border: 1px solid #E88F2A !important;
    color: #E88F2A !important;
    background: #fff !important;
    border-radius: 25px !important;
    padding: 9px 18px !important;
    font-weight: 900 !important;
    -webkit-text-stroke: 0.3px #E88F2A;
    transition: 0.3s;
}

.register-btn:hover {
    background: #E88F2A !important;
    color: #fff !important;
    -webkit-text-stroke: 0.3px #fff;
}


/* =====================================================
   ABOUT HERO
===================================================== */

.about-hero {
    position: relative;
    min-height: 420px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;

    background:
        linear-gradient(
            rgba(0,0,0,0.72),
            rgba(0,0,0,0.72)
        ),
        url("img/hero.jpg") center/cover no-repeat;

    overflow: hidden;
}

.about-hero::before {
    content: "";
    position: absolute;
    width: 320px;
    height: 320px;
    border: 1px solid rgba(232,143,42,0.35);
    border-radius: 50%;
    top: -160px;
    left: -160px;
}

.about-hero::after {
    content: "";
    position: absolute;
    width: 260px;
    height: 260px;
    border: 1px solid rgba(232,143,42,0.30);
    border-radius: 50%;
    bottom: -130px;
    right: -130px;
}

.about-hero-overlay {
    width: 100%;
    padding: 80px 20px;
    position: relative;
    z-index: 2;
}

.about-hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    color: #E88F2A;
    font-size: 14px;
    font-weight: 900;
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-bottom: 18px;
}

.about-hero-title {
    color: #fff;
    font-size: 58px;
    font-weight: 900;
    margin: 0;
    letter-spacing: 1px;
}

.about-hero-title span {
    color: #E88F2A;
}

.about-hero-text {
    color: #eee;
    font-size: 19px;
    margin: 18px 0;
    letter-spacing: 0.5px;
}

.about-hero-divider {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    margin-bottom: 28px;
}

.about-hero-divider span {
    width: 45px;
    height: 2px;
    background: #E88F2A;
    border-radius: 10px;
}

.about-hero-divider i {
    color: #E88F2A;
    font-size: 15px;
}

.about-order-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 13px 28px;
    background: #E88F2A;
    color: #fff;
    text-decoration: none;
    border-radius: 30px;
    font-size: 15px;
    font-weight: 900;
    transition: 0.3s;
    box-shadow:
        0 8px 22px rgba(232,143,42,0.25);
}

.about-order-btn:hover {
    background: #fff;
    color: #000;
    transform: translateY(-3px);
}


/* =====================================================
   ABOUT SWIFFIN
===================================================== */

.swiffin-about {
    padding: 90px 0;
    background: #000;
}

.about-image-wrap {
    position: relative;
    padding: 15px;
}

.about-main-image {
    width: 100%;
    height: 500px;
    object-fit: cover;
    display: block;
    border-radius: 25px;
    box-shadow:
        0 15px 40px rgba(0,0,0,0.55);
}

.about-image-wrap::before {
    content: "";
    position: absolute;
    width: 90px;
    height: 90px;
    top: 0;
    left: 0;
    border-top: 4px solid #E88F2A;
    border-left: 4px solid #E88F2A;
    border-radius: 12px 0 0 0;
    z-index: 2;
}

.about-image-wrap::after {
    content: "";
    position: absolute;
    width: 90px;
    height: 90px;
    bottom: 0;
    right: 0;
    border-bottom: 4px solid #E88F2A;
    border-right: 4px solid #E88F2A;
    border-radius: 0 0 12px 0;
    z-index: 2;
}

.about-floating-card {
    position: absolute;
    left: -10px;
    bottom: 45px;
    display: flex;
    align-items: center;
    gap: 12px;
    background: #fff;
    color: #000;
    padding: 12px 20px;
    border-radius: 50px;
    box-shadow:
        0 10px 30px rgba(0,0,0,0.45);
    z-index: 5;
}

.about-floating-icon {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background: #E88F2A;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    flex-shrink: 0;
}

.about-floating-icon img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.about-floating-card strong {
    display: block;
    color: #111;
    font-size: 14px;
    font-weight: 900;
}

.about-floating-card small {
    display: block;
    color: #777;
    font-size: 11px;
}

.about-corner-box {
    position: absolute;
    top: 30px;
    right: 30px;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: #E88F2A;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
    box-shadow:
        0 6px 18px rgba(0,0,0,0.35);
    z-index: 5;
}


/* =====================================================
   ABOUT CONTENT
===================================================== */

.about-content {
    padding-left: 20px;
}

.about-small-title {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #E88F2A;
    font-size: 14px;
    font-weight: 900;
    letter-spacing: 2px;
    margin-bottom: 14px;
}

.about-small-title span {
    width: 35px;
    height: 3px;
    background: #E88F2A;
    border-radius: 10px;
}

.about-content h2 {
    color: #fff;
    font-size: 44px;
    line-height: 1.2;
    font-weight: 900;
    margin-bottom: 20px;
}

.about-content h2 span {
    color: #E88F2A;
}

.about-description {
    color: #aaa;
    font-size: 15px;
    line-height: 1.8;
    margin-bottom: 28px;
}


/* =====================================================
   FEATURES
===================================================== */

.about-features {
    display: flex;
    flex-direction: column;
    gap: 14px;
}

.about-feature {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    background: #111;
    border: 1px solid #292929;
    border-radius: 14px;
    transition: 0.3s;
}

.about-feature:hover {
    background: #1b1b1b;
    border-color: #E88F2A;
    transform: translateX(7px);
    box-shadow:
        0 8px 20px rgba(232,143,42,0.12);
}

.feature-icon {
    flex-shrink: 0;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: #E88F2A;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.about-feature h5 {
    margin: 0 0 4px;
    color: #fff;
    font-weight: 900;
    font-size: 16px;
}

.about-feature p {
    margin: 0;
    color: #999;
    font-size: 13px;
    line-height: 1.5;
}


/* =====================================================
   ABOUT BUTTON
===================================================== */

.about-shop-btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin-top: 28px;
    padding: 13px 25px;
    background: #E88F2A;
    color: #fff;
    text-decoration: none;
    border-radius: 30px;
    font-weight: 900;
    font-size: 14px;
    transition: 0.3s;
    box-shadow:
        0 8px 20px rgba(232,143,42,0.20);
}

.about-shop-btn:hover {
    background: #fff;
    color: #000;
    transform: translateY(-3px);
}


/* =====================================================
   FEATURE BOX
===================================================== */

.feature-box {
    background: #000 !important;
    border-radius: 18px;
    padding: 30px 20px;
    min-height: 140px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    transition: 0.3s;
}

.feature-box:hover {
    transform: translateY(-5px);
    box-shadow:
        0 10px 25px rgba(0,0,0,0.25);
}

.feature-box h2 {
    color: #E88F2A !important;
    margin-bottom: 8px;
}

.feature-box h5 {
    color: #fff !important;
    margin: 0;
    font-weight: 900;
}


/* =====================================================
   SERVICE BOX
===================================================== */

.service-box {
    background: #000 !important;
    border-radius: 18px;
    padding: 25px !important;
    transition: 0.3s;
}

.service-box:hover {
    transform: translateY(-5px);
    box-shadow:
        0 10px 25px rgba(0,0,0,0.25);
}

.service-box p {
    color: #ccc;
}

.service-box h5 {
    color: #E88F2A !important;
    font-weight: 900 !important;
}


/* =====================================================
   BACK TO TOP
===================================================== */

.back-to-top:hover {
    background: #fff !important;
    color: #000 !important;
    transform: translateY(-5px);
    box-shadow:
        0 8px 20px rgba(232,143,42,0.45);
}


/* =====================================================
   MOBILE
===================================================== */

@media(max-width:991px) {

    .swiffin-about {
        padding: 65px 0;
    }

    .about-main-image {
        height: 420px;
    }

    .about-content {
        padding-left: 0;
    }

    .about-content h2 {
        font-size: 37px;
    }
}

@media(max-width:700px) {

    .topbar {
        padding: 10px 0;
    }

    .topbar-left {
        padding-left: 15px;
        margin-bottom: 10px;
    }

    .topbar-logo {
        margin-bottom: 10px;
    }

    .topbar-call {
        justify-content: flex-start;
        padding-left: 15px;
        padding-right: 15px;
    }

    .hero h1 {
        font-size: 38px;
    }

    .hero p {
        font-size: 16px;
    }

    .welcome-user {
        margin-bottom: 10px;
    }
}

@media(max-width:576px) {

    .about-main-image {
        height: 320px;
    }

    .about-floating-card {
        left: 0;
        bottom: 25px;
    }

    .about-content h2 {
        font-size: 31px;
    }

    .about-description {
        font-size: 14px;
    }

}


/* =====================================================
   FINAL BOLD FIX
   ALL NAVBAR TEXT
===================================================== */

.navbar a,
.navbar button,
.navbar .nav-link,
.navbar .cart-link,
.navbar .signin-btn,
.navbar .register-btn,
.navbar .user-dropdown-btn {
    font-weight: 900 !important;
}

</style>

</head>


<body>


<!-- =====================================================
     TOPBAR
===================================================== -->

<div class="container-fluid px-5">

    <div class="row align-items-center">

        <!-- WELCOME -->

        <div class="col-lg-3">

            <?php if ($customer_logged_in) { ?>

                <div class="welcome-user">

                    <div class="user-icon">
                        <i class="fas fa-user"></i>
                    </div>

                    <div class="welcome-text">

                        <small>
                            Welcome
                        </small>

                        <strong>
                            <?php
                            echo htmlspecialchars($customer_name);
                            ?>
                        </strong>

                    </div>

                </div>

            <?php } else { ?>

                <div class="welcome-guest">

                    <i class="fas fa-user-circle"></i>

                    <span>
                        Welcome Guest
                    </span>

                </div>

            <?php } ?>

        </div>


        <!-- LOGO -->

        <div class="col-lg-5 text-center py-2">

            <a
                href="index1.php"
                class="navbar-brand d-flex justify-content-center align-items-center"
            >

                <img
                    src="img/logo.png"
                    alt="SWIFFIN Logo"
                    width="60"
                    height="60"
                >

                <h1 class="m-0 ms-2 text-uppercase">

                    <span style="color:#ff9800;">
                        SWIFFIN
                    </span>

                </h1>

            </a>

        </div>


        <!-- CALL -->

        <div class="col-lg-4 text-end pe-4">

            <div class="d-inline-flex align-items-center">

                <i
                    class="bi bi-phone-vibrate fs-1 text-primary me-3"
                ></i>

                <div class="text-start">

                    <h6 class="text-uppercase mb-1">
                        CALL US
                    </h6>

                    <span
                        style="
                            color:#222 !important;
                            display:block !important;
                        "
                    >
                        +91 9876543210
                    </span>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =====================================================
     NAVBAR
===================================================== -->

<nav
    class="navbar navbar-expand-lg bg-white navbar-light shadow-sm sticky-top py-3"
>

    <div class="container">

        <!-- MOBILE BUTTON -->

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbar"
            aria-controls="navbar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >

            <span class="navbar-toggler-icon"></span>

        </button>


        <!-- NAVBAR -->

        <div
            class="collapse navbar-collapse"
            id="navbar"
        >

            <ul class="navbar-nav ms-auto align-items-center">


                <!-- HOME -->

                <li class="nav-item">

                    <a
                        href="index1.php"
                        class="nav-link fw-bold"
                    >
                        Home
                    </a>

                </li>


                <!-- ABOUT -->

                <li class="nav-item">

                    <a
                        href="about.php"
                        class="nav-link active fw-bold"
                    >
                        About
                    </a>

                </li>


                <!-- CAKES -->

                <li class="nav-item dropdown">

                    <div class="d-flex align-items-center">

                        <a
                            href="product.php"
                            class="nav-link cakes-main-link"
                        >
                            Cakes
                        </a>

                        <a
                            href="#"
                            class="nav-link dropdown-toggle cakes-dropdown-btn"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                        ></a>


                        <ul class="dropdown-menu">

                            <?php foreach ($parent_categories as $parent) { ?>

                                <?php

                                $parent_id =
                                    intval($parent['id']);

                                $sub_categories =
                                    getSubCategoriesAbout(
                                        $conn,
                                        $parent_id
                                    );

                                ?>

                                <?php if (count($sub_categories) > 0) { ?>

                                    <li class="dropdown-submenu">

                                        <a
                                            href="product.php?category=<?php echo $parent_id; ?>"
                                            class="dropdown-item dropdown-toggle"
                                        >
                                            <?php
                                            echo htmlspecialchars(
                                                $parent['category_name']
                                            );
                                            ?>
                                        </a>


                                        <ul class="dropdown-menu">

                                            <?php foreach ($sub_categories as $sub) { ?>

                                                <li>

                                                    <a
                                                        href="product.php?category=<?php echo intval($sub['id']); ?>"
                                                        class="dropdown-item"
                                                    >
                                                        <?php
                                                        echo htmlspecialchars(
                                                            $sub['category_name']
                                                        );
                                                        ?>
                                                    </a>

                                                </li>

                                            <?php } ?>

                                        </ul>

                                    </li>

                                <?php } else { ?>

                                    <li>

                                        <a
                                            href="product.php?category=<?php echo $parent_id; ?>"
                                            class="dropdown-item"
                                        >
                                            <?php
                                            echo htmlspecialchars(
                                                $parent['category_name']
                                            );
                                            ?>
                                        </a>

                                    </li>

                                <?php } ?>

                            <?php } ?>

                        </ul>

                    </div>

                </li>


                <!-- GALLERY -->

                <li class="nav-item">

                    <a
                        href="gallery.php"
                        class="nav-link fw-bold"
                    >
                        Gallery
                    </a>

                </li>


                <!-- CONTACT -->

                <li class="nav-item">

                    <a
                        href="contact.php"
                        class="nav-link fw-bold"
                    >
                        Contact
                    </a>

                </li>


                <!-- CART -->

                <?php if ($customer_logged_in) { ?>

                    <li class="nav-item">

                        <a
                            href="carts.php"
                            class="nav-link cart-link"
                        >

                            <i class="fas fa-shopping-cart"></i>

                            Cart

                        </a>

                    </li>

                <?php } ?>


                <!-- USER -->

                <?php if ($customer_logged_in) { ?>

                    <li class="nav-item dropdown ms-2">

                        <button
                            class="user-dropdown-btn dropdown-toggle"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                        >

                            <i class="fas fa-user-circle"></i>

                            <span>
                                <?php
                                echo htmlspecialchars(
                                    $customer_name
                                );
                                ?>
                            </span>

                        </button>


                        <ul
                            class="dropdown-menu dropdown-menu-end user-menu"
                        >

                            <li>

                                <div class="user-info">

                                    <strong>
                                        <?php
                                        echo htmlspecialchars(
                                            $customer_name
                                        );
                                        ?>
                                    </strong>

                                    <small>
                                        <?php
                                        echo htmlspecialchars(
                                            $customer_email
                                        );
                                        ?>
                                    </small>

                                </div>

                            </li>


                            <li>

                                <a
                                    href="#"
                                    class="dropdown-item"
                                >

                                    <i class="fas fa-user me-2"></i>

                                    My Profile

                                </a>

                            </li>


                            <li>

                                <a
                                    href="carts.php"
                                    class="dropdown-item"
                                >

                                    <i class="fas fa-shopping-cart me-2"></i>

                                    My Cart

                                </a>

                            </li>


                            <li>

                                <hr class="dropdown-divider">

                            </li>


                            <li>

                                <a
                                    href="logout.php"
                                    class="dropdown-item logout-item"
                                >

                                    <i class="fas fa-sign-out-alt me-2"></i>

                                    Sign Out

                                </a>

                            </li>

                        </ul>

                    </li>


                <?php } else { ?>


                    <!-- SIGN IN -->

                    <li class="nav-item ms-2">

                        <a
                            href="login.php"
                            class="btn signin-btn"
                        >

                            <i class="fas fa-sign-in-alt"></i>

                            Sign In

                        </a>

                    </li>


                    <!-- REGISTER -->

                    <li class="nav-item ms-2">

                        <a
                            href="register.php"
                            class="btn register-btn"
                        >

                            <i class="fas fa-user-plus"></i>

                            Register

                        </a>

                    </li>


                <?php } ?>


            </ul>

        </div>

    </div>

</nav>


<!-- =====================================================
     ABOUT HERO
===================================================== -->

<section class="about-hero">

    <div class="about-hero-overlay">

        <div class="container text-center">

            <div class="about-hero-badge">

                <i class="fa fa-birthday-cake"></i>

                SWIFFIN CAKE SHOP

            </div>

            <h1 class="about-hero-title">

                About <span>SWIFFIN</span>

            </h1>

            <p class="about-hero-text">

                Freshly Baked Happiness for Every Celebration

            </p>

            <div class="about-hero-divider">

                <span></span>

                <i class="fa fa-birthday-cake"></i>

                <span></span>

            </div>

            <a
                href="product.php"
                class="about-order-btn"
            >

                <i class="fa fa-shopping-bag"></i>

                Explore Our Cakes

                <i class="fa fa-arrow-right"></i>

            </a>

        </div>

    </div>

</section>


<!-- =====================================================
     ABOUT SWIFFIN
===================================================== -->

<section class="swiffin-about">

    <div class="container">

        <div class="row align-items-center g-5">


            <!-- IMAGE -->

            <div class="col-lg-6">

                <div class="about-image-wrap">

                    <img
                        src="img/about.jpg"
                        class="about-main-image"
                        alt="About Swiffin Cake Shop"
                    >


                    <div class="about-floating-card">

                        <div class="about-floating-icon">

                            <img
                                src="img/logo.png"
                                alt="SWIFFIN Logo"
                            >

                        </div>

                        <div>

                            <strong>
                                Freshly Baked
                            </strong>

                            <small>
                                Every Single Day
                            </small>

                        </div>

                    </div>


                    <div class="about-corner-box">

                        <i class="fa fa-heart"></i>

                    </div>

                </div>

            </div>


            <!-- CONTENT -->

            <div class="col-lg-6">

                <div class="about-content">

                    <div class="about-small-title">

                        <span></span>

                        ABOUT SWIFFIN

                    </div>


                    <h2>

                        We Bake

                        <span>Happiness</span>

                        Every Day

                    </h2>


                    <p class="about-description">

                        Swiffin Cake Shop is passionate about creating
                        beautiful and delicious cakes for birthdays,
                        anniversaries, weddings and every special occasion.
                        Our expert bakers use premium ingredients to bring
                        you unforgettable taste, freshness and quality.

                    </p>


                    <div class="about-features">


                        <div class="about-feature">

                            <div class="feature-icon">

                                <i class="fa fa-birthday-cake"></i>

                            </div>

                            <div>

                                <h5>
                                    Premium Quality
                                </h5>

                                <p>
                                    Freshly baked with carefully selected
                                    premium ingredients.
                                </p>

                            </div>

                        </div>


                        <div class="about-feature">

                            <div class="feature-icon">

                                <i class="fa fa-truck"></i>

                            </div>

                            <div>

                                <h5>
                                    Fast Home Delivery
                                </h5>

                                <p>
                                    Safe and fresh delivery right to
                                    your doorstep.
                                </p>

                            </div>

                        </div>


                        <div class="about-feature">

                            <div class="feature-icon">

                                <i class="fa fa-heart"></i>

                            </div>

                            <div>

                                <h5>
                                    Made With Love
                                </h5>

                                <p>
                                    Every cake is prepared with care
                                    for your special moments.
                                </p>

                            </div>

                        </div>

                    </div>


                    <a
                        href="product.php"
                        class="about-shop-btn"
                    >

                        <i class="fa fa-birthday-cake"></i>

                        Explore Our Cakes

                        <i class="fa fa-arrow-right"></i>

                    </a>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- =====================================================
     WHY CHOOSE US
===================================================== -->

<section class="py-5 bg-light">

    <div class="container">

        <div class="text-center mb-5">

            <h5 class="text-warning fw-bold">
                WHY CHOOSE US
            </h5>

            <b class="display-5 fw-bold">
                Why Customers Love Swiffin
            </b>

            <p class="text-muted">
                Freshly baked cakes made with love for every
                special moment.
            </p>

        </div>


        <div class="row g-4">


            <div class="col-lg-4 col-md-6">

                <div
                    class="card border-0 shadow-lg h-100 text-center p-3"
                >

                    <img
                        src="img/fresh.jpg"
                        class="img-fluid mx-auto mb-3"
                        style="
                            width:150px;
                            height:150px;
                            object-fit:contain;
                        "
                        alt="Freshly Baked"
                    >

                    <h4 class="fw-bold">
                        Freshly Baked
                    </h4>

                    <p class="text-muted">

                        Every cake is baked daily using premium
                        ingredients for delicious taste and
                        perfect softness.

                    </p>

                </div>

            </div>


            <div class="col-lg-4 col-md-6">

                <div
                    class="card border-0 shadow-lg h-100 text-center p-3"
                >

                    <img
                        src="img/custom.jpg"
                        class="img-fluid mx-auto mb-3"
                        style="
                            width:150px;
                            height:150px;
                            object-fit:contain;
                        "
                        alt="Custom Designs"
                    >

                    <h4 class="fw-bold">
                        Custom Designs
                    </h4>

                    <p class="text-muted">

                        Birthday, Anniversary, Wedding or Theme
                        Cakes customized exactly as you imagine.

                    </p>

                </div>

            </div>


            <div class="col-lg-4 col-md-6 mx-auto">

                <div
                    class="card border-0 shadow-lg h-100 text-center p-3"
                >

                    <img
                        src="img/fast.jpg"
                        class="img-fluid mx-auto mb-3"
                        style="
                            width:150px;
                            height:150px;
                            object-fit:contain;
                        "
                        alt="Fast Delivery"
                    >

                    <h4 class="fw-bold">
                        Fast Delivery
                    </h4>

                    <p class="text-muted">

                        Fresh cakes delivered safely to your
                        doorstep with secure packaging and
                        on-time service.

                    </p>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- =====================================================
     STATISTICS
===================================================== -->

<section class="py-5">

    <div class="container">

        <div class="row g-4">

            <div class="col-md-3">

                <div class="feature-box text-center">

                    <h2 class="text-warning fw-bold">
                        5000+
                    </h2>

                    <h5>
                        Happy Customers
                    </h5>

                </div>

            </div>


            <div class="col-md-3">

                <div class="feature-box text-center">

                    <h2 class="text-warning fw-bold">
                        250+
                    </h2>

                    <h5>
                        Cake Designs
                    </h5>

                </div>

            </div>


            <div class="col-md-3">

                <div class="feature-box text-center">

                    <h2 class="text-warning fw-bold">
                        10+
                    </h2>

                    <h5>
                        Years Experience
                    </h5>

                </div>

            </div>


            <div class="col-md-3">

                <div class="feature-box text-center">

                    <h2 class="text-warning fw-bold">
                        4.9 ★
                    </h2>

                    <h5>
                        Customer Rating
                    </h5>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- =====================================================
     OUR SERVICES
===================================================== -->

<section class="py-5 bg-light">

    <div class="container">

        <div class="text-center mb-5">

            <h5 class="text-warning fw-bold">
                OUR SERVICES
            </h5>

            <b class="display-5 fw-bold">
                What We Offer
            </b>

            <p class="text-muted">

                We create delicious cakes and desserts for every
                celebration with premium quality and timely delivery.

            </p>

        </div>


        <div class="row g-4">


            <div class="col-lg-4 col-md-6">

                <div class="service-box text-center p-4">

                    <img
                        src="img/Birthday.png"
                        class="img-fluid mb-3 service-img"
                        alt="Birthday Cakes"
                    >

                    <h5>
                        Birthday Cakes
                    </h5>

                    <p>
                        Beautiful birthday cakes with custom
                        themes and fresh flavors.
                    </p>

                </div>

            </div>


            <div class="col-lg-4 col-md-6">

                <div class="service-box text-center p-4">

                    <img
                        src="img/wedding-cake.png"
                        class="img-fluid mb-3 service-img"
                        alt="Wedding Cakes"
                    >

                    <h5>
                        Wedding Cakes
                    </h5>

                    <p>
                        Elegant multi-tier wedding cakes designed
                        for your special day.
                    </p>

                </div>

            </div>


            <div class="col-lg-4 col-md-6">

                <div class="service-box text-center p-4">

                    <img
                        src="img/chocolate-cake.png"
                        class="img-fluid mb-3 service-img"
                        alt="Chocolate Cakes"
                    >

                    <h5>
                        Chocolate Cakes
                    </h5>

                    <p>
                        Rich chocolate cakes made with premium
                        cocoa ingredients.
                    </p>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- =====================================================
     BACK TO TOP
===================================================== -->

<a
    href="#"
    class="back-to-top"
    title="Back to Top"
    style="
        position:fixed;
        right:25px;
        bottom:25px;
        width:48px;
        height:48px;
        display:flex;
        align-items:center;
        justify-content:center;
        background:#E88F2A;
        color:#fff;
        border-radius:50%;
        text-decoration:none;
        font-size:20px;
        font-weight:bold;
        box-shadow:0 5px 15px rgba(0,0,0,0.3);
        z-index:999;
        transition:0.3s;
    "
>

    <i class="bi bi-arrow-up fw-bold"></i>

</a>


<!-- =====================================================
     JAVASCRIPT
===================================================== -->

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>

<script
    src="https://code.jquery.com/jquery-3.4.1.min.js"
></script>

<script
    src="lib/easing/easing.min.js"
></script>

<script
    src="lib/waypoints/waypoints.min.js"
></script>

<script
    src="lib/counterup/counterup.min.js"
></script>

<script
    src="lib/owlcarousel/owl.carousel.min.js"
></script>

<script
    src="js/main.js"
></script>

</body>

</html>

