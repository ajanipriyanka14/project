<?php
session_start();
//include "check_session.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>login</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Oswald:wght@500;600;700&family=Pacifico&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<style>
<body>{
	margin:0;
	padding:0;
}
.container-fluid
{
	margin-top:0!important;
	padding:0!important;
}

.navbar{
    background:#fff !important;
}

.navbar .nav-link{
    color:#222 !important;
    font-weight:600;
}

.navbar .nav-link:hover{
    color:#E88F2A !important;
}
.btn-primary{
    background:#E88F2A !important;
    border-color:#E88F2A !important;
    color:#fff !important;
}

.btn-primary:hover{
    background:#d67d18 !important;
    border-color:#d67d18 !important;
}


</style>
    <!-- Topbar Start -->

	<div class="container-fluid px-5">
    <div class="row align-items-center">

        <!-- Welcome Left -->
        <div class="col-lg-2">
            <h5 class="m-1 fw-bold">
			<?php
			if(isset($_SESSION['name'])){
               echo "Welcome ". $_SESSION['name']; 
			}
			else
			{
				echo "Welcome";
			}
			?>		
            </h5>
        </div>

     <!-- SWIFFIN Center -->
<div class="col-lg-5 text-center  py-2">
    <a href="index1.php" class="navbar-brand d-flex justify-content-center align-items-center">
        <img src="img/logo.png" alt="Logo" width="60" height="60" >
        <h1 class="m-0  ms-2 text-uppercase ">
		<span style ="color:#ff9800;">SWIFFIN</span>
		</h1>
    </a>
</div>
        <!-- CALL US Right -->
        <div class="col-lg-4 text-end">
            <div class="d-inline-flex align-items-center ">
                <i class="bi bi-phone-vibrate fs-1 text-primary me-3"></i>
                <div class="text-start">
                    <h6 class="text-uppercase mb-1">CALL US</h6>
                    <span>+91 9876543210</span>
                </div>
            </div>
        </div>

    </div>
</div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow-sm sticky-top py-3">
    <div class="container">

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbar">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a href="index1.php" class="nav-link active">Home</a></li>
                <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
               <li class="nav-item"><a href="product.php" class="nav-link">Cakes</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link">Gallery</a></li>
                <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
                <li class="nav-item"><a href="login.php" class="btn btn-primary rounded-circle ms-3 px-4 fw-bold">Login</a></li>
				<li class="nav-item"><a href="register.php" class="btn btn-primary  rounded-circle ms-3 px-4 fw-bold">Register</a></li>
				<li class="nav-item"><a href="logout.php" class="btn btn-primary rounded-circle ms-3 px-4 fw-bold">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
    <!-- Navbar End -->

<!-- Hero Start -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">

            <!-- Left -->
            <div class="col-lg-6 text-white">

                <h5 class="text-warning fw-bold mb-3">
                    Welcome To Swiffin Cake Shop
                </h5>

                <h1 class="display-2 fw-bold mb-4">
                    Fresh & Delicious Cakes
                </h1>

                <p class="lead mb-4">
                    Celebrate every moment with our freshly baked cakes,
                    made with love and premium ingredients.
                </p>

                <a href="product.php" class="btn btn-warning btn-lg me-3">
                    Order Now
                </a>

                <a href="about.php" class="btn btn-outline-light btn-lg">
                    Explore More
                </a>

            </div>

            <!-- Right -->
            <div class="col-lg-6 text-center">

                <img src="img/hero.jpg"
                     class="img-fluid hero-img"
                     alt="Cake">

            </div>

        </div>
    </div>
</section>
<!-- Hero End -->

    <!-- Video Modal Start -->
    <div class="modal fade" id="videoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Youtube Video</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- 16:9 aspect ratio -->
                    <div class="ratio ratio-16x9">
                        <iframe class="embed-responsive-item" src="" id="video" allowfullscreen allowscriptaccess="always"
                            allow="autoplay"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Video Modal End -->

    <!-- Footer Start -->
		<div class="container-fluid bg-img text-secondary" style="margin-top: 90px">
        <div class="container">
		<div class="row gx-5">
								<div class="col-lg-4 col-md-6 mb-lg-n5">
                    <div class="d-flex flex-column align-items-center justify-content-center text-center h-100 bg-primary border-inner p-4">
                        <a href="index.html" class="navbar-brand">
                            <h1 class="m-0 text-uppercase text-white"><i class="fa fa-birthday-cake fs-1 text-dark me-3"></i>swiffin</h1>
                        </a>
                        <p class="mt-3">Lorem diam sit erat dolor elitr et, diam lorem justo labore amet clita labore stet eos magna sit. Elitr dolor eirmod duo tempor lorem, elitr clita ipsum sea. Nonumy rebum et takimata ea takimata amet gubergren, erat rebum magna lorem stet eos. Diam amet et kasd eos duo dolore no.</p>
                    </div>
                </div>
                <div class="col-lg-8 col-md-6">
                    <div class="row gx-5">
                        <div class="col-lg-4 col-md-12 pt-5 mb-5">
                            <h4 class="text-primary text-uppercase mb-4">Get In Touch</h4>
                            <div class="d-flex mb-2">
                                <i class="bi bi-geo-alt text-primary me-2"></i>
                                <p class="mb-0">123 Street, New York, USA</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-envelope-open text-primary me-2"></i>
                                <p class="mb-0">info@example.com</p>
                            </div>
                            <div class="d-flex mb-2">
                                <i class="bi bi-telephone text-primary me-2"></i>
                                <p class="mb-0">+012 345 67890</p>
                            </div>
<div class="d-flex mt-4">
    <a class="btn btn-warning btn-lg-square rounded-circle me-2" href="#">
        <i class="fab fa-facebook-f"></i>
    </a>

    <a class="btn btn-warning btn-lg-square rounded-circle me-2" href="#">
        <i class="fab fa-instagram"></i>
    </a>

    <a class="btn btn-warning btn-lg-square rounded-circle me-2" href="#">
        <i class="fab fa-whatsapp"></i>
    </a>

    <a class="btn btn-warning btn-lg-square rounded-circle" href="#">
        <i class="fab fa-linkedin-in"></i>
    </a>
</div>
                        </div>
                        <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                            <h4 class="text-primary text-uppercase mb-4">Quick Links</h4>
                            <div class="d-flex flex-column justify-content-start">
                                <a class="text-secondary mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Home</a>
                                <a class="text-secondary mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>About Us</a>
                                <a class="text-secondary mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Our Services</a>
                                <a class="text-secondary mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Meet The Team</a>
                                <a class="text-secondary mb-2" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Latest Blog</a>
                                <a class="text-secondary" href="#"><i class="bi bi-arrow-right text-primary me-2"></i>Contact Us</a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 pt-0 pt-lg-5 mb-5">
                            <h4 class="text-primary text-uppercase mb-4">Newsletter</h4>
                            <p>Amet justo diam dolor rebum lorem sit stet sea justo kasd</p>
                            <form action="">
                                <div class="input-group">
                                    <input type="text" class="form-control border-white p-3" placeholder="Your Email">
                                    <button class="btn btn-primary">Sign Up</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid text-secondary py-4" style="background: #111111;">
        <div class="container text-center">
            <p class="mb-0">&copy; <a class="text-white border-bottom" href="#">swiffin cake Shop</a>. All Rights Reserved. 
			
			<!--/*** The author’s attribution link must remain intact in the template. ***/-->
            <!--/*** If you wish to remove this credit link, please purchase the Pro Version . ***/-->
            Designed by <a class="text-white border-bottom" href="https://htmlcodex.com">HTML Codex</a></p>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary border-inner py-3 fs-4 back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>