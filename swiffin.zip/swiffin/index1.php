
<?php
session_start();
include("config.php");


/* =====================================================
   CUSTOMER LOGIN SESSION
===================================================== */

$customer_logged_in = false;
$customer_name = "";
$customer_email = "";

if (
    isset($_SESSION['customer']) &&
    $_SESSION['customer'] === true
) {
    $customer_logged_in = true;

    $customer_name =
        $_SESSION['customer_name'] ?? "";

    $customer_email =
        $_SESSION['customer_email'] ?? "";
}


/* =====================================================
   DYNAMIC PARENT CATEGORIES
===================================================== */

$parent_categories = [];

$cat_sql = "
    SELECT id, category_name, parent_id, status
    FROM category
    WHERE parent_id = 0
    AND status = 'Active'
    ORDER BY category_name ASC
";

$cat_result = mysqli_query($conn, $cat_sql);

if ($cat_result) {

    while ($cat = mysqli_fetch_assoc($cat_result)) {

        $parent_categories[] = $cat;
    }
}


/* =====================================================
   GET SUB CATEGORIES
===================================================== */

function getSubCategories($conn, $parent_id)
{
    $sub_categories = [];

    $parent_id = intval($parent_id);

    $sql = "
        SELECT id, category_name, parent_id, status
        FROM category
        WHERE parent_id = $parent_id
        AND status = 'Active'
        ORDER BY category_name ASC
    ";

    $result = mysqli_query($conn, $sql);

    if ($result) {

        while ($row = mysqli_fetch_assoc($result)) {

            $sub_categories[] = $row;
        }
    }

    return $sub_categories;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <title>SWIFFIN Cake Shop</title>

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="keywords"
        content="SWIFFIN Cake Shop, Cakes, Birthday Cake, Online Cake Shop"
    >

    <meta
        name="description"
        content="Fresh and delicious cakes from SWIFFIN Cake Shop"
    >


    <!-- FAVICON -->

    <link
        href="img/favicon.ico"
        rel="icon"
    >


    <!-- GOOGLE FONTS -->

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Oswald:wght@500;600;700&family=Pacifico&display=swap"
        rel="stylesheet"
    >


    <!-- FONT AWESOME -->

    <link
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
        rel="stylesheet"
    >


    <!-- BOOTSTRAP ICONS -->

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
        rel="stylesheet"
    >


    <!-- OWL CAROUSEL -->

    <link
        href="lib/owlcarousel/assets/owl.carousel.min.css"
        rel="stylesheet"
    >


    <!-- BOOTSTRAP -->

    <link
        href="css/bootstrap.min.css"
        rel="stylesheet"
    >


    <!-- MAIN CSS -->

    <link
        href="css/style.css"
        rel="stylesheet"
    >



<style>

/* =====================================================
   GENERAL
===================================================== */

html {
    scroll-behavior: smooth;
}

body {

    margin: 0;
    padding: 0;
    background: #fff;
    font-family: "Open Sans", sans-serif;

}

.container-fluid {

    margin-top: 0 !important;

}


/* =====================================================
   COLORS
===================================================== */

:root {

    --orange: #E88F2A;
    --orange-dark: #d67d18;
    --black: #111111;
    --dark: #181818;
    --light: #FAF3EB;

}


/* =====================================================
   NAVBAR
===================================================== */
.navbar {

    background: #fff !important;

}

.navbar .nav-link {

    color: #222 !important;

    font-weight: 900 !important;

    -webkit-text-stroke: 0.6px #222;

    transition: 0.3s;

}

.navbar .nav-link.active {
    color: #E88F2A !important;
    -webkit-text-stroke: 0.6px #E88F2A;
    font-weight: 900 !important;
}



.navbar .nav-link:hover {
    color: var(--orange) !important;
    -webkit-text-stroke: 0.4px var(--orange);
}



.navbar-nav .nav-link {

    font-weight: 900 !important;

}
/* =====================================================
   PRIMARY BUTTON
===================================================== */

.btn-primary {

    background: var(--orange) !important;

    border-color: var(--orange) !important;

    color: #fff !important;

}

.btn-primary:hover {

    background: var(--orange-dark) !important;

    border-color: var(--orange-dark) !important;

}


/* =====================================================
   WELCOME USER
===================================================== */

.welcome-user {

    display: flex;

    align-items: center;

    gap: 10px;

}

.user-icon {

    width: 42px;

    height: 42px;

    border-radius: 50%;

    background: var(--orange);

    color: #fff;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 18px;

    box-shadow:
        0 4px 12px rgba(232,143,42,0.30);

}

.welcome-text {

    display: flex;

    flex-direction: column;

    line-height: 1.2;

}

.welcome-text small {

    color: #888;

    font-size: 10px;

    text-transform: uppercase;

    letter-spacing: 1px;

}

.welcome-text strong {

    color: #222;

    font-size: 14px;

    max-width: 140px;

    overflow: hidden;

    text-overflow: ellipsis;

    white-space: nowrap;

}


/* =====================================================
   GUEST
===================================================== */

.welcome-guest {

    display: flex;

    align-items: center;

    gap: 8px;

    color: #555;

    font-weight: 600;

}

.welcome-guest i {

    font-size: 28px;

    color: var(--orange);

}


/* =====================================================
   CATEGORY DROPDOWN
===================================================== */

.dropdown-submenu {

    position: relative;

}

.dropdown-submenu > .dropdown-menu {

    top: 0;

    left: 100%;

    margin-top: 0;

    display: none;

}

.dropdown-submenu:hover > .dropdown-menu {

    display: block;

}

.dropdown-menu {

    min-width: 220px;

    border: none;

    border-radius: 10px;

    box-shadow:
        0 10px 30px rgba(0,0,0,0.15);

}

.dropdown-item {

    padding: 10px 15px;

    font-size: 14px;

    font-weight: 600;

}

.dropdown-item:hover {

    color: var(--orange);

    background: var(--light);

}


/* =====================================================
   USER DROPDOWN
===================================================== */

.user-dropdown-btn {

    border: none;

    background: transparent;

    display: flex;

    align-items: center;

    gap: 8px;

    color: #222;

    font-weight: 600;

    cursor: pointer;

    padding: 7px 12px;

    border-radius: 25px;

    transition: 0.3s;

}

.user-dropdown-btn:hover {

    background: var(--light);

    color: var(--orange);

}

.user-dropdown-btn i {

    color: var(--orange);

    font-size: 21px;

}


.user-menu {

    min-width: 230px;

    padding: 10px;

    border: none;

    border-radius: 13px;

    box-shadow:
        0 10px 30px rgba(0,0,0,0.16);

}

.user-menu .user-info {

    padding: 12px;

    border-bottom: 1px solid #eee;

    margin-bottom: 5px;

}

.user-menu .user-info strong {

    display: block;

    color: #222;

    font-size: 15px;

}

.user-menu .user-info small {

    color: #888;

    font-size: 11px;

    word-break: break-all;

}

.user-menu .dropdown-item {

    border-radius: 8px;

    padding: 10px 12px;

}

.user-menu .logout-item {

    color: #dc3545;

}

.user-menu .logout-item:hover {

    background: #fff0f0;

    color: #dc3545;

}


/* =====================================================
   CART
===================================================== */

.cart-link {

    display: inline-flex !important;

    align-items: center;

    gap: 6px;

}

.cart-link i {

    color: var(--orange);

    font-size: 18px;

}


/* =====================================================
   SIGN IN
===================================================== */

.signin-btn {

    display: inline-flex;

    align-items: center;

    gap: 7px;

    background: var(--orange) !important;

    color: #fff !important;

    border-radius: 25px !important;

    padding: 9px 18px !important;

    font-weight: 700;

    border: 1px solid var(--orange) !important;

    transition: 0.3s;

}

.signin-btn:hover {

    background: #fff !important;

    color: var(--orange) !important;

}


/* =====================================================
   REGISTER
===================================================== */

.register-btn {

    display: inline-flex;

    align-items: center;

    gap: 7px;

    border: 1px solid var(--orange) !important;

    color: var(--orange) !important;

    background: #fff !important;

    border-radius: 25px !important;

    padding: 9px 18px !important;

    font-weight: 700;

    transition: 0.3s;

}

.register-btn:hover {

    background: var(--orange) !important;

    color: #fff !important;

}


/* =====================================================
   HERO
===================================================== */

.hero-section {

    background:
        linear-gradient(
            rgba(0,0,0,0.78),
            rgba(0,0,0,0.78)
        ),
        url("img/hero-bg.jpg");

    background-size: cover;

    background-position: center;

    padding: 110px 0;

    min-height: 600px;

    display: flex;

    align-items: center;

}

.hero-section h5 {

    color: var(--orange) !important;

    letter-spacing: 1px;

}

.hero-section h1 {

    font-family: "Oswald", sans-serif;

}

.hero-section p {

    color: #ddd;

    line-height: 1.8;

}


.hero-section .btn-warning {

    background: var(--orange);

    border-color: var(--orange);

    color: #fff;

    font-weight: 700;

    border-radius: 30px;

    padding: 13px 28px;

}

.hero-section .btn-warning:hover {

    background: #fff;

    color: #000;

}


.hero-section .btn-outline-light {

    border-radius: 30px;

    padding: 13px 28px;

    font-weight: 700;

}


.hero-img {

    max-height: 470px;

    object-fit: contain;

    border-radius: 20px;

    box-shadow:
        0 15px 40px rgba(0,0,0,0.35);

}


/* =====================================================
   SEARCH
===================================================== */

.cake-search {

    width: 100%;

    display: flex;

    justify-content: center;

}

.search-wrapper {

    width: 650px;

    max-width: 100%;

    height: 58px;

    background: #fff;

    border: 2px solid #ddd;

    border-radius: 30px;

    display: flex;

    align-items: center;

    padding-left: 20px;

    overflow: hidden;

    transition: 0.3s;

}

.search-wrapper:focus-within {

    border-color: var(--orange);

    box-shadow:
        0 0 15px rgba(232,143,42,0.30);

}

.search-icon {

    color: #777;

    font-size: 19px;

    margin-right: 12px;

}

.search-wrapper input {

    flex: 1;

    height: 100%;

    border: none;

    outline: none;

    font-size: 16px;

    color: #222;

    background: transparent;

}

.search-wrapper input::placeholder {

    color: #888;

}

.search-wrapper button {

    height: 100%;

    border: none;

    background: var(--orange);

    color: #fff;

    padding: 0 28px;

    font-size: 15px;

    font-weight: 700;

    cursor: pointer;

    transition: 0.3s;

}

.search-wrapper button:hover {

    background: var(--orange-dark);

}


/* =====================================================
   PRODUCT CARD
===================================================== */

.product-card {

    background: #111;

    border: 2px solid #2c2c2c;

    border-radius: 18px;

    overflow: hidden;

    height: 100%;

    transition: 0.35s;

}

.product-card:hover {

    border-color: var(--orange);

    box-shadow:
        0 10px 30px rgba(232,143,42,0.30);

    transform: translateY(-7px);

}

.product-card img {

    width: 100%;

    height: 230px;

    object-fit: cover;

    display: block;

}

.product-body {

    padding: 20px;

    text-align: center;

    color: #fff;

}

.product-body h5 {

    color: #fff;

    font-weight: 800;

    font-size: 18px;

    margin-bottom: 7px;

}

.product-body .category {

    color: #999;

    margin-bottom: 12px;

    font-size: 13px;

}

.product-body p {

    color: #ccc;

    font-size: 14px;

    margin-bottom: 7px;

}

.product-body strong {

    color: #fff;

}

.price {

    color: var(--orange);

    font-size: 21px;

    font-weight: 800;

    margin: 12px 0;

}


/* =====================================================
   RATING
===================================================== */

.rating {

    margin: 10px 0 16px;

    white-space: nowrap;

}

.star {

    color: var(--orange);

    font-size: 17px;

}

.star.empty {

    color: #555;

}

.rating-number {

    color: #fff;

    font-weight: bold;

    margin-left: 5px;

}

.reviews {

    color: #999;

    font-size: 12px;

    margin-left: 3px;

}


/* =====================================================
   VIEW PRODUCT
===================================================== */

.view-product-btn {

    display: inline-block;

    background: var(--orange);

    color: #fff;

    text-decoration: none;

    font-weight: 700;

    padding: 11px 25px;

    border-radius: 30px;

    transition: 0.3s;

}

.view-product-btn:hover {

    background: #fff;

    color: #000;

    transform: translateY(-2px);

}


/* =====================================================
   VIEW ALL
===================================================== */

.view-all-btn {

    display: inline-block;

    background: var(--orange);

    color: #fff;

    text-decoration: none;

    font-weight: 700;

    padding: 14px 40px;

    border-radius: 30px;

    transition: 0.3s;

    box-shadow:
        0 6px 18px rgba(232,143,42,0.20);

}

.view-all-btn:hover {

    background: #fff;

    color: #000;

    transform: translateY(-3px);

}


/* =====================================================
   NO PRODUCT
===================================================== */

.no-product {

    padding: 55px;

    color: #fff;

}

.no-product i {

    font-size: 45px;

    color: var(--orange);

    margin-bottom: 15px;

}

.no-product h4 {

    color: #fff;

    font-weight: 800;

}

.no-product p {

    color: #999;

}


/* =====================================================
   FOOTER
===================================================== */

.swiffin-footer {

    background: #111;

    color: #aaa;

    border-top: 1px solid #292929;

}


/* =====================================================
   FOOTER BRAND
===================================================== */

.footer-brand-box {

    background: var(--orange);

    min-height: 390px;

    padding: 45px 35px;

    text-align: center;

    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;

    position: relative;

    overflow: hidden;

}


/* DECORATIVE CIRCLES */

.footer-brand-box::before {

    content: "";

    position: absolute;

    width: 190px;

    height: 190px;

    border: 2px solid rgba(0,0,0,0.08);

    border-radius: 50%;

    top: -75px;

    left: -75px;

}

.footer-brand-box::after {

    content: "";

    position: absolute;

    width: 150px;

    height: 150px;

    border: 2px solid rgba(0,0,0,0.08);

    border-radius: 50%;

    bottom: -65px;

    right: -55px;

}


/* =====================================================
   FOOTER LOGO
===================================================== */

.footer-logo {

    text-decoration: none;

    display: flex;

    align-items: center;

    justify-content: center;

    position: relative;

    z-index: 2;

}

.footer-logo-icon {
    width:55px;
    height:55px;

    border-radius:50%;

    background:#fff;

    display:flex;
    align-items:center;
    justify-content:center;

    overflow:hidden;

    border:2px solid #E88F2A;

    flex-shrink:0;
}

.footer-logo-icon img {
    width:45px;
    height:45px;

    object-fit:contain;

    border-radius:50%;
}
.footer-logo-text {

    color: #000;

    font-size: 35px;

    font-weight: 900;

    letter-spacing: 3px;

}


/* =====================================================
   FOOTER TAGLINE
===================================================== */

.footer-tagline {

    margin-top: 20px;

    margin-bottom: 10px;

    color: #000;

    font-size: 13px;

    font-weight: 800;

    letter-spacing: 3px;

}


/* =====================================================
   FOOTER DESCRIPTION
===================================================== */

.footer-description {

    max-width: 290px;

    color: #222;

    font-size: 14px;

    line-height: 1.8;

    margin-bottom: 18px;

}


/* =====================================================
   FOOTER DECORATION
===================================================== */

.footer-decoration {

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 9px;

    margin-top: 4px;

}

.footer-decoration span {

    width: 38px;

    height: 2px;

    background: #000;

    border-radius: 20px;

}

.footer-decoration i {

    color: #000;

    font-size: 14px;

}


/* =====================================================
   FOOTER MINI TEXT
===================================================== */

.footer-mini-text {

    margin-top: 12px;

    color: #000;

    font-size: 10px;

    font-weight: 800;

    letter-spacing: 2px;

}


/* =====================================================
   FOOTER CONTENT
===================================================== */

.footer-content {

    padding: 48px 20px 20px 45px;

}


/* =====================================================
   FOOTER TITLE
===================================================== */

.footer-title {

    color: var(--orange);

    font-size: 18px;

    font-weight: 800;

    text-transform: uppercase;

    letter-spacing: 1px;

    margin-bottom: 28px;

    position: relative;

    padding-bottom: 12px;

}

.footer-title::after {

    content: "";

    position: absolute;

    left: 0;

    bottom: 0;

    width: 38px;

    height: 3px;

    background: var(--orange);

    border-radius: 10px;

}


/* =====================================================
   FOOTER INFORMATION
===================================================== */

.footer-info {

    display: flex;

    align-items: flex-start;

    margin-bottom: 20px;

}

.footer-info-icon {

    width: 35px;

    height: 35px;

    min-width: 35px;

    display: flex;

    align-items: center;

    justify-content: center;

    background: #1e1e1e;

    border: 1px solid #333;

    border-radius: 9px;

    color: var(--orange);

    margin-right: 12px;

    transition: 0.3s;

}

.footer-info:hover .footer-info-icon {

    background: var(--orange);

    color: #fff;

    transform: translateY(-2px);

}

.footer-info small {

    display: block;

    color: #777;

    font-size: 10px;

    text-transform: uppercase;

    letter-spacing: 1px;

    margin-bottom: 2px;

}

.footer-info p {

    color: #ddd;

    font-size: 13px;

    margin: 0;

    line-height: 1.5;

}


/* =====================================================
   SOCIAL
===================================================== */

.social-title {

    color: #ddd;

    font-size: 13px;

    font-weight: 700;

    margin-top: 24px;

    margin-bottom: 12px;

    text-transform: uppercase;

    letter-spacing: 1px;

}

.social-icons {

    display: flex;

    gap: 9px;

}

.social-icon {

    width: 39px;

    height: 39px;

    border: 1px solid #444;

    background: #1a1a1a;

    color: #ddd;

    border-radius: 10px;

    display: flex;

    align-items: center;

    justify-content: center;

    text-decoration: none;

    font-size: 15px;

    transition: all 0.3s ease;

}

.social-icon:hover {

    background: var(--orange);

    border-color: var(--orange);

    color: #fff;

    transform: translateY(-4px);

    box-shadow:
        0 7px 15px rgba(232,143,42,0.25);

}


/* =====================================================
   QUICK LINKS
===================================================== */

.footer-links {

    display: flex;

    flex-direction: column;

}

.footer-links a {

    display: flex;

    align-items: center;

    color: #999;

    text-decoration: none;

    font-size: 14px;

    margin-bottom: 14px;

    transition: 0.3s;

}

.footer-links a:hover {

    color: var(--orange);

    padding-left: 5px;

}

.link-icon {

    width: 25px;

    color: var(--orange);

    font-size: 11px;

    transition: 0.3s;

}

.footer-links a:hover .link-icon {

    transform: translateX(3px);

}


/* =====================================================
   NEWSLETTER
===================================================== */

.newsletter-text {

    color: #999;

    font-size: 14px;

    line-height: 1.8;

    margin-bottom: 20px;

}

.newsletter-box {

    height: 52px;

    width: 100%;

    background: #1a1a1a;

    border: 1px solid #383838;

    border-radius: 30px;

    display: flex;

    align-items: center;

    padding-left: 16px;

    overflow: hidden;

    transition: 0.3s;

}

.newsletter-box:focus-within {

    border-color: var(--orange);

    box-shadow:
        0 0 12px rgba(232,143,42,0.15);

}

.newsletter-box > i {

    color: var(--orange);

    font-size: 16px;

    margin-right: 10px;

}

.newsletter-box input {

    flex: 1;

    height: 100%;

    background: transparent;

    border: none;

    outline: none;

    color: #fff;

    font-size: 13px;

    min-width: 0;

}

.newsletter-box input::placeholder {

    color: #777;

}

.newsletter-box button {

    width: 52px;

    height: 52px;

    border: none;

    background: var(--orange);

    color: #fff;

    font-size: 17px;

    display: flex;

    align-items: center;

    justify-content: center;

    cursor: pointer;

    transition: 0.3s;

}

.newsletter-box button:hover {

    background: #fff;

    color: #000;

}

.newsletter-note {

    margin-top: 13px;

    color: #666;

    font-size: 11px;

}

.newsletter-note i {

    color: var(--orange);

    margin-right: 5px;

}


/* =====================================================
   COPYRIGHT
===================================================== */

.copyright-section {

    background: #090909;

    border-top: 1px solid #252525;

    padding: 18px 0;

}

.copyright-text {

    color: #777;

    font-size: 12px;

}

.copyright-text a {

    color: var(--orange);

    text-decoration: none;

    font-weight: 700;

}

.copyright-text a:hover {

    color: #fff;

}

.copyright-text .fa-heart {

    color: var(--orange);

    margin: 0 4px;

}


/* =====================================================
   BACK TO TOP
===================================================== */

.swiffin-top {

    position: fixed;

    right: 25px;

    bottom: 25px;

    width: 52px;

    height: 52px;

    border-radius: 15px;

    background: var(--orange);

    color: #fff;

    display: flex;

    align-items: center;

    justify-content: center;

    text-decoration: none;

    font-size: 20px;

    box-shadow:
        0 8px 22px rgba(0,0,0,0.30);

    z-index: 9999;

    transition: all 0.3s ease;

    opacity: 0;

    visibility: hidden;

}

.swiffin-top:hover {

    background: #fff;

    color: #000;

    transform: translateY(-6px);

    box-shadow:
        0 10px 25px rgba(232,143,42,0.35);

}


/* =====================================================
   MOBILE
===================================================== */

@media(max-width:991px) {

    .footer-content {

        padding: 45px 25px 15px;

    }

    .hero-section {

        padding: 80px 0;

    }

}

@media(max-width:767px) {

    .search-wrapper {

        height: 52px;

    }

    .search-wrapper input {

        font-size: 14px;

    }

    .search-wrapper button {

        padding: 0 18px;

    }

    .footer-brand-box {

        min-height: 340px;

        padding: 35px 25px;

    }

    .footer-logo-text {

        font-size: 29px;

    }

    .footer-logo-icon {

        width: 50px;

        height: 50px;

        font-size: 23px;

    }

    .footer-content {

        padding: 40px 25px 10px;

    }

    .copyright-text {

        text-align: center !important;

        margin-bottom: 7px !important;

    }

    .swiffin-top {

        width: 46px;

        height: 46px;

        right: 18px;

        bottom: 18px;

        border-radius: 13px;

    }

}
..hero-floating-card {
    position:absolute;
    right:-5px;
    bottom:45px;
    z-index:5;

    display:flex;
    align-items:center;
    gap:10px;

    padding:10px 16px;

    background:#fff;
    border-radius:40px;

    box-shadow:0 10px 30px rgba(0,0,0,0.30);
}

/* LOGO CIRCLE */

.floating-icon {
    width:48px;
    height:48px;

    border-radius:50%;

    background:#fff;

    display:flex;
    align-items:center;
    justify-content:center;

    overflow:hidden;

    border:2px solid #E88F2A;

    flex-shrink:0;
}

.floating-icon img {
    width:38px;
    height:38px;

    object-fit:contain;

    border-radius:50%;
}

/* TEXT */

.floating-text {
    text-align:left;
    line-height:1.2;
}

.floating-text small {
    display:block;

    color:#fff;

    font-size:10px;

    text-transform:uppercase;

    margin-bottom:3px;
}

.floating-text strong {
    display:block;

    color:#fff;

    font-size:14px;

    font-weight:700;
}

</style>

</head>


<body>


<!-- =====================================================
     TOPBAR
===================================================== -->

<div class="container-fluid px-5">

    <div class="row align-items-center">


        <!-- WELCOME -->

        <div class="col-lg-3">

            <?php if ($customer_logged_in) { ?>

                <div class="welcome-user">

                    <div class="user-icon">

                        <i class="fas fa-user"></i>

                    </div>

                    <div class="welcome-text">

                        <small>
                            Welcome
                        </small>

                        <strong>

                            <?php
                            echo htmlspecialchars(
                                $customer_name
                            );
                            ?>

                        </strong>

                    </div>

                </div>

            <?php } else { ?>

                <div class="welcome-guest">

                    <i class="fas fa-user-circle"></i>

                    <span>
                        Welcome Guest
                    </span>

                </div>

            <?php } ?>

        </div>


        <!-- LOGO -->

        <div class="col-lg-5 text-center py-2">

            <a
                href="index1.php"
                class="navbar-brand d-flex justify-content-center align-items-center"
            >

                <img
                    src="img/logo.png"
                    alt="SWIFFIN Logo"
                    width="60"
                    height="60"
                >

                <h1 class="m-0 ms-2 text-uppercase">

                    <span style="color:#ff9800;">
                        SWIFFIN
                    </span>

                </h1>

            </a>

        </div>


        <!-- CALL -->

        <div class="col-lg-4 text-end pe-4">

            <div class="d-inline-flex align-items-center">

                <i
                    class="bi bi-phone-vibrate fs-1 text-primary me-3"
                ></i>

                <div class="text-start">

                    <h6 class="text-uppercase mb-1">
                        CALL US
                    </h6>

                    <span>
                        +91 9876543210
                    </span>

                </div>

            </div>

        </div>

    </div>

</div>



<!-- =====================================================
     NAVBAR
===================================================== -->

<nav
    class="navbar navbar-expand-lg bg-white navbar-light shadow-sm sticky-top py-3"
>

    <div class="container">


        <!-- MOBILE -->

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbar"
            aria-controls="navbar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >

            <span class="navbar-toggler-icon"></span>

        </button>


        <div
            class="collapse navbar-collapse"
            id="navbar"
        >

            <ul class="navbar-nav ms-auto align-items-center">


                <!-- HOME -->

                <li class="nav-item">

                    <a
                        href="index1.php"
                        class="nav-link active"
                    >
                        Home
                    </a>

                </li>


                <!-- ABOUT -->

                <li class="nav-item">

                    <a
                        href="about.php"
                        class="nav-link"
                    >
                        About
                    </a>

                </li>


                <!-- CAKES -->

                <li class="nav-item dropdown">

                    <div class="d-flex align-items-center">

                        <a
                            href="product.php"
                            class="nav-link"
                            style="padding-right:2px;"
                        >
                            Cakes
                        </a>

                        <a
                            href="#"
                            class="nav-link dropdown-toggle"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            style="padding-left:2px;"
                        ></a>


                        <ul class="dropdown-menu">

                            <?php foreach (
                                $parent_categories
                                as $parent
                            ) { ?>

                                <?php

                                $parent_id =
                                    intval(
                                        $parent['id']
                                    );

                                $sub_categories =
                                    getSubCategories(
                                        $conn,
                                        $parent_id
                                    );

                                ?>


                                <?php if (
                                    count(
                                        $sub_categories
                                    ) > 0
                                ) { ?>

                                    <li class="dropdown-submenu">

                                        <a
                                            href="product.php?category=<?php echo $parent_id; ?>"
                                            class="dropdown-item dropdown-toggle"
                                        >

                                            <?php
                                            echo htmlspecialchars(
                                                $parent['category_name']
                                            );
                                            ?>

                                        </a>


                                        <ul class="dropdown-menu">

                                            <?php foreach (
                                                $sub_categories
                                                as $sub
                                            ) { ?>

                                                <li>

                                                    <a
                                                        href="product.php?category=<?php echo intval($sub['id']); ?>"
                                                        class="dropdown-item"
                                                    >

                                                        <?php
                                                        echo htmlspecialchars(
                                                            $sub['category_name']
                                                        );
                                                        ?>

                                                    </a>

                                                </li>

                                            <?php } ?>

                                        </ul>

                                    </li>

                                <?php } else { ?>

                                    <li>

                                        <a
                                            href="product.php?category=<?php echo $parent_id; ?>"
                                            class="dropdown-item"
                                        >

                                            <?php
                                            echo htmlspecialchars(
                                                $parent['category_name']
                                            );
                                            ?>

                                        </a>

                                    </li>

                                <?php } ?>

                            <?php } ?>

                        </ul>

                    </div>

                </li>
					  <!-- GALLERY -->

                <li class="nav-item">

                    <a
                        href="gallery.php"
                        class="nav-link fw-bold"
                    >
                        Gallery
                    </a>

                </li>

                <!-- CONTACT -->

                <li class="nav-item">

                    <a
                        href="contact.php"
                        class="nav-link"
                    >
                        Contact
                    </a>

                </li>


                <!-- CART -->

                <?php if ($customer_logged_in) { ?>

                    <li class="nav-item">

                        <a
                            href="carts.php"
                            class="nav-link cart-link"
                        >

                            <i class="fas fa-shopping-cart"></i>

                            Cart

                        </a>

                    </li>

                <?php } ?>


                <!-- LOGGED CUSTOMER -->

                <?php if ($customer_logged_in) { ?>

                    <li class="nav-item dropdown ms-2">

                        <button
                            class="user-dropdown-btn dropdown-toggle"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                        >

                            <i class="fas fa-user-circle"></i>

                            <span>

                                <?php
                                echo htmlspecialchars(
                                    $customer_name
                                );
                                ?>

                            </span>

                        </button>


                        <ul
                            class="dropdown-menu dropdown-menu-end user-menu"
                        >

                            <li>

                                <div class="user-info">

                                    <strong>

                                        <?php
                                        echo htmlspecialchars(
                                            $customer_name
                                        );
                                        ?>

                                    </strong>

                                    <small>

                                        <?php
                                        echo htmlspecialchars(
                                            $customer_email
                                        );
                                        ?>

                                    </small>

                                </div>

                            </li>


                            <li>

                                <a
                                    href="#"
                                    class="dropdown-item"
                                >

                                    <i class="fas fa-user me-2"></i>

                                    My Profile

                                </a>

                            </li>


                            <li>

                                <a
                                    href="carts.php"
                                    class="dropdown-item"
                                >

                                    <i class="fas fa-shopping-cart me-2"></i>

                                    My Cart

                                </a>

                            </li>


                            <li>

                                <hr class="dropdown-divider">

                            </li>


                            <li>

                                <a
                                    href="logout.php"
                                    class="dropdown-item logout-item"
                                >

                                    <i class="fas fa-sign-out-alt me-2"></i>

                                    Sign Out

                                </a>

                            </li>

                        </ul>

                    </li>


                <?php } else { ?>


                    <!-- SIGN IN -->

                    <li class="nav-item ms-2">

                        <a
                            href="login.php"
                            class="btn signin-btn"
                        >

                            <i class="fas fa-sign-in-alt"></i>

                            Sign In

                        </a>

                    </li>


                    <!-- REGISTER -->

                    <li class="nav-item ms-2">

                        <a
                            href="register.php"
                            class="btn register-btn"
                        >

                            <i class="fas fa-user-plus"></i>

                            Register

                        </a>

                    </li>


                <?php } ?>

            </ul>

        </div>

    </div>

</nav>



<!-- =====================================================
     UNIQUE PREMIUM HERO
===================================================== -->

<section class="hero-section">

    <div class="container">

        <div class="row align-items-center min-vh-75">

            <!-- =================================================
                 LEFT CONTENT
            ================================================== -->

            <div class="col-lg-6 hero-content">

                <div class="hero-badge">
                    <i class="fa fa-birthday-cake"></i>
                    Freshly Baked With Love
                </div>


                <h1 class="hero-title">

                    Make Every
                    <span>Celebration</span>
                    Sweeter

                </h1>


                <p class="hero-text">

                    Discover delicious cakes freshly baked
                    with premium ingredients. From birthdays
                    to special moments, make every celebration
                    unforgettable with SWIFFIN.

                </p>


                <!-- BUTTONS -->

                <div class="hero-buttons">

                    <a
                        href="product.php"
                        class="hero-order-btn"
                    >

                        <i class="fa fa-shopping-bag"></i>

                        Order Your Cake

                    </a>


                    <a
                        href="about.php"
                        class="hero-explore-btn"
                    >

                        Explore More

                        <i class="fa fa-arrow-right"></i>

                    </a>

                </div>


                <!-- SMALL FEATURES -->

                <div class="hero-features">

                    <div class="hero-feature">

                        <i class="fa fa-check-circle"></i>

                        <div>
                            <strong>Fresh Cakes</strong>
                            <small>Made Daily</small>
                        </div>

                    </div>


                    <div class="hero-feature">

                        <i class="fa fa-star"></i>

                        <div>
                            <strong>Premium Quality</strong>
                            <small>Best Ingredients</small>
                        </div>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 RIGHT IMAGE
            ================================================== -->

            <div class="col-lg-6 text-center hero-image-area">

                <div class="hero-image-wrapper">

                    <div class="hero-circle"></div>

                    <img
                        src="img/hero.jpg"
                        class="img-fluid hero-img"
                        alt="Fresh Delicious Cake"
                    >

<!-- FLOATING CARD -->

<div class="hero-floating-card">

    <div class="floating-icon">
        <img
            src="img/logo.png"
            alt="SWIFFIN Logo"
        >
    </div>

    <div class="floating-text">
        <small>Made Fresh</small>
        <strong>Every Day</strong>
    </div>

</div>

                    <!-- DECORATIVE DOT -->

                    <div class="hero-dot dot-one"></div>
                    <div class="hero-dot dot-two"></div>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- =====================================================
     HERO CSS
===================================================== -->

<style>

.hero-section {

    position:relative;

    min-height:650px;

    padding:80px 0;

    overflow:hidden;

    background:
        linear-gradient(
            120deg,
            #080808 0%,
            #111111 55%,
            #191919 100%
        );

}


/* =====================================================
   LEFT CONTENT
===================================================== */

.hero-content {

    position:relative;

    z-index:5;

}


.hero-badge {

    display:inline-flex;

    align-items:center;

    gap:9px;

    padding:9px 18px;

    margin-bottom:22px;

    border:1px solid rgba(232,143,42,0.45);

    border-radius:30px;

    background:rgba(232,143,42,0.08);

    color:#E88F2A;

    font-size:14px;

    font-weight:600;

}


.hero-badge i {

    font-size:15px;

}


.hero-title {

    color:#fff;

    font-size:62px;

    line-height:1.08;

    font-weight:800;

    margin-bottom:25px;

    letter-spacing:-1px;

}


.hero-title span {

    display:block;

    color:#E88F2A;

}


.hero-text {

    color:#bdbdbd;

    font-size:17px;

    line-height:1.8;

    max-width:560px;

    margin-bottom:32px;

}


/* =====================================================
   BUTTONS
===================================================== */

.hero-buttons {

    display:flex;

    align-items:center;

    gap:15px;

    flex-wrap:wrap;

}


.hero-order-btn {

    display:inline-flex;

    align-items:center;

    gap:10px;

    padding:14px 27px;

    border-radius:30px;

    background:#E88F2A;

    color:#fff;

    text-decoration:none;

    font-size:15px;

    font-weight:700;

    box-shadow:
        0 8px 25px rgba(232,143,42,0.25);

    transition:0.3s;

}


.hero-order-btn:hover {

    background:#fff;

    color:#111;

    transform:translateY(-3px);

    box-shadow:
        0 12px 30px rgba(255,255,255,0.15);

}


.hero-explore-btn {

    display:inline-flex;

    align-items:center;

    gap:10px;

    padding:13px 24px;

    border:1px solid #555;

    border-radius:30px;

    color:#fff;

    text-decoration:none;

    font-size:15px;

    font-weight:600;

    transition:0.3s;

}


.hero-explore-btn:hover {

    border-color:#E88F2A;

    color:#E88F2A;

    transform:translateY(-3px);

}


.hero-explore-btn i {

    font-size:12px;

}


/* =====================================================
   FEATURES
===================================================== */

.hero-features {

    display:flex;

    align-items:center;

    gap:35px;

    margin-top:42px;

}


.hero-feature {

    display:flex;

    align-items:center;

    gap:10px;

}


.hero-feature > i {

    color:#E88F2A;

    font-size:22px;

}


.hero-feature strong {

    display:block;

    color:#fff;

    font-size:13px;

}


.hero-feature small {

    display:block;

    color:#777;

    font-size:11px;

    margin-top:2px;

}


/* =====================================================
   IMAGE AREA
===================================================== */

.hero-image-area {

    position:relative;

    z-index:2;

}


.hero-image-wrapper {

    position:relative;

    width:500px;

    max-width:100%;

    margin:auto;

}


.hero-img {

    position:relative;

    width:100%;

    max-height:500px;

    object-fit:cover;

    border-radius:50%;

    border:10px solid rgba(255,255,255,0.06);

    box-shadow:
        0 25px 60px rgba(0,0,0,0.55);

    z-index:2;

}


/* =====================================================
   BACKGROUND CIRCLE
===================================================== */

.hero-circle {

    position:absolute;

    width:430px;

    height:430px;

    border-radius:50%;

    border:1px solid rgba(232,143,42,0.35);

    top:50%;

    left:50%;

    transform:translate(-50%,-50%);

}


.hero-circle::before {

    content:"";

    position:absolute;

    width:360px;

    height:360px;

    border-radius:50%;

    border:1px dashed rgba(232,143,42,0.25);

    top:50%;

    left:50%;

    transform:translate(-50%,-50%);

}


/* =====================================================
   FLOATING CARD
===================================================== */

.hero-floating-card {

    position:absolute;

    right:-5px;

    bottom:45px;

    z-index:5;

    display:flex;

    align-items:center;

    gap:10px;

    padding:12px 17px;

    background:#fff;

    border-radius:13px;

    box-shadow:
        0 10px 35px rgba(0,0,0,0.35);

    text-align:left;

}


.floating-icon {

    width:40px;

    height:40px;

    display:flex;

    align-items:center;

    justify-content:center;

    border-radius:50%;

    background:#E88F2A;

    color:#fff;

}


.hero-floating-card small {

    display:block;

    color:#888;

    font-size:10px;

    text-transform:uppercase;

}


.hero-floating-card strong {

    display:block;

    color:#222;

    font-size:13px;

}


/* =====================================================
   DECORATIVE DOTS
===================================================== */

.hero-dot {

    position:absolute;

    width:12px;

    height:12px;

    border-radius:50%;

    background:#E88F2A;

    z-index:4;

}


.dot-one {

    top:35px;

    right:40px;

}


.dot-two {

    bottom:80px;

    left:20px;

    width:8px;

    height:8px;

}


/* =====================================================
   RESPONSIVE
===================================================== */

@media(max-width:991px) {

    .hero-section {

        padding:65px 0;

        text-align:center;

    }


    .hero-title {

        font-size:48px;

    }


    .hero-text {

        margin-left:auto;

        margin-right:auto;

    }


    .hero-buttons {

        justify-content:center;

    }


    .hero-features {

        justify-content:center;

    }


    .hero-image-area {

        margin-top:60px;

    }

}


@media(max-width:576px) {

    .hero-section {

        padding:50px 15px;

    }


    .hero-title {

        font-size:38px;

    }


    .hero-text {

        font-size:14px;

    }


    .hero-features {

        flex-direction:column;

        gap:15px;

    }


    .hero-image-wrapper {

        width:340px;

    }


    .hero-floating-card {

        right:0;

        bottom:20px;

        padding:9px 12px;

    }


    .hero-circle {

        width:300px;

        height:300px;

    }

}

</style>
<!-- =====================================================
     PRODUCTS
===================================================== -->

<section
    class="py-5"
    style="background:#000;"
>

    <div class="container">


        <!-- TITLE -->

        <div class="text-center mb-4">

            <h5
                style="
                    color:#E88F2A;
                    font-weight:bold;
                    letter-spacing:1px;
                "
            >
                OUR PRODUCTS
            </h5>

            <h1
                class="fw-bold"
                style="color:#fff;"
            >
                Our Delicious Cakes
            </h1>

            <p style="color:#aaa;">

                Freshly baked cakes made with love.

            </p>

        </div>






        <!-- PRODUCTS ROW -->

        <div class="row g-4">


<?php

/* =====================================================
   PRODUCT QUERY
===================================================== */

$product_query = mysqli_query(

    $conn,

    "SELECT *
     FROM cake
     WHERE stock > 0
     AND status = 'Available'
     ORDER BY id DESC
     LIMIT 8"

);
/* =====================================================
   DATABASE ERROR
===================================================== */

if (!$product_query) {

    echo '

        <div class="col-12 text-center">

            <div class="no-product">

                <i class="fa fa-database"></i>

                <h4>
                    Database Error
                </h4>

                <p>
                    ' .
                    htmlspecialchars(
                        mysqli_error($conn)
                    )
                    . '
                </p>

            </div>

        </div>

    ';

}


/* =====================================================
   PRODUCTS FOUND
===================================================== */

elseif (
    mysqli_num_rows($product_query) > 0
) {


    while (
        $product =
        mysqli_fetch_assoc(
            $product_query
        )
    ) {


        /* =================================================
           CAKE NAME
        ================================================= */

        $cake_name =
            $product['cake_name'];

        $cake_name_safe =
            mysqli_real_escape_string(
                $conn,
                $cake_name
            );


        /* =================================================
           FEEDBACK
        ================================================= */

        $feedback_query =
            mysqli_query(

                $conn,

                "SELECT
                    AVG(rating) AS avg_rating,
                    COUNT(*) AS total_reviews
                 FROM feedback
                 WHERE cake_name='$cake_name_safe'"

            );


        $avg_rating = 0;

        $total_reviews = 0;


        if ($feedback_query) {

            $feedback_data =
                mysqli_fetch_assoc(
                    $feedback_query
                );


            if (
                $feedback_data &&
                $feedback_data['avg_rating'] !== null
            ) {

                $avg_rating =
                    round(
                        $feedback_data['avg_rating'],
                        1
                    );

            }


            if ($feedback_data) {

                $total_reviews =
                    (int)
                    $feedback_data[
                        'total_reviews'
                    ];

            }

        }


        $rounded_rating =
            round($avg_rating);

?>



        <!-- PRODUCT CARD -->

        <div class="col-lg-3 col-md-6">

            <div class="product-card">


                <!-- IMAGE -->

                <img
                    src="img/<?php
                        echo htmlspecialchars(
                            $product['image']
                        );
                    ?>"
                    alt="<?php
                        echo htmlspecialchars(
                            $product['cake_name']
                        );
                    ?>"
                >


                <!-- BODY -->

                <div class="product-body">


                    <!-- NAME -->

                    <h5>

                        <?php
                        echo htmlspecialchars(
                            $product['cake_name']
                        );
                        ?>

                    </h5>


                    <!-- CATEGORY -->

                    <p class="category">

                        <?php
                        echo htmlspecialchars(
                            $product['category']
                        );
                        ?>

                    </p>


                    <!-- FLAVOUR -->

                    <p>

                        <strong>
                            Flavour:
                        </strong>

                        <?php
                        echo htmlspecialchars(
                            $product['flavour']
                        );
                        ?>

                    </p>


                    <!-- WEIGHT -->

                    <p>

                        <strong>
                            Weight:
                        </strong>

                        <?php
                        echo htmlspecialchars(
                            $product['weight']
                        );
                        ?>

                    </p>


                    <!-- PRICE -->

                    <div class="price">

                        ₹<?php
                        echo number_format(
                            $product['price'],
                            2
                        );
                        ?>

                    </div>


                    <!-- RATING -->

                    <div class="rating">

                        <?php

                        for (
                            $i = 1;
                            $i <= 5;
                            $i++
                        ) {

                            if (
                                $i <=
                                $rounded_rating
                            ) {

                                echo
                                '<span class="star">★</span>';

                            } else {

                                echo
                                '<span class="star empty">★</span>';

                            }

                        }

                        ?>


                        <?php
                        if (
                            $total_reviews > 0
                        ) {
                        ?>

                            <span
                                class="rating-number"
                            >

                                <?php
                                echo $avg_rating;
                                ?>

                            </span>

                            <span
                                class="reviews"
                            >

                                (
                                <?php
                                echo $total_reviews;
                                ?>
                                Reviews)

                            </span>


                        <?php
                        } else {
                        ?>

                            <span
                                class="reviews"
                            >
                                No Reviews
                            </span>

                        <?php } ?>

                    </div>


                    <!-- VIEW PRODUCT -->

                    <a
                        href="product.php?id=<?php
                            echo intval(
                                $product['id']
                            );
                        ?>"
                        class="view-product-btn"
                    >

                        View Product

                    </a>

                </div>

            </div>

        </div>


<?php

    }

}


/* =====================================================
   NO PRODUCTS
===================================================== */

else {

?>

    <div class="col-12 text-center">

        <div class="no-product">

            <i class="fa fa-search"></i>

            <h4>
                No Cakes Found
            </h4>

            <p>

                No cake found for
                "<?php
                echo htmlspecialchars(
                    $search
                );
                ?>"

            </p>

        </div>

    </div>

<?php

}

?>

        </div>



        <!-- VIEW ALL -->

        <?php if ($search == "") { ?>

            <div
                class="text-center mt-5"
            >

                <a
                    href="product.php"
                    class="view-all-btn"
                >

                    View All Cakes

                </a>

            </div>

        <?php } ?>


    </div>

</section>



<!-- =====================================================
     FOOTER
===================================================== -->

<footer
    class="swiffin-footer"
    style="margin-top:90px;"
>

    <div class="container">

        <div class="row g-0">


            <!-- =================================================
                 FOOTER BRAND
            ================================================== -->

           <div class="col-lg-4 col-md-6">

    <div class="footer-brand-box">

        <!-- LOGO -->

        <a
            href="index1.php"
            class="footer-logo"
        >

            <div class="footer-logo-icon">

                <img
                    src="img/logo.png"
                    alt="SWIFFIN Logo"
                >

            </div>

            <div class="footer-logo-text fw-bold">

                SWIFFIN

            </div>

        </a>
                    <!-- TAGLINE -->

                    <h6 class="footer-tagline">

                        BAKED WITH LOVE

                    </h6>


                    <!-- DESCRIPTION -->

                    <p class="footer-description">

                        Freshly baked cakes made with
                        premium ingredients and lots of love.
                        Make every celebration sweeter with
                        SWIFFIN.

                    </p>


                    <!-- DECORATION -->

                    <div class="footer-decoration">

                        <span></span>

                        <i class="fa fa-birthday-cake"></i>

                        <span></span>

                    </div>


                    <!-- MINI TEXT -->

                    <div class="footer-mini-text">

                        SWEET • FRESH • DELICIOUS

                    </div>

                </div>

            </div>



            <!-- =================================================
                 FOOTER DETAILS
            ================================================== -->

            <div class="col-lg-8 col-md-6">

                <div class="footer-content">

                    <div class="row">


                        <!-- =================================================
                             GET IN TOUCH
                        ================================================== -->

                        <div
                            class="col-lg-4 col-md-12 mb-5"
                        >

                            <h4 class="footer-title">

                                Get In Touch

                            </h4>


                            <!-- ADDRESS -->

                            <div class="footer-info">

                                <div class="footer-info-icon">

                                    <i class="bi bi-geo-alt-fill"></i>

                                </div>

                                <div>

                                    <small>
                                        Visit Us
                                    </small>

                                    <p>
                                        Amreli, Gujarat, India
                                    </p>

                                </div>

                            </div>


                            <!-- EMAIL -->

                            <div class="footer-info">

                                <div class="footer-info-icon">

                                    <i class="bi bi-envelope-fill"></i>

                                </div>

                                <div>

                                    <small>
                                        Email Us
                                    </small>

                                    <p>
                                        Swiffin10@gmail.com
                                    </p>

                                </div>

                            </div>


                            <!-- PHONE -->

                            <div class="footer-info">

                                <div class="footer-info-icon">

                                    <i class="bi bi-telephone-fill"></i>

                                </div>

                                <div>

                                    <small>
                                        Call Us
                                    </small>

                                    <p>
                                        +91 9876543210
                                    </p>

                                </div>

                            </div>


                            <!-- SOCIAL -->

                            <div class="social-title">

                                Follow Us

                            </div>


                            <div class="social-icons">


                                <a
                                    href="#"
                                    class="social-icon"
                                    title="Facebook"
                                >

                                    <i class="fab fa-facebook-f"></i>

                                </a>


                                <a
                                    href="#"
                                    class="social-icon"
                                    title="Instagram"
                                >

                                    <i class="fab fa-instagram"></i>

                                </a>


                                <a
                                    href="#"
                                    class="social-icon"
                                    title="WhatsApp"
                                >

                                    <i class="fab fa-whatsapp"></i>

                                </a>


                                <a
                                    href="#"
                                    class="social-icon"
                                    title="LinkedIn"
                                >

                                    <i class="fab fa-linkedin-in"></i>

                                </a>


                            </div>

                        </div>



                        <!-- =================================================
                             QUICK LINKS
                        ================================================== -->

                        <div
                            class="col-lg-4 col-md-12 mb-5"
                        >

                            <h4 class="footer-title">

                                Quick Links

                            </h4>


                            <div class="footer-links">


                                <a href="index1.php">

                                    <span class="link-icon">

                                        <i class="bi bi-chevron-right"></i>

                                    </span>

                                    Home

                                </a>


                                <a href="about.php">

                                    <span class="link-icon">

                                        <i class="bi bi-chevron-right"></i>

                                    </span>

                                    About Us

                                </a>


                                <a href="product.php">

                                    <span class="link-icon">

                                        <i class="bi bi-chevron-right"></i>

                                    </span>

                                    Our Cakes

                                </a>


                                <a href="contact.php">

                                    <span class="link-icon">

                                        <i class="bi bi-chevron-right"></i>

                                    </span>

                                    Contact Us

                                </a>


                                <?php
                                if (
                                    $customer_logged_in
                                ) {
                                ?>

                                    <a href="carts.php">

                                        <span class="link-icon">

                                            <i class="bi bi-cart3"></i>

                                        </span>

                                        My Cart

                                    </a>

                                <?php } ?>


                            </div>

                        </div>



                        <!-- =================================================
                             NEWSLETTER
                        ================================================== -->

                        <div
                            class="col-lg-4 col-md-12 mb-5"
                        >

                            <h4 class="footer-title">

                                Newsletter

                            </h4>


                            <p class="newsletter-text">

                                Stay updated with our latest
                                cakes, special offers and
                                delicious new arrivals.

                            </p>


                            <form
                                action=""
                                method="POST"
                            >

                                <div class="newsletter-box">

                                    <i class="bi bi-envelope"></i>


                                    <input
                                        type="email"
                                        name="newsletter_email"
                                        placeholder="Your Email"
                                        required
                                    >


                                    <button
                                        type="submit"
                                        title="Subscribe"
                                    >

                                        <i class="bi bi-arrow-right"></i>

                                    </button>

                                </div>

                            </form>


                            <div class="newsletter-note">

                                <i class="bi bi-shield-check"></i>

                                We respect your privacy.

                            </div>

                        </div>


                    </div>

                </div>

            </div>


        </div>

    </div>

</footer>



<!-- =====================================================
     COPYRIGHT
===================================================== -->

<div class="copyright-section">

    <div class="container">

        <div class="row align-items-center">


            <div class="col-md-6 text-center text-md-start">

                <p class="copyright-text mb-0">

                    © <?php echo date("Y"); ?>

                    <a href="index1.php">

                        SWIFFIN Cake Shop

                    </a>

                    . All Rights Reserved.

                </p>

            </div>


            <div class="col-md-6 text-center text-md-end">

                <p class="copyright-text mb-0">

                    Freshly Baked

                    <i class="fa fa-heart"></i>

                    With Love

                </p>

            </div>


        </div>

    </div>

</div>



<!-- =====================================================
     BACK TO TOP
===================================================== -->

<a
    href="#"
    class="swiffin-top"
    title="Back to Top"
    aria-label="Back to Top"
>

    <i class="bi bi-arrow-up"></i>

</a>



<!-- =====================================================
     JAVASCRIPT
===================================================== -->

<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>

<script src="lib/easing/easing.min.js"></script>

<script src="lib/waypoints/waypoints.min.js"></script>

<script src="lib/counterup/counterup.min.js"></script>

<script src="lib/owlcarousel/owl.carousel.min.js"></script>

<script src="js/main.js"></script>


<script>

/* =====================================================
   BACK TO TOP
===================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const topButton =
            document.querySelector(
                ".swiffin-top"
            );


        if (!topButton) {
            return;
        }


        window.addEventListener(
            "scroll",
            function () {

                if (
                    window.scrollY > 300
                ) {

                    topButton.style.opacity = "1";

                    topButton.style.visibility =
                        "visible";

                } else {

                    topButton.style.opacity = "0";

                    topButton.style.visibility =
                        "hidden";

                }

            }
        );


        topButton.addEventListener(
            "click",
            function (e) {

                e.preventDefault();

                window.scrollTo({

                    top: 0,

                    behavior: "smooth"

                });

            }
        );

    }
);


/* =====================================================
   SUBMENU HOVER
===================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const submenuItems =
            document.querySelectorAll(
                ".dropdown-submenu"
            );


        submenuItems.forEach(
            function (item) {

                item.addEventListener(
                    "mouseenter",
                    function () {

                        const menu =
                            item.querySelector(
                                ":scope > .dropdown-menu"
                            );

                        if (menu) {

                            menu.style.display =
                                "block";

                        }

                    }
                );


                item.addEventListener(
                    "mouseleave",
                    function () {

                        const menu =
                            item.querySelector(
                                ":scope > .dropdown-menu"
                            );

                        if (menu) {

                            menu.style.display =
                                "";

                        }

                    }
                );

            }
        );

    }
);

</script>


</body>

</html>

