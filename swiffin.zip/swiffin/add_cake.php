
<?php

session_start();

include("config.php");


/* =====================================================
   ADMIN LOGIN CHECK
===================================================== */

if (
    !isset($_SESSION['admin']) &&
    !isset($_SESSION['admin_name'])
) {
    header("Location: admin.php");
    exit();
}


/* =====================================================
   VARIABLES
===================================================== */

$message = "";
$message_type = "";

$image_folder = "img/cakes/";


$cake_name = "";
$category_id = "";
$flavor_id = "";
$price = "";
$weight = "";
$description = "";
$status = "Active";


/* =====================================================
   CREATE IMAGE FOLDER
===================================================== */

if (!is_dir($image_folder)) {
    mkdir($image_folder, 0777, true);
}


/* =====================================================
   ADD CAKE
===================================================== */

if (isset($_POST['add_cake'])) {

    $cake_name = trim($_POST['cake_name'] ?? "");

    $category_id = intval(
        $_POST['category_id'] ?? 0
    );

    $flavor_id = intval(
        $_POST['flavor_id'] ?? 0
    );

    $price = trim(
        $_POST['price'] ?? ""
    );

    $weight = trim(
        $_POST['weight'] ?? ""
    );

    $description = trim(
        $_POST['description'] ?? ""
    );

    $status = trim(
        $_POST['status'] ?? "Active"
    );

    $image_name = "";


    /* =================================================
       VALIDATION
    ================================================= */

    if ($cake_name == "") {

        $message = "Cake name is required.";
        $message_type = "error";

    } elseif ($category_id <= 0) {

        $message = "Please select category.";
        $message_type = "error";

    } elseif ($flavor_id <= 0) {

        $message = "Please select flavor.";
        $message_type = "error";

    } elseif (
        $price == "" ||
        !is_numeric($price) ||
        floatval($price) <= 0
    ) {

        $message = "Please enter valid price.";
        $message_type = "error";

    } else {


        /* =================================================
           GET CATEGORY NAME AUTOMATICALLY
           
           category_id -> category.id
           category    -> category.category_name
        ================================================= */

        $category_stmt = mysqli_prepare(
            $conn,
            "SELECT id, category_name, parent_id
             FROM category
             WHERE id = ?
             AND status = 'Active'
             LIMIT 1"
        );


        if (!$category_stmt) {

            $message =
                "Category Prepare Error: " .
                mysqli_error($conn);

            $message_type = "error";

        } else {

            mysqli_stmt_bind_param(
                $category_stmt,
                "i",
                $category_id
            );

            mysqli_stmt_execute(
                $category_stmt
            );

            $category_query =
                mysqli_stmt_get_result(
                    $category_stmt
                );

            $selected_category =
                mysqli_fetch_assoc(
                    $category_query
                );

            mysqli_stmt_close(
                $category_stmt
            );


            if (!$selected_category) {

                $message =
                    "Selected category is invalid.";

                $message_type = "error";

            } else {

                /*
                 * IMPORTANT
                 *
                 * Category name automatic:
                 *
                 * category_id = selected category ID
                 * category    = selected category name
                 */

                $category_name =
                    trim(
                        $selected_category[
                            'category_name'
                        ]
                    );


                /* =================================================
                   CHECK FLAVOR
                ================================================= */

                $flavor_stmt = mysqli_prepare(
                    $conn,
                    "SELECT id
                     FROM flavor
                     WHERE id = ?
                     AND status = 'Active'
                     LIMIT 1"
                );


                if (!$flavor_stmt) {

                    $message =
                        "Flavor Prepare Error: " .
                        mysqli_error($conn);

                    $message_type = "error";

                } else {

                    mysqli_stmt_bind_param(
                        $flavor_stmt,
                        "i",
                        $flavor_id
                    );

                    mysqli_stmt_execute(
                        $flavor_stmt
                    );

                    $flavor_query =
                        mysqli_stmt_get_result(
                            $flavor_stmt
                        );

                    $flavor_exists =
                        mysqli_num_rows(
                            $flavor_query
                        );

                    mysqli_stmt_close(
                        $flavor_stmt
                    );


                    if ($flavor_exists == 0) {

                        $message =
                            "Selected flavor is invalid.";

                        $message_type = "error";

                    }
                }


                /* =================================================
                   IMAGE UPLOAD
                ================================================= */

                if ($message == "") {

                    if (
                        isset($_FILES['image']) &&
                        $_FILES['image']['error'] == 0
                    ) {

                        $allowed = array(
                            "jpg",
                            "jpeg",
                            "png",
                            "webp"
                        );


                        $extension =
                            strtolower(
                                pathinfo(
                                    $_FILES['image']['name'],
                                    PATHINFO_EXTENSION
                                )
                            );


                        if (
                            !in_array(
                                $extension,
                                $allowed
                            )
                        ) {

                            $message =
                                "Only JPG, JPEG, PNG and WEBP images are allowed.";

                            $message_type = "error";

                        } else {

                            $image_name =
                                time() .
                                "_" .
                                uniqid() .
                                "." .
                                $extension;


                            if (
                                !move_uploaded_file(
                                    $_FILES['image']['tmp_name'],
                                    $image_folder .
                                    $image_name
                                )
                            ) {

                                $message =
                                    "Image upload failed.";

                                $message_type = "error";
                            }
                        }
                    }
                }


                /* =================================================
                   INSERT CAKE
                   
                   IMPORTANT:
                   
                   category_id = FK category.id
                   category    = category.category_name
                   
                   Both are saved automatically.
                ================================================= */

                if ($message == "") {

                    $sql = "

                        INSERT INTO cake
                        (
                            cake_name,
                            category,
                            category_id,
                            flavor_id,
                            price,
                            weight,
                            image,
                            description,
                            status
                        )

                        VALUES
                        (
                            ?,
                            ?,
                            ?,
                            ?,
                            ?,
                            ?,
                            ?,
                            ?,
                            ?
                        )

                    ";


                    $stmt =
                        mysqli_prepare(
                            $conn,
                            $sql
                        );


                    if (!$stmt) {

                        $message =
                            "Database Prepare Error: " .
                            mysqli_error($conn);

                        $message_type = "error";

                    } else {

                        $price_value =
                            floatval($price);


                        mysqli_stmt_bind_param(
                            $stmt,
                            "ssiidssss",
                            $cake_name,
                            $category_name,
                            $category_id,
                            $flavor_id,
                            $price_value,
                            $weight,
                            $image_name,
                            $description,
                            $status
                        );


                        if (
                            mysqli_stmt_execute(
                                $stmt
                            )
                        ) {

                            $message =
                                "Cake added successfully!";

                            $message_type =
                                "success";


                            /* CLEAR FORM */

                            $cake_name = "";
                            $category_id = "";
                            $flavor_id = "";
                            $price = "";
                            $weight = "";
                            $description = "";
                            $status = "Active";

                        } else {

                            /* DELETE IMAGE IF INSERT FAILS */

                            if (
                                $image_name != "" &&
                                file_exists(
                                    $image_folder .
                                    $image_name
                                )
                            ) {

                                unlink(
                                    $image_folder .
                                    $image_name
                                );
                            }


                            $message =
                                "Database Error: " .
                                mysqli_stmt_error(
                                    $stmt
                                );

                            $message_type =
                                "error";
                        }


                        mysqli_stmt_close(
                            $stmt
                        );
                    }
                }
            }
        }
    }
}


/* =====================================================
   GET PARENT CATEGORIES
===================================================== */

$parent_categories = array();


$parent_sql = "

    SELECT
        id,
        category_name,
        parent_id

    FROM category

    WHERE
        parent_id = 0
        AND status = 'Active'

    ORDER BY category_name ASC

";


$parent_result =
    mysqli_query(
        $conn,
        $parent_sql
    );


if ($parent_result) {

    while (
        $parent =
        mysqli_fetch_assoc(
            $parent_result
        )
    ) {

        $parent_categories[] =
            $parent;
    }
}


/* =====================================================
   GET CHILD CATEGORIES
===================================================== */

function getChildCategories(
    $conn,
    $parent_id
) {

    $children = array();

    $parent_id =
        intval($parent_id);


    $sql = "

        SELECT
            id,
            category_name,
            parent_id

        FROM category

        WHERE
            parent_id = $parent_id
            AND status = 'Active'

        ORDER BY category_name ASC

    ";


    $result =
        mysqli_query(
            $conn,
            $sql
        );


    if ($result) {

        while (
            $row =
            mysqli_fetch_assoc(
                $result
            )
        ) {

            $children[] =
                $row;
        }
    }


    return $children;
}


/* =====================================================
   GET FLAVORS
===================================================== */

$flavor_result = mysqli_query(
    $conn,

    "SELECT
        id,
        flavor_name

     FROM flavor

     WHERE status = 'Active'

     ORDER BY flavor_name ASC"
);


if (!$flavor_result) {

    $message =
        "Flavor query error: " .
        mysqli_error($conn);

    $message_type = "error";
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Add Cake | SWIFFIN
</title>


<style>

/* =====================================================
   RESET
===================================================== */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


/* =====================================================
   BODY
===================================================== */

body {

    font-family: Arial, sans-serif;

    background: #000;

    color: #fff;
}


/* =====================================================
   SIDEBAR
===================================================== */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;

    height: 100vh;

    background: #111;

    border-right: 1px solid #333;

    overflow-y: auto;
}


.logo {

    height: 75px;

    display: flex;

    align-items: center;

    justify-content: center;

    color: #E88F2A;

    font-size: 28px;

    font-weight: bold;

    letter-spacing: 3px;

    border-bottom: 1px solid #333;
}


.admin-box {

    text-align: center;

    padding: 20px;

    border-bottom: 1px solid #333;
}


.admin-icon {

    width: 48px;
    height: 48px;

    margin: 0 auto 10px;

    border-radius: 50%;

    background: #E88F2A;

    color: #000;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 22px;
}


.admin-box h4 {
    margin-bottom: 5px;
}


.admin-box p {

    color: #777;

    font-size: 12px;
}


.menu-title {

    color: #666;

    font-size: 11px;

    font-weight: bold;

    padding: 18px 20px 8px;

    text-transform: uppercase;

    letter-spacing: 1px;
}


.sidebar a {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 12px 20px;

    color: #bbb;

    text-decoration: none;

    font-size: 14px;

    transition: .3s;
}


.sidebar a:hover {

    background: #1b1b1b;

    color: #E88F2A;

    border-left: 3px solid #E88F2A;
}


.sidebar a.active {

    background: rgba(232,143,42,.12);

    color: #E88F2A;

    border-left: 3px solid #E88F2A;
}


.icon {

    width: 22px;

    min-width: 22px;

    text-align: center;
}


/* =====================================================
   MAIN
===================================================== */

.main {

    margin-left: 250px;

    min-height: 100vh;
}


/* =====================================================
   TOPBAR
===================================================== */

.topbar {

    height: 75px;

    background: #111;

    border-bottom: 1px solid #333;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;
}


.topbar h2 {
    font-size: 22px;
}


.topbar p {

    color: #777;

    font-size: 12px;

    margin-top: 5px;
}


.admin-name {

    color: #aaa;

    font-size: 14px;
}


.admin-name span {

    color: #E88F2A;

    font-weight: bold;
}


.logout {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    background: #E88F2A;

    color: #fff;

    text-decoration: none;

    padding: 9px 18px;

    border-radius: 5px;

    margin-left: 15px;

    font-size: 13px;

    font-weight: bold;
}


.logout:hover {

    background: #fff;

    color: #000;
}


/* =====================================================
   CONTENT
===================================================== */

.content {
    padding: 30px;
}


.page-title {
    margin-bottom: 25px;
}


.page-title h1 {

    color: #E88F2A;

    font-size: 27px;

    margin-bottom: 7px;
}


.page-title p {

    color: #777;

    font-size: 13px;
}


/* =====================================================
   MESSAGE
===================================================== */

.message {

    padding: 13px 16px;

    border-radius: 6px;

    margin-bottom: 20px;

    font-size: 14px;
}


.message.success {

    background: #132b18;

    border: 1px solid #287a3e;

    color: #65d77c;
}


.message.error {

    background: #2b1111;

    border: 1px solid #8b3030;

    color: #ff7777;
}


/* =====================================================
   FORM BOX
===================================================== */

.form-box {

    background: #111;

    border: 1px solid #333;

    border-radius: 8px;

    padding: 25px;

    max-width: 1000px;
}


.form-box h2 {

    font-size: 20px;

    margin-bottom: 25px;

    color: #fff;
}


/* =====================================================
   FORM GRID
===================================================== */

.form-grid {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 20px;
}


.form-group label {

    display: block;

    color: #E88F2A;

    font-size: 13px;

    font-weight: bold;

    margin-bottom: 8px;
}


.form-group input,
.form-group select,
.form-group textarea {

    width: 100%;

    padding: 12px;

    background: #050505;

    color: #fff;

    border: 1px solid #444;

    border-radius: 5px;

    outline: none;
}


.form-group input,
.form-group select {
    height: 44px;
}


.form-group textarea {

    height: 100px;

    resize: vertical;
}


.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {

    border-color: #E88F2A;

    box-shadow:
        0 0 7px rgba(232,143,42,.2);
}


.form-group input[type="file"] {

    padding: 9px;

    cursor: pointer;
}


/* =====================================================
   CATEGORY SELECT
===================================================== */

.category-parent {

    font-weight: bold;

    color: #E88F2A;

    background: #111;
}


.category-child {

    padding-left: 20px;
}


/* =====================================================
   FULL WIDTH
===================================================== */

.full-width {
    grid-column: 1 / -1;
}


/* =====================================================
   BUTTON
===================================================== */

.add-btn {

    margin-top: 25px;

    width: 180px;

    height: 44px;

    background: #E88F2A;

    color: #fff;

    border: none;

    border-radius: 6px;

    font-weight: bold;

    cursor: pointer;
}


.add-btn:hover {

    background: #fff;

    color: #000;
}


/* =====================================================
   FOOTER
===================================================== */

.footer {

    text-align: center;

    padding: 20px;

    color: #555;

    border-top: 1px solid #222;

    margin-top: 40px;

    font-size: 12px;
}


.footer span {
    color: #E88F2A;
}


/* =====================================================
   RESPONSIVE
===================================================== */

@media(max-width:800px) {

    .sidebar {
        width: 70px;
    }


    .logo {
        font-size: 0;
    }


    .logo::after {

        content: "S";

        font-size: 28px;

        color: #E88F2A;
    }


    .admin-box h4,
    .admin-box p,
    .menu-title,
    .sidebar a span:not(.icon) {

        display: none;
    }


    .sidebar a {

        justify-content: center;

        padding: 13px 5px;
    }


    .main {
        margin-left: 70px;
    }


    .form-grid {
        grid-template-columns: 1fr;
    }


    .full-width {
        grid-column: auto;
    }

}

</style>

</head>


<body>


<!-- =====================================================
     SIDEBAR
===================================================== -->

<div class="sidebar">

    <div class="logo">
        SWIFFIN
    </div>


    <div class="admin-box">

        <div class="admin-icon">
            👤
        </div>


        <h4>

            <?php

            echo htmlspecialchars(
                $_SESSION['admin_name']
                ?? $_SESSION['admin']
                ?? 'Admin'
            );

            ?>

        </h4>


        <p>
            Administrator
        </p>

    </div>


    <div class="menu-title">
        Main Menu
    </div>


    <a href="admin_dashboard.php">

        <span class="icon">🏠</span>

        <span>Dashboard</span>

    </a>


    <div class="menu-title">
        Cake Management
    </div>


    <a
        href="add_cake.php"
        class="active"
    >

        <span class="icon">🍰</span>

        <span>Add Cake</span>

    </a>


    <a href="view_cake.php">

        <span class="icon">👁️</span>

        <span>View Cakes</span>

    </a>


    <a href="edit_cake.php">

        <span class="icon">📝</span>

        <span>Edit Cake</span>

    </a>


    <a href="delete_cake.php">

        <span class="icon">🗑️</span>

        <span>Delete Cake</span>

    </a>


    <a href="category.php">

        <span class="icon">📂</span>

        <span>Categories</span>

    </a>


    <a href="flavor.php">

        <span class="icon">🍓</span>

        <span>Flavors</span>

    </a>


    <div class="menu-title">
        Sales Management
    </div>


    <a href="order.php">

        <span class="icon">📦</span>

        <span>Orders</span>

    </a>


    <a href="customer.php">

        <span class="icon">👥</span>

        <span>Customers</span>

    </a>


    <a href="carts.php">

        <span class="icon">🛒</span>

        <span>Carts</span>

    </a>


    <a href="payment.php">

        <span class="icon">💳</span>

        <span>Payments</span>

    </a>


    <div class="menu-title">
        Other Management
    </div>


    <a href="stock.php">

        <span class="icon">📊</span>

        <span>Stock</span>

    </a>


    <a href="delivery.php">

        <span class="icon">🚚</span>

        <span>Delivery</span>

    </a>


    <a href="feedback.php">

        <span class="icon">⭐</span>

        <span>Feedback</span>

    </a>


    <a href="reports.php">

        <span class="icon">📈</span>

        <span>Reports</span>

    </a>


    <a href="offers.php">

        <span class="icon">🎁</span>

        <span>Offers</span>

    </a>


    <a href="staff.php">

        <span class="icon">👨‍💼</span>

        <span>Staff</span>

    </a>


    <a href="enquiry.php">

        <span class="icon">📩</span>

        <span>Enquiries</span>

    </a>


    <a href="settings.php">

        <span class="icon">⚙️</span>

        <span>Settings</span>

    </a>


    <a href="logout.php">

        <span class="icon">🚪</span>

        <span>Logout</span>

    </a>

</div>


<!-- =====================================================
     MAIN
===================================================== -->

<div class="main">


    <!-- TOPBAR -->

    <div class="topbar">

        <div>

            <h2>
                Add Cake
            </h2>

            <p>
                Add new cake to Swiffin Cake Shop
            </p>

        </div>


        <div>

            <span class="admin-name">

                Welcome,

                <span>

                    <?php

                    echo htmlspecialchars(
                        $_SESSION['admin_name']
                        ?? $_SESSION['admin']
                        ?? 'Admin'
                    );

                    ?>

                </span>

            </span>


            <a
                href="logout.php"
                class="logout"
            >
                Logout
            </a>

        </div>

    </div>


    <!-- CONTENT -->

    <div class="content">


        <div class="page-title">

            <h1>
                🍰 Add New Cake
            </h1>

            <p>
                Enter cake details and add it to your shop.
            </p>

        </div>


        <!-- MESSAGE -->

        <?php if ($message != "") { ?>

            <div
                class="message
                <?php echo htmlspecialchars(
                    $message_type
                ); ?>"
            >

                <?php

                echo htmlspecialchars(
                    $message
                );

                ?>

            </div>

        <?php } ?>


        <!-- FORM -->

        <div class="form-box">

            <h2>
                Cake Information
            </h2>


            <form
                method="POST"
                enctype="multipart/form-data"
            >


                <div class="form-grid">


                    <!-- CAKE NAME -->

                    <div class="form-group">

                        <label>
                            Cake Name
                        </label>

                        <input
                            type="text"
                            name="cake_name"
                            placeholder="Example: Oreo Cream Cake"
                            value="<?php
                            echo htmlspecialchars(
                                $cake_name
                            );
                            ?>"
                            required
                        >

                    </div>


                    <!-- CATEGORY -->

                    <div class="form-group">

                        <label>
                            Category
                        </label>


                        <select
                            name="category_id"
                            required
                        >

                            <option value="">
                                Select Category
                            </option>


                            <?php

                            if (
                                count(
                                    $parent_categories
                                ) > 0
                            ) {


                                foreach (
                                    $parent_categories
                                    as $parent
                                ) {


                                    $parent_id =
                                        intval(
                                            $parent['id']
                                        );


                                    $children =
                                        getChildCategories(
                                            $conn,
                                            $parent_id
                                        );

                            ?>


                                <!-- PARENT -->

                                <option
                                    value="<?php
                                    echo $parent_id;
                                    ?>"
                                    class="category-parent"

                                    <?php

                                    if (
                                        intval(
                                            $category_id
                                        ) ==
                                        $parent_id
                                    ) {

                                        echo "selected";
                                    }

                                    ?>
                                >

                                    <?php

                                    echo
                                        htmlspecialchars(
                                            $parent[
                                                'category_name'
                                            ]
                                        );

                                    ?>

                                    (Parent)

                                </option>


                                <?php


                                /* =================================================
                                   CHILDREN
                                ================================================= */

                                foreach (
                                    $children
                                    as $child
                                ) {

                                    $child_id =
                                        intval(
                                            $child['id']
                                        );

                                ?>

                                    <option
                                        value="<?php
                                        echo $child_id;
                                        ?>"

                                        <?php

                                        if (
                                            intval(
                                                $category_id
                                            ) ==
                                            $child_id
                                        ) {

                                            echo "selected";
                                        }

                                        ?>
                                    >

                                        &nbsp;&nbsp;&nbsp;↳

                                        <?php

                                        echo
                                            htmlspecialchars(
                                                $child[
                                                    'category_name'
                                                ]
                                            );

                                        ?>

                                    </option>

                                <?php

                                }

                            }

                        } else {

                        ?>

                            <option value="">
                                No Category Available
                            </option>

                        <?php

                        }

                        ?>

                        </select>

                    </div>


                    <!-- FLAVOR -->

                    <div class="form-group">

                        <label>
                            Flavor
                        </label>

                        <select
                            name="flavor_id"
                            required
                        >

                            <option value="">
                                Select Flavor
                            </option>


                            <?php

                            if (
                                $flavor_result &&
                                mysqli_num_rows(
                                    $flavor_result
                                ) > 0
                            ) {

                                while (
                                    $flavor =
                                    mysqli_fetch_assoc(
                                        $flavor_result
                                    )
                                ) {

                            ?>

                                <option
                                    value="<?php
                                    echo intval(
                                        $flavor['id']
                                    );
                                    ?>"

                                    <?php

                                    if (
                                        intval(
                                            $flavor_id
                                        ) ==
                                        intval(
                                            $flavor['id']
                                        )
                                    ) {

                                        echo "selected";
                                    }

                                    ?>
                                >

                                    <?php

                                    echo
                                        htmlspecialchars(
                                            $flavor[
                                                'flavor_name'
                                            ]
                                        );

                                    ?>

                                </option>

                            <?php

                                }

                            } else {

                            ?>

                                <option value="">
                                    No Flavor Available
                                </option>

                            <?php

                            }

                            ?>

                        </select>

                    </div>


                    <!-- PRICE -->

                    <div class="form-group">

                        <label>
                            Price (₹)
                        </label>

                        <input
                            type="number"
                            name="price"
                            placeholder="Example: 500"
                            min="1"
                            step="0.01"
                            value="<?php
                            echo htmlspecialchars(
                                $price
                            );
                            ?>"
                            required
                        >

                    </div>


                    <!-- WEIGHT -->

                    <div class="form-group">

                        <label>
                            Weight
                        </label>

                        <select name="weight">

                            <option value="">
                                Select Weight
                            </option>

                            <option
                                value="500g"
                                <?php
                                echo
                                    ($weight == "500g")
                                    ? "selected"
                                    : "";
                                ?>
                            >
                                500g
                            </option>

                            <option
                                value="1kg"
                                <?php
                                echo
                                    ($weight == "1kg")
                                    ? "selected"
                                    : "";
                                ?>
                            >
                                1 Kg
                            </option>

                            <option
                                value="1.5kg"
                                <?php
                                echo
                                    ($weight == "1.5kg")
                                    ? "selected"
                                    : "";
                                ?>
                            >
                                1.5 Kg
                            </option>

                            <option
                                value="2kg"
                                <?php
                                echo
                                    ($weight == "2kg")
                                    ? "selected"
                                    : "";
                                ?>
                            >
                                2 Kg
                            </option>

                            <option
                                value="2.5kg"
                                <?php
                                echo
                                    ($weight == "2.5kg")
                                    ? "selected"
                                    : "";
                                ?>
                            >
                                2.5 Kg
                            </option>

                            <option
                                value="3kg"
                                <?php
                                echo
                                    ($weight == "3kg")
                                    ? "selected"
                                    : "";
                                ?>
                            >
                                3 Kg
                            </option>

                        </select>

                    </div>


                    <!-- STATUS -->

                    <div class="form-group">

                        <label>
                            Status
                        </label>

                        <select name="status">

                            <option
                                value="Active"
                                <?php
                                echo
                                    ($status == "Active")
                                    ? "selected"
                                    : "";
                                ?>
                            >
                                Active
                            </option>

                            <option
                                value="Inactive"
                                <?php
                                echo
                                    ($status == "Inactive")
                                    ? "selected"
                                    : "";
                                ?>
                            >
                                Inactive
                            </option>

                        </select>

                    </div>


                    <!-- IMAGE -->

                    <div class="form-group">

                        <label>
                            Cake Image
                        </label>

                        <input
                            type="file"
                            name="image"
                            accept=".jpg,.jpeg,.png,.webp"
                        >

                    </div>


                    <!-- DESCRIPTION -->

                    <div class="form-group full-width">

                        <label>
                            Description
                        </label>

                        <textarea
                            name="description"
                            placeholder="Enter cake description..."
                        ><?php

                        echo htmlspecialchars(
                            $description
                        );

                        ?></textarea>

                    </div>


                </div>


                <button
                    type="submit"
                    name="add_cake"
                    class="add-btn"
                >

                    + Add Cake

                </button>


            </form>

        </div>

    </div>


    <!-- FOOTER -->

    <div class="footer">

        © 2026

        <span>
            SWIFFIN Cake Shop
        </span>

        | Add Cake

    </div>


</div>


</body>

</html>


<?php

mysqli_close($conn);

?>

