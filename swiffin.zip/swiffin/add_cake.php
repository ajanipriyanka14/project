<?php
session_start();
include("config.php");

if (!isset($_SESSION['admin'])) {
    header("Location: admin.php");
    exit();
}

if(isset($_POST['save']))
{
    $cake_name   = $_POST['cake_name'];
    $category    = $_POST['category'];
    $price       = $_POST['price'];
    $flavour     = $_POST['flavour'];
    $weight      = $_POST['weight'];
    $description = $_POST['description'];
    $stock       = $_POST['stock'];
    $status      = $_POST['status'];

    $image = $_FILES['image']['name'];
    $temp  = $_FILES['image']['tmp_name'];

    move_uploaded_file($temp, "img/" . $image);

    $query = "INSERT INTO cake
    (cake_name, category, price, flavour, weight, image, description, stock, status)
    VALUES
    ('$cake_name','$category','$price','$flavour','$weight','$image','$description','$stock','$status')";

    if(mysqli_query($conn, $query))
    {
        echo "<script>alert('Cake Added Successfully'); window.location='view_cake.php';</script>";
    }
    else
    {
        echo "<script>alert('Error! Cake Not Added');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Add Cake | Swiffin Cake Shop</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#000;
    font-family:Arial,sans-serif;
}

.cake-box{
    max-width:700px;
    margin:40px auto;
    background:#1b1b1b;
    padding:35px;
    border-radius:20px;
    box-shadow:0 0 20px rgba(232,143,42,.35);
}

h2{
    color:#E88F2A;
    text-align:center;
    margin-bottom:30px;
    font-weight:bold;
}

label{
    color:#fff;
    font-weight:bold;
}

.form-control,
.form-select{
    background:#2b2b2b;
    color:#fff;
    border:1px solid #555;
}

.form-control:focus,
.form-select:focus{
    background:#2b2b2b;
    color:#fff;
    border-color:#E88F2A;
    box-shadow:none;
}

textarea{
    resize:none;
}

.btn-save{
    width:100%;
    background:#E88F2A;
    color:#fff;
    font-weight:bold;
    padding:12px;
    border:none;
    border-radius:30px;
}

.btn-save:hover{
    background:#d67d18;
    color:#fff;
}

</style>

</head>

<body>

<div class="container">

<div class="cake-box">

<h2>Add New Cake</h2>

<form method="post" enctype="multipart/form-data">

<div class="mb-3">
<label>Cake Name</label>
<input type="text" name="cake_name" class="form-control" required>
</div>

<div class="mb-3">
<label>Category</label>
<input type="text" name="category" class="form-control" required>
</div>

<div class="mb-3">
<label>Price</label>
<input type="number" name="price" class="form-control" required>
</div>

<div class="mb-3">
<label>Flavour</label>
<input type="text" name="flavour" class="form-control" required>
</div>

<div class="mb-3">
<label>Weight</label>
<input type="text" name="weight" class="form-control" required>
</div>

<div class="mb-3">
<label>Cake Image</label>
<input type="file" name="image" class="form-control" required>
</div>

<div class="mb-3">
<label>Description</label>
<textarea name="description" rows="4" class="form-control" required></textarea>
</div>

<div class="mb-3">
<label>Stock</label>
<input type="number" name="stock" class="form-control" required>
</div>

<div class="mb-3">
<label>Status</label>

<select name="status" class="form-select" required>
<option value="Available">Available</option>
<option value="Out of Stock">Out of Stock</option>
</select>

</div>

<button type="submit" name="save" class="btn btn-save">
Add Cake
</button>

</form>

</div>

</div>

</body>
</html>