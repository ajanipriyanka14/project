<?php
session_start();
include "config.php";

$query = "SELECT * FROM payment ORDER BY id DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Payment</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
    body{
        background:#000;
        color:#fff;
    }

    .table{
        background:#1b1b1b;
        color:#fff;
    }

    .table th{
        background:#E88F2A;
        color:#fff;
    }

    h2{
        color:#E88F2A;
    }
    </style>

</head>

<body>

<div class="container mt-5">

<h2 class="text-center mb-4">
Payment Details
</h2>

<table class="table table-bordered table-hover text-center">

<tr>

<th>ID</th>
<th>Order ID</th>
<th>Customer</th>
<th>Method</th>
<th>Amount</th>
<th>Status</th>
<th>Date</th>

</tr>

<?php

while($row=mysqli_fetch_assoc($result))
{

?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['order_id']; ?></td>

<td><?php echo $row['customer_name']; ?></td>

<td><?php echo $row['payment_method']; ?></td>

<td>₹<?php echo $row['amount']; ?></td>

<td>

<?php

if($row['payment_status']=="Paid")
{
    echo "<span class='badge bg-success'>Paid</span>";
}
else
{
    echo "<span class='badge bg-danger'>Pending</span>";
}

?>

</td>

<td><?php echo $row['payment_date']; ?></td>

</tr>

<?php
}
?>

</table>

</div>

</body>
</html>