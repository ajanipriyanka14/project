```php
<?php

session_start();
include "config.php";


/* =====================================================
   UPDATE DELIVERY
===================================================== */

if (isset($_POST['update_delivery'])) {

    $id = intval($_POST['id']);

    $delivery_person = mysqli_real_escape_string(
        $conn,
        $_POST['delivery_person']
    );

    $delivery_status = mysqli_real_escape_string(
        $conn,
        $_POST['delivery_status']
    );


    /* ================= DELIVERY DATE ================= */

    if ($delivery_status == "Delivered") {

        $delivery_date = date("Y-m-d H:i:s");

        $sql = "UPDATE delivery SET
                delivery_person='$delivery_person',
                delivery_status='$delivery_status',
                delivery_date='$delivery_date'
                WHERE id='$id'";

    } else {

        $sql = "UPDATE delivery SET
                delivery_person='$delivery_person',
                delivery_status='$delivery_status'
                WHERE id='$id'";
    }


    /* ================= UPDATE ================= */

    if (mysqli_query($conn, $sql)) {

        echo "<script>
                alert('Delivery Updated Successfully');
                window.location='delivery.php';
              </script>";

        exit();

    } else {

        die("Update Error: " . mysqli_error($conn));
    }
}


/* =====================================================
   GET DELIVERY DATA
===================================================== */

$query = mysqli_query(
    $conn,
    "SELECT * FROM delivery ORDER BY id DESC"
);


if (!$query) {

    die("Database Error: " . mysqli_error($conn));
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Delivery Management | Swiffin Cake Shop
</title>


<!-- Bootstrap -->

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<!-- Font Awesome -->

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
rel="stylesheet"
>


<style>

/* =====================================================
   BODY
===================================================== */

*{
    box-sizing:border-box;
}

body{

    margin:0;

    padding:0;

    background:#000;

    color:#fff;

    font-family:
    Arial,
    Helvetica,
    sans-serif;
}


/* =====================================================
   MAIN
===================================================== */

.main{

    width:95%;

    max-width:1400px;

    margin:40px auto;
}


/* =====================================================
   TITLE
===================================================== */

.page-title{

    text-align:center;

    margin-bottom:30px;
}

.page-title h2{

    color:#E88F2A;

    font-weight:bold;

    margin-bottom:8px;
}

.page-title p{

    color:#aaa;

    margin:0;
}


/* =====================================================
   DELIVERY BOX
===================================================== */

.delivery-box{

    background:#111;

    border:1px solid #E88F2A;

    border-radius:18px;

    padding:25px;

    box-shadow:
    0 0 20px rgba(232,143,42,.25);
}


/* =====================================================
   TABLE
===================================================== */

.table{

    margin:0;

    color:#fff;
}

.table thead th{

    background:#E88F2A !important;

    color:#fff !important;

    text-align:center;

    vertical-align:middle;

    white-space:nowrap;
}

.table tbody td{

    background:#1b1b1b !important;

    color:#fff !important;

    text-align:center;

    vertical-align:middle;

    border-color:#333;
}


/* =====================================================
   INPUT
===================================================== */

.form-control{

    background:#000 !important;

    color:#fff !important;

    border:1px solid #E88F2A;
}

.form-control::placeholder{

    color:#777;
}

.form-control:focus{

    background:#000 !important;

    color:#fff !important;

    border-color:#E88F2A;

    box-shadow:
    0 0 8px rgba(232,143,42,.3);
}


/* =====================================================
   SELECT
===================================================== */

.form-select{

    background:#000 !important;

    color:#fff !important;

    border:1px solid #E88F2A;
}

.form-select:focus{

    background:#000 !important;

    color:#fff !important;

    border-color:#E88F2A;

    box-shadow:
    0 0 8px rgba(232,143,42,.3);
}


/* =====================================================
   UPDATE BUTTON
===================================================== */

.update-btn{

    background:#E88F2A;

    color:#fff;

    border:none;

    border-radius:20px;

    padding:8px 15px;

    font-weight:bold;

    cursor:pointer;
}

.update-btn:hover{

    background:#d67d18;

    color:#fff;
}


/* =====================================================
   REVIEW BUTTON
===================================================== */

.review-btn{

    display:inline-block;

    background:#28a745;

    color:#fff;

    text-decoration:none;

    border-radius:20px;

    padding:8px 14px;

    font-size:13px;

    font-weight:bold;

    white-space:nowrap;
}

.review-btn:hover{

    background:#218838;

    color:#fff;
}


/* =====================================================
   NOT AVAILABLE
===================================================== */

.not-available{

    color:#777;

    font-size:12px;
}


/* =====================================================
   STATUS COLORS
===================================================== */

.status-pending{

    color:#ffc107;

    font-weight:bold;
}

.status-assigned{

    color:#0dcaf0;

    font-weight:bold;
}

.status-delivery{

    color:#0d6efd;

    font-weight:bold;
}

.status-delivered{

    color:#28a745;

    font-weight:bold;
}

.status-cancelled{

    color:#dc3545;

    font-weight:bold;
}


/* =====================================================
   BACK BUTTON
===================================================== */

.back-btn{

    display:inline-block;

    margin-top:25px;

    background:#E88F2A;

    color:#fff;

    text-decoration:none;

    padding:10px 25px;

    border-radius:25px;

    font-weight:bold;
}

.back-btn:hover{

    background:#d67d18;

    color:#fff;
}


/* =====================================================
   MOBILE
===================================================== */

@media(max-width:700px){

    .main{

        width:98%;

        margin:20px auto;
    }

    .delivery-box{

        padding:12px;
    }

    .page-title h2{

        font-size:24px;
    }

}

</style>

</head>


<body>


<div class="main">


<!-- =====================================================
     TITLE
===================================================== -->

<div class="page-title">

<h2>

<i class="fas fa-truck"></i>

Delivery Management

</h2>

<p>

Manage customer deliveries and delivery status

</p>

</div>



<!-- =====================================================
     DELIVERY TABLE
===================================================== -->

<div class="delivery-box">

<div class="table-responsive">


<table class="table table-bordered table-hover">


<thead>

<tr>

<th>ID</th>

<th>Order ID</th>

<th>Customer</th>

<th>Mobile</th>

<th>Address</th>

<th>Delivery Person</th>

<th>Status</th>

<th>Delivery Date</th>

<th>Action</th>

<th>Review</th>

</tr>

</thead>


<tbody>


<?php

if (mysqli_num_rows($query) > 0) {


while ($row = mysqli_fetch_assoc($query)) {

?>


<tr>


<!-- ID -->

<td>

<?php

echo $row['id'];

?>

</td>



<!-- ORDER ID -->

<td>

<strong>

#<?php

echo $row['order_id'];

?>

</strong>

</td>



<!-- CUSTOMER -->

<td>

<?php

echo htmlspecialchars(
    $row['customer_name']
);

?>

</td>



<!-- MOBILE -->

<td>

<?php

echo htmlspecialchars(
    $row['mobile']
);

?>

</td>



<!-- ADDRESS -->

<td>

<?php

echo htmlspecialchars(
    $row['address']
);

?>

</td>



<!-- DELIVERY PERSON -->

<td>


<form method="POST">


<input
type="hidden"
name="id"
value="<?php echo $row['id']; ?>"
>


<input
type="text"
name="delivery_person"
class="form-control"
value="<?php

echo htmlspecialchars(
    $row['delivery_person']
);

?>"
placeholder="Delivery Person"
required
>


</td>



<!-- STATUS -->

<td>


<select
name="delivery_status"
class="form-select"
>


<option
value="Pending"

<?php

if (
    $row['delivery_status']
    ==
    "Pending"
) {

    echo "selected";

}

?>

>

Pending

</option>


<option
value="Assigned"

<?php

if (
    $row['delivery_status']
    ==
    "Assigned"
) {

    echo "selected";

}

?>

>

Assigned

</option>


<option
value="Out For Delivery"

<?php

if (
    $row['delivery_status']
    ==
    "Out For Delivery"
) {

    echo "selected";

}

?>

>

Out For Delivery

</option>


<option
value="Delivered"

<?php

if (
    $row['delivery_status']
    ==
    "Delivered"
) {

    echo "selected";

}

?>

>

Delivered

</option>


<option
value="Cancelled"

<?php

if (
    $row['delivery_status']
    ==
    "Cancelled"
) {

    echo "selected";

}

?>

>

Cancelled

</option>


</select>


</td>



<!-- DELIVERY DATE -->

<td>

<?php

if (!empty($row['delivery_date'])) {

    echo date(
        "d-m-Y h:i A",
        strtotime(
            $row['delivery_date']
        )
    );

} else {

    echo "-";

}

?>

</td>



<!-- ACTION -->

<td>


<button
type="submit"
name="update_delivery"
class="update-btn"
>

<i class="fas fa-save"></i>

Update

</button>


</form>


</td>



<!-- REVIEW -->

<td>


<?php

if (
    $row['delivery_status']
    ==
    "Delivered"
) {

?>

<a
href="feedback.php?order_id=<?php echo $row['order_id']; ?>"
class="review-btn"
>

<i class="fas fa-star"></i>

Rate & Review

</a>

<?php

} else {

?>

<span class="not-available">

Available after delivery

</span>

<?php

}

?>


</td>


</tr>


<?php

}


} else {


?>


<tr>

<td colspan="10">

No Delivery Records Found

</td>

</tr>


<?php

}

?>


</tbody>


</table>


</div>

</div>



<!-- =====================================================
     BACK BUTTON
===================================================== -->

<div class="text-center">

<a
href="admin_dashboard.php"
class="back-btn"
>

<i class="fas fa-arrow-left"></i>

Back to Dashboard

</a>

</div>


</div>


</body>

</html>
```
