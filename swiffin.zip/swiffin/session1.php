<?php
session_start();

$_SESSION['email'] = $row['email'];
header ("location: index1.html");
exit();
?>