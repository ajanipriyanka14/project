<?php
include "config.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>View Cake | Swiffin Cake Shop</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#000;
    color:#fff;
    font-family:Arial, sans-serif;
}

.container{
    margin-top:40px;
}

h2{
    text-align:center;
    color:#E88F2A;
    font-weight:bold;
    margin-bottom:30px;
}

.table-box{
    background:#1b1b1b;
    padding:20px;
    border-radius:15px;
    box-shadow:0 0 20px rgba(232,143,42,.35);
}

.table{
    color:#fff;
    margin-bottom:0;
}

.table th{
    background:#E88F2A;
	color:#fff !important;
    color:#fff;
    text-align:center;
}

.table td{
    background:#222;
	color:#fff !important;
    vertical-align:middle;
    text-align:center;
}

img{
    width:90px;
    height:90px;
    object-fit:cover;
    border-radius:10px;
}

.btn-edit{
    background:#0d6efd;
    color:#fff;
    text-decoration:none;
    padding:6px 12px;
    border-radius:5px;
    margin-right:5px;
}

.btn-delete{
    background:#dc3545;
    color:#fff;
    text-decoration:none;
    padding:6px 12px;
    border-radius:5px;
}

.btn-edit:hover,
.btn-delete:hover{
    color:#fff;
}

.badge{
    font-size:14px;
    padding:8px 12px;
}

</style>

</head>

<body>

<div class="container">

<h2>All Cake List</h2>

<div class="table-box">

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>ID</th>
<th>Cake</th>
<th>Category</th>
<th>Price</th>
<th>Flavour</th>
<th>Weight</th>
<th>Image</th>
<th>Description</th>
<th>Stock</th>
<th>Status</th>
<th>Action</th>

</tr>

</thead>

<tbody>

<?php

$query = "SELECT * FROM cake ORDER BY id DESC";
$result = mysqli_query($conn,$query);

while($row=mysqli_fetch_assoc($result))
{
?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['cake_name']; ?></td>

<td><?php echo $row['category']; ?></td>

<td>₹<?php echo number_format($row['price'],2); ?></td>

<td><?php echo $row['flavour']; ?></td>

<td><?php echo $row['weight']; ?></td>

<td>
<img src="img/<?php echo $row['image']; ?>">
</td>

<td><?php echo $row['description']; ?></td>

<td><?php echo $row['stock']; ?></td>

<td>

<?php
if($row['status']=="Available")
{
    echo "<span class='badge bg-success'>Available</span>";
}
else
{
    echo "<span class='badge bg-danger'>Out of Stock</span>";
}
?>

</td>

<td>

<a href="edit_cake.php?id=<?php echo $row['id']; ?>" class="btn-edit">
Edit
</a>

<a href="delete_cake.php?id=<?php echo $row['id']; ?>"
class="btn-delete"
onclick="return confirm('Are you sure you want to delete this cake?');">
Delete
</a>

</td>

</tr>

<?php
}
?>

</tbody>

</table>

</div>

</div>

</body>
</html>