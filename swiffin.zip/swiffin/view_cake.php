<?php

session_start();
include "config.php";


/* =====================================================
   ADMIN CHECK
===================================================== */

if (
    !isset($_SESSION['admin_id']) &&
    !isset($_SESSION['admin_name']) &&
    !isset($_SESSION['admin'])
) {
    header("Location: admin.php");
    exit();
}


/* =====================================================
   SEARCH + CATEGORY
===================================================== */

$search = trim($_GET['search'] ?? '');

$selected_category = intval(
    $_GET['category_id'] ?? 0
);


/* =====================================================
   GET ALL ACTIVE CATEGORIES
===================================================== */

$category_list = [];

$category_sql = "
    SELECT
        id,
        category_name,
        parent_id,
        status
    FROM category
    WHERE status = 'Active'
    ORDER BY
        parent_id ASC,
        category_name ASC
";

$category_result = mysqli_query(
    $conn,
    $category_sql
);

if ($category_result) {

    while (
        $cat = mysqli_fetch_assoc(
            $category_result
        )
    ) {

        $category_list[] = $cat;
    }
}


/* =====================================================
   SELECTED CATEGORY INFORMATION
===================================================== */

$selected_cat = null;

if ($selected_category > 0) {

    $stmt = mysqli_prepare(
        $conn,
        "
        SELECT
            id,
            category_name,
            parent_id,
            status
        FROM category
        WHERE id = ?
        LIMIT 1
        "
    );

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $selected_category
    );

    mysqli_stmt_execute($stmt);

    $res = mysqli_stmt_get_result($stmt);

    $selected_cat =
        mysqli_fetch_assoc($res);

    mysqli_stmt_close($stmt);
}


/* =====================================================
   BUILD CATEGORY IDS
===================================================== */

$category_ids = [];


/* =====================================================
   MAIN CATEGORY SELECTED
   EXAMPLE:

   Oreo Cake
       |
       └── Oreo Cream Cake

   Selecting Oreo Cake:
   Show BOTH categories
===================================================== */

if (
    $selected_cat &&
    intval($selected_cat['parent_id']) == 0
) {

    /* Main category itself */

    $category_ids[] =
        intval($selected_cat['id']);


    /* Get ALL CHILD CATEGORIES */

    $child_stmt = mysqli_prepare(
        $conn,
        "
        SELECT id
        FROM category
        WHERE parent_id = ?
        AND status = 'Active'
        "
    );

    mysqli_stmt_bind_param(
        $child_stmt,
        "i",
        $selected_category
    );

    mysqli_stmt_execute(
        $child_stmt
    );

    $child_result =
        mysqli_stmt_get_result(
            $child_stmt
        );


    while (
        $child = mysqli_fetch_assoc(
            $child_result
        )
    ) {

        $category_ids[] =
            intval($child['id']);
    }


    mysqli_stmt_close(
        $child_stmt
    );
}


/* =====================================================
   CHILD CATEGORY SELECTED

   Example:

   Oreo Cream Cake

   Show ONLY Oreo Cream Cake products
===================================================== */

elseif (
    $selected_cat &&
    intval($selected_cat['parent_id']) > 0
) {

    $category_ids[] =
        intval($selected_cat['id']);
}


/* =====================================================
   REMOVE DUPLICATES
===================================================== */

$category_ids =
    array_values(
        array_unique(
            array_map(
                'intval',
                $category_ids
            )
        )
    );


/* =====================================================
   CAKE QUERY
===================================================== */

$sql = "
    SELECT

        cake.*,

        category.category_name
            AS category_display_name,

        category.parent_id
            AS category_parent_id,

        flavor.flavor_name
            AS flavor_display_name

    FROM cake

    LEFT JOIN category
        ON cake.category_id = category.id

    LEFT JOIN flavor
        ON cake.flavor_id = flavor.id

    WHERE 1 = 1
";


/* =====================================================
   CATEGORY FILTER
===================================================== */

if (
    $selected_category > 0 &&
    $selected_cat
) {

    $selected_name =
        mysqli_real_escape_string(
            $conn,
            trim(
                $selected_cat['category_name']
            )
        );


    /* =================================================
       MAIN CATEGORY
    ================================================= */

    if (
        intval(
            $selected_cat['parent_id']
        ) == 0
    ) {

        /*
           Get parent + child names
        */

        $names = [];

        $names[] =
            trim(
                $selected_cat['category_name']
            );


        $child_name_stmt =
            mysqli_prepare(
                $conn,
                "
                SELECT category_name
                FROM category
                WHERE parent_id = ?
                AND status = 'Active'
                "
            );

        mysqli_stmt_bind_param(
            $child_name_stmt,
            "i",
            $selected_category
        );

        mysqli_stmt_execute(
            $child_name_stmt
        );

        $child_name_result =
            mysqli_stmt_get_result(
                $child_name_stmt
            );


        while (
            $child_name =
            mysqli_fetch_assoc(
                $child_name_result
            )
        ) {

            $names[] =
                trim(
                    $child_name[
                        'category_name'
                    ]
                );
        }


        mysqli_stmt_close(
            $child_name_stmt
        );


        /*
           Escape category names
        */

        $safe_names = [];

        foreach (
            $names as $name
        ) {

            $safe_names[] =
                "'" .
                mysqli_real_escape_string(
                    $conn,
                    $name
                ) .
                "'";
        }


        $name_list =
            implode(
                ",",
                $safe_names
            );


        /*
           CATEGORY ID LIST
        */

        $id_condition = "0";

        if (
            count($category_ids) > 0
        ) {

            $id_condition =
                implode(
                    ",",
                    $category_ids
                );
        }


        /*
           FINAL MAIN CATEGORY FILTER

           This checks:

           1. cake.category_id
           2. cake.category text
           3. joined category name
        */

        $sql .= "
            AND
            (
                cake.category_id IN
                ($id_condition)

                OR

                LOWER(
                    TRIM(
                        cake.category
                    )
                ) IN
                (
                    SELECT
                        LOWER(
                            TRIM(
                                c.category_name
                            )
                        )
                    FROM category c
                    WHERE
                        c.id = $selected_category
                        OR
                        c.parent_id =
                            $selected_category
                )

                OR

                LOWER(
                    TRIM(
                        category.category_name
                    )
                ) IN
                (
                    $name_list
                )
            )
        ";
    }


    /* =================================================
       CHILD CATEGORY
    ================================================= */

    else {

        /*
           Only selected child
        */

        $child_id =
            intval(
                $selected_cat['id']
            );


        $child_name =
            mysqli_real_escape_string(
                $conn,
                trim(
                    $selected_cat[
                        'category_name'
                    ]
                )
            );


        $sql .= "
            AND
            (
                cake.category_id =
                    $child_id

                OR

                LOWER(
                    TRIM(
                        cake.category
                    )
                )
                =
                LOWER(
                    TRIM(
                        '$child_name'
                    )
                )

                OR

                LOWER(
                    TRIM(
                        category.category_name
                    )
                )
                =
                LOWER(
                    TRIM(
                        '$child_name'
                    )
                )
            )
        ";
    }
}


/* =====================================================
   SEARCH FILTER
===================================================== */

if ($search != '') {

    $safe_search =
        mysqli_real_escape_string(
            $conn,
            $search
        );


    $sql .= "
        AND
        (
            cake.cake_name LIKE
                '%$safe_search%'

            OR

            category.category_name LIKE
                '%$safe_search%'

            OR

            flavor.flavor_name LIKE
                '%$safe_search%'

            OR

            cake.category LIKE
                '%$safe_search%'

            OR

            cake.flavour LIKE
                '%$safe_search%'
        )
    ";
}


/* =====================================================
   ORDER
===================================================== */

$sql .= "
    ORDER BY cake.id DESC
";


/* =====================================================
   EXECUTE
===================================================== */

$result =
    mysqli_query(
        $conn,
        $sql
    );


if (!$result) {

    die(
        "Cake Database Error: " .
        mysqli_error($conn)
    );
}


/* =====================================================
   TOTAL CAKES
===================================================== */

$total_query =
    mysqli_query(
        $conn,
        "
        SELECT COUNT(*) AS total
        FROM cake
        "
    );

$total_row =
    mysqli_fetch_assoc(
        $total_query
    );

$total_cakes =
    intval(
        $total_row['total']
    );


/* =====================================================
   AVAILABLE
===================================================== */

$available_query =
    mysqli_query(
        $conn,
        "
        SELECT COUNT(*) AS total
        FROM cake
        WHERE status = 'Available'
        "
    );

$available_row =
    mysqli_fetch_assoc(
        $available_query
    );

$available_cakes =
    intval(
        $available_row['total']
    );


/* =====================================================
   OUT OF STOCK
===================================================== */

$out_query =
    mysqli_query(
        $conn,
        "
        SELECT COUNT(*) AS total
        FROM cake
        WHERE status = 'Out of Stock'
        "
    );

$out_row =
    mysqli_fetch_assoc(
        $out_query
    );

$out_cakes =
    intval(
        $out_row['total']
    );

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
Manage Cakes | SWIFFIN Admin
</title>

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
>

<link
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
    rel="stylesheet"
>


<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #000;
    color: #fff;
    font-family: Arial, sans-serif;
}


/* HEADER */

.admin-header {
    background: #111;
    border-bottom: 1px solid #333;
    padding: 17px 35px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: sticky;
    top: 0;
    z-index: 1000;
}

.logo {
    color: #E88F2A;
    font-size: 25px;
    font-weight: bold;
    letter-spacing: 2px;
}

.admin-info {
    color: #aaa;
    font-size: 14px;
}


/* MAIN */

.main-container {
    width: 94%;
    max-width: 1400px;
    margin: 35px auto;
}


/* HEADER */

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.page-title h1 {
    margin: 0;
    font-size: 32px;
    font-weight: bold;
}

.page-title h1 i {
    color: #E88F2A;
}

.page-title p {
    color: #888;
    margin: 8px 0 0;
}


/* BUTTON */

.add-btn {
    background: #E88F2A;
    color: #fff;
    text-decoration: none;
    padding: 12px 22px;
    border-radius: 25px;
    font-weight: bold;
}

.add-btn:hover {
    background: #fff;
    color: #000;
}


/* STATS */

.stats {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 18px;
    margin-bottom: 28px;
}

.stat-card {
    background: #111;
    border: 1px solid #333;
    border-radius: 15px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 16px;
}

.stat-icon {
    width: 55px;
    height: 55px;
    border-radius: 12px;
    background: #24180d;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #E88F2A;
    font-size: 25px;
}

.stat-card h3 {
    margin: 0;
    font-size: 25px;
}

.stat-card p {
    margin: 4px 0 0;
    color: #888;
}


/* FILTER */

.filter-box {
    background: #111;
    border: 1px solid #333;
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 25px;
}

.search-input,
.category-select {
    background: #1b1b1b;
    border: 1px solid #444;
    color: #fff;
    height: 46px;
}

.search-input:focus,
.category-select:focus {
    background: #1b1b1b;
    color: #fff;
    border-color: #E88F2A;
    box-shadow: none;
}

.search-input::placeholder {
    color: #777;
}

.category-select option {
    background: #1b1b1b;
    color: #fff;
}

.search-btn {
    background: #E88F2A;
    color: #fff;
    border: none;
    height: 46px;
    padding: 0 25px;
    border-radius: 8px;
    font-weight: bold;
}

.search-btn:hover {
    background: #fff;
    color: #000;
}

.clear-btn {
    height: 46px;
    padding: 0 20px;
    border: 1px solid #444;
    color: #ccc;
    background: #181818;
    text-decoration: none;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
}

.clear-btn:hover {
    border-color: #E88F2A;
    color: #E88F2A;
}


/* RESULT */

.result-text {
    color: #888;
    margin-bottom: 18px;
}

.result-text span {
    color: #E88F2A;
    font-weight: bold;
}


/* GRID */

.cake-grid {
    display: grid;
    grid-template-columns: repeat(4,1fr);
    gap: 22px;
}


/* CARD */

.cake-card {
    background: #111;
    border: 1px solid #333;
    border-radius: 18px;
    overflow: hidden;
    transition: .3s;
}

.cake-card:hover {
    transform: translateY(-6px);
    border-color: #E88F2A;
}


/* IMAGE */

.cake-image {
    height: 230px;
    background: #1b1b1b;
    position: relative;
    overflow: hidden;
}

.cake-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}


/* STATUS */

.status-badge {
    position: absolute;
    top: 12px;
    right: 12px;
    padding: 6px 11px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.available {
    background: #153d24;
    color: #4ade80;
    border: 1px solid #286b3d;
}

.out-stock {
    background: #3d1515;
    color: #ff6b6b;
    border: 1px solid #7b2929;
}


/* CONTENT */

.cake-content {
    padding: 18px;
}

.cake-category {
    color: #E88F2A;
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.cake-name {
    font-size: 19px;
    font-weight: bold;
    margin: 7px 0;
}

.cake-info {
    color: #999;
    font-size: 13px;
    margin-bottom: 12px;
}

.price {
    color: #fff;
    font-size: 21px;
    font-weight: bold;
}

.stock {
    color: #999;
    font-size: 13px;
    margin-top: 5px;
}


/* ACTION */

.action-row {
    display: flex;
    gap: 8px;
    margin-top: 15px;
}

.edit-btn,
.delete-btn {
    flex: 1;
    text-align: center;
    text-decoration: none;
    padding: 9px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: bold;
}

.edit-btn {
    background: #172b42;
    color: #5caeff;
    border: 1px solid #214a72;
}

.delete-btn {
    background: #351717;
    color: #ff6b6b;
    border: 1px solid #6d2727;
}


/* EMPTY */

.empty-box {
    background: #111;
    border: 1px solid #333;
    border-radius: 18px;
    padding: 70px 20px;
    text-align: center;
}

.empty-box i {
    font-size: 55px;
    color: #E88F2A;
}

.empty-box h3 {
    margin-top: 15px;
}

.empty-box p {
    color: #888;
    margin-bottom: 25px;
}


/* BOTTOM */

.bottom-buttons {
    display: flex;
    justify-content: center;
    gap: 12px;
    margin-top: 35px;
}

.bottom-btn {
    text-decoration: none;
    padding: 11px 22px;
    border-radius: 25px;
    border: 1px solid #444;
    color: #ccc;
    font-weight: bold;
}

.bottom-btn:hover {
    color: #E88F2A;
    border-color: #E88F2A;
}


/* MOBILE */

@media(max-width:1100px) {

    .cake-grid {
        grid-template-columns: repeat(3,1fr);
    }
}

@media(max-width:800px) {

    .cake-grid {
        grid-template-columns: repeat(2,1fr);
    }

    .stats {
        grid-template-columns: 1fr;
    }

    .page-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 18px;
    }
}

@media(max-width:550px) {

    .main-container {
        width: 94%;
        margin: 25px auto;
    }

    .cake-grid {
        grid-template-columns: 1fr;
    }

    .admin-header {
        padding: 15px 20px;
    }

    .admin-info {
        display: none;
    }
}

</style>

</head>


<body>


<header class="admin-header">

    <div class="logo">

        <i class="bi bi-cake2-fill"></i>

        SWIFFIN

    </div>

    <div class="admin-info">

        <i class="bi bi-shield-lock-fill"></i>

        Admin Panel

    </div>

</header>


<div class="main-container">


<div class="page-header">

    <div class="page-title">

        <h1>

            <i class="bi bi-grid-3x3-gap-fill"></i>

            Manage Cakes

        </h1>

        <p>
            View, search and manage all cake products
        </p>

    </div>


    <a
        href="add_cake.php"
        class="add-btn"
    >

        <i class="bi bi-plus-lg"></i>

        Add New Cake

    </a>

</div>


<!-- STATS -->

<div class="stats">

    <div class="stat-card">

        <div class="stat-icon">
            <i class="bi bi-cake2-fill"></i>
        </div>

        <div>

            <h3>
                <?php echo $total_cakes; ?>
            </h3>

            <p>Total Cakes</p>

        </div>

    </div>


    <div class="stat-card">

        <div class="stat-icon">
            <i class="bi bi-check-circle-fill"></i>
        </div>

        <div>

            <h3>
                <?php echo $available_cakes; ?>
            </h3>

            <p>Available</p>

        </div>

    </div>


    <div class="stat-card">

        <div class="stat-icon">
            <i class="bi bi-box-seam-fill"></i>
        </div>

        <div>

            <h3>
                <?php echo $out_cakes; ?>
            </h3>

            <p>Out of Stock</p>

        </div>

    </div>

</div>


<!-- FILTER -->

<div class="filter-box">

<form method="GET">

<div class="row g-2">


<div class="col-lg-5">

<input
    type="text"
    name="search"
    class="form-control search-input"
    placeholder="Search cake, category or flavour..."
    value="<?php
        echo htmlspecialchars($search);
    ?>"
>

</div>


<div class="col-lg-3">

<select
    name="category_id"
    class="form-select category-select"
>

<option value="">
    All Categories
</option>


<?php

foreach (
    $category_list as $cat
) {

    $cat_id =
        intval($cat['id']);

    $cat_parent =
        intval($cat['parent_id']);

?>

<option
    value="<?php echo $cat_id; ?>"
    <?php

    if (
        $selected_category ==
        $cat_id
    ) {

        echo "selected";
    }

    ?>
>

<?php

if ($cat_parent > 0) {

    echo "↳ ";
}

echo htmlspecialchars(
    $cat['category_name']
);

?>

</option>

<?php

}

?>

</select>

</div>


<div class="col-lg-2">

<button
    type="submit"
    class="search-btn w-100"
>

    <i class="bi bi-search"></i>

    Search

</button>

</div>


<div class="col-lg-2">

<a
    href="view_cake.php"
    class="clear-btn"
>

    <i class="bi bi-arrow-clockwise"></i>

    &nbsp; Reset

</a>

</div>


</div>

</form>

</div>


<!-- RESULT -->

<div class="result-text">

Showing

<span>
<?php
echo mysqli_num_rows($result);
?>
</span>

cake products

<?php

if (
    $selected_cat
) {

    echo " in ";

    echo htmlspecialchars(
        $selected_cat[
            'category_name'
        ]
    );

}

?>

</div>


<!-- CAKES -->

<?php

if (
    mysqli_num_rows($result) > 0
) {

?>

<div class="cake-grid">


<?php

while (
    $row =
    mysqli_fetch_assoc($result)
) {


/* IMAGE */

$image_name =
    trim(
        $row['image'] ?? ''
    );


$image_path =
    "img/" .
    $image_name;


if (
    $image_name != '' &&
    !file_exists($image_path)
) {

    $image_path =
        "img/cakes/" .
        $image_name;
}


if (
    $image_name == '' ||
    !file_exists($image_path)
) {

    $image_path =
        "img/default-cake.jpg";
}


/* CATEGORY */

$display_category =
    trim(
        $row[
            'category_display_name'
        ] ?? ''
    );


if (
    $display_category == ''
) {

    $display_category =
        trim(
            $row[
                'category'
            ] ?? ''
        );
}


if (
    $display_category == ''
) {

    $display_category =
        "N/A";
}


/* FLAVOR */

$display_flavor =
    trim(
        $row[
            'flavor_display_name'
        ] ?? ''
    );


if (
    $display_flavor == ''
) {

    $display_flavor =
        trim(
            $row[
                'flavour'
            ] ?? ''
        );
}


if (
    $display_flavor == ''
) {

    $display_flavor =
        "N/A";
}


/* STOCK */

$stock =
    intval(
        $row['stock'] ?? 0
    );


/* STATUS */

$status =
    trim(
        $row['status'] ?? ''
    );


$is_available =
    (
        strtolower($status)
        == 'available'
        &&
        $stock > 0
    );

?>


<div class="cake-card">


<div class="cake-image">

<img
    src="<?php
        echo htmlspecialchars(
            $image_path
        );
    ?>"
    alt="<?php
        echo htmlspecialchars(
            $row['cake_name']
        );
    ?>"
    onerror="
        this.src='img/default-cake.jpg';
    "
>


<?php

if ($is_available) {

?>

<span class="status-badge available">

    <i class="bi bi-check-circle-fill"></i>

    Available

</span>

<?php

} else {

?>

<span class="status-badge out-stock">

    <i class="bi bi-x-circle-fill"></i>

    Out of Stock

</span>

<?php

}

?>

</div>


<div class="cake-content">


<div class="cake-category">

<?php

echo htmlspecialchars(
    $display_category
);

?>

</div>


<div class="cake-name">

<?php

echo htmlspecialchars(
    $row['cake_name']
);

?>

</div>


<div class="cake-info">

<i class="bi bi-stars"></i>

<?php

echo htmlspecialchars(
    $display_flavor
);

?>

&nbsp; • &nbsp;

<?php

echo htmlspecialchars(
    $row['weight'] ?? 'N/A'
);

?>

</div>


<div class="price">

₹<?php

echo number_format(
    floatval(
        $row['price']
    ),
    2
);

?>

</div>


<div class="stock">

<i class="bi bi-box-seam"></i>

Stock:

<?php

echo $stock;

?>

</div>


<div class="action-row">


<a
    href="edit_cake.php?id=<?php
        echo intval(
            $row['id']
        );
    ?>"
    class="edit-btn"
>

<i class="bi bi-pencil-fill"></i>

Edit

</a>


<a
    href="delete_cake.php?id=<?php
        echo intval(
            $row['id']
        );
    ?>"
    class="delete-btn"
    onclick="
        return confirm(
            'Are you sure you want to delete this cake?'
        );
    "
>

<i class="bi bi-trash-fill"></i>

Delete

</a>


</div>


</div>

</div>


<?php

}

?>

</div>


<?php

} else {

?>

<div class="empty-box">

<i class="bi bi-cake2"></i>

<h3>
No Cakes Found
</h3>

<p>
There are no cakes available in this category.
</p>

<a
    href="add_cake.php"
    class="add-btn"
>

<i class="bi bi-plus-lg"></i>

Add Cake

</a>

</div>

<?php

}

?>


<div class="bottom-buttons">


<a
    href="admin_dashboard.php"
    class="bottom-btn"
>

<i class="bi bi-arrow-left"></i>

Dashboard

</a>


<a
    href="add_cake.php"
    class="bottom-btn"
>

<i class="bi bi-plus-circle"></i>

Add New Cake

</a>


</div>


</div>


</body>

</html>


<?php

mysqli_close($conn);

?>