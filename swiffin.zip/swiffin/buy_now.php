<?php

session_start();

include "config.php";


/* ================================
   CHECK BUY NOW
================================ */

if (!isset($_POST['buy_now'])) {

    header("Location: product.php");
    exit();

}


/* ================================
   GET DATA
================================ */

$cake_id = isset($_POST['cake_id'])
    ? intval($_POST['cake_id'])
    : 0;

$quantity = isset($_POST['quantity'])
    ? intval($_POST['quantity'])
    : 1;


/* ================================
   VALIDATE
================================ */

if ($cake_id <= 0) {

    die("Invalid Cake ID");

}

if ($quantity <= 0) {

    $quantity = 1;

}


/* ================================
   GET CAKE
================================ */

$query = mysqli_query(
    $conn,
    "SELECT * FROM cake
     WHERE id='$cake_id'
     LIMIT 1"
);


if (!$query) {

    die(
        "Database Error: " .
        mysqli_error($conn)
    );

}


if (mysqli_num_rows($query) == 0) {

    die("Cake Not Found");

}


$cake = mysqli_fetch_assoc($query);


/* ================================
   STOCK CHECK
================================ */

if (
    intval($cake['stock']) <= 0 ||
    $cake['status'] != "Available"
) {

    die("This Cake is Out of Stock");

}


/* ================================
   CUSTOMER CHECK
================================ */

if (!isset($_SESSION['customer_id'])) {

    header("Location: login.php");
    exit();

}


/* ================================
   CUSTOMER DETAILS
================================ */

$customer_id = intval(
    $_SESSION['customer_id']
);


/* ================================
   CUSTOMER NAME & EMAIL
================================ */

$customer_name =
    isset($_SESSION['name'])
    ? $_SESSION['name']
    : "";

$email =
    isset($_SESSION['email'])
    ? $_SESSION['email']
    : "";


/* ================================
   PRICE
================================ */

$price = floatval($cake['price']);

$total = $price * $quantity;


/* ================================
   INSERT INTO CART
================================ */

$customer_name =
    mysqli_real_escape_string(
        $conn,
        $customer_name
    );

$email =
    mysqli_real_escape_string(
        $conn,
        $email
    );

$cake_name =
    mysqli_real_escape_string(
        $conn,
        $cake['cake_name']
    );


$insert = mysqli_query(
    $conn,

    "INSERT INTO carts
    (
        customer_name,
        email,
        cake_name,
        quantity,
        price,
        total,
        cart_date
    )
    VALUES
    (
        '$customer_name',
        '$email',
        '$cake_name',
        '$quantity',
        '$price',
        '$total',
        NOW()
    )"
);


if (!$insert) {

    die(
        "Cart Insert Error: " .
        mysqli_error($conn)
    );

}


/* ================================
   GET NEW CART ID
================================ */

$cart_id = mysqli_insert_id($conn);


/* ================================
   GO TO CHECKOUT
================================ */

header(
    "Location: checkout.php?cart_id=" .
    $cart_id
);

exit();

?>