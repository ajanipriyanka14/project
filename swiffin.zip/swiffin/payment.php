<?php
session_start();
include "config.php";

$order_id = "";
$customer_name = "";
$amount = "";

if(isset($_GET['id']))
{
    $id = $_GET['id'];

    $query = mysqli_query($conn,"SELECT * FROM carts WHERE id='$id'");

    if(mysqli_num_rows($query)>0)
    {
        $row = mysqli_fetch_assoc($query);

        $order_id = $row['id'];
        $customer_name = $row['customer_name'];
        $amount = $row['total'];
    }
    else
    {
        die("Order Not Found");
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Payment | Swiffin Cake Shop</title>

<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<style>

body{
    background:#000;
    color:#fff;
    font-family:Arial;
}

.payment-box{
    max-width:650px;
    margin:60px auto;
    background:#1b1b1b;
    padding:35px;
    border-radius:20px;
    box-shadow:0 0 20px rgba(232,143,42,.4);
}

h2{
    color:#E88F2A;
    text-align:center;
    margin-bottom:30px;
}

.form-control,
.form-select{
    background:#2b2b2b;
    color:#fff;
    border:1px solid #555;
}

.form-control:focus,
.form-select:focus{
    background:#2b2b2b;
    color:#fff;
    border-color:#E88F2A;
    box-shadow:none;
}

.btn-payment{
    background:#E88F2A;
    color:#fff;
    width:100%;
    font-weight:bold;
}

.btn-payment:hover{
    background:#d87d16;
    color:#fff;
}

</style>

</head>

<body>

<div class="container">

<div class="payment-box">

<h2>
<i class="fas fa-credit-card"></i>
Payment
</h2>

<form method="post" id="paymentForm">

<div class="mb-3">

<label>Order ID</label>

<input
type="text"
class="form-control"
name="order_id"
value="<?php echo $order_id; ?>"
readonly>

</div>

<div class="mb-3">

<label>Customer Name</label>

<input
type="text"
class="form-control"
name="customer_name"
value="<?php echo $customer_name; ?>"
readonly>

</div>

<div class="mb-3">

<label>Payment Method</label>

<select
class="form-select"
name="payment_method"
required>

<option value="">
Select Payment
</option>

<option value="COD">
Cash On Delivery
</option>

<option value="UPI">
UPI
</option>

<option value="Card">
Debit / Credit Card
</option>

<option value="Net Banking">
Net Banking
</option>

</select>

</div>

<div class="mb-3">

<label>Total Amount</label>

<input
type="text"
class="form-control"
name="amount"
value="<?php echo $amount; ?>"
readonly>

</div>
<div class="mb-3">

<label>Payment Status</label>

<input
type="text"
class="form-control"
name="payment_status"
value="Paid"
readonly>

</div>

<div class="mb-3">

<label>Payment Date</label>

<input
type="date"
class="form-control"
name="payment_date"
value="<?php echo date('Y-m-d'); ?>"
readonly>

</div>

<button
type="submit"
name="submit"
class="btn btn-payment">

<i class="fas fa-check-circle"></i>
Pay Now

</button>

</form>

<?php

if(isset($_POST['submit']))
{

    $order_id = $_POST['order_id'];
    $customer_name = $_POST['customer_name'];
    $payment_method = $_POST['payment_method'];
    $amount = $_POST['amount'];
    $payment_status = "Paid";
    $payment_date = date("Y-m-d");

    $insert = mysqli_query($conn,"
    INSERT INTO payment
    (
        order_id,
        customer_name,
        payment_method,
        amount,
        payment_status,
        payment_date
    )
    VALUES
    (
        '$order_id',
        '$customer_name',
        '$payment_method',
        '$amount',
        '$payment_status',
        '$payment_date'
    )
    ");

    if($insert)
    {
        echo "<script>
        alert('Payment Successful');
        window.location='product.php';
        </script>";
    }
    else
    {
        echo "<div class='alert alert-danger mt-3'>
        ".mysqli_error($conn)."
        </div>";
    }

}

?>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>