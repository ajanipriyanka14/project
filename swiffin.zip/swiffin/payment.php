<?php

session_start();
include "config.php";

/* =====================================================
   VARIABLES
===================================================== */

$success = false;
$order_id = "";
$error = "";


/* =====================================================
   CHECK CART ID
===================================================== */

if (!isset($_GET['cart_id']) && !isset($_POST['cart_id'])) {
    die("Cart ID Not Found");
}

if (isset($_POST['cart_id'])) {
    $cart_id = intval($_POST['cart_id']);
} else {
    $cart_id = intval($_GET['cart_id']);
}

if ($cart_id <= 0) {
    die("Invalid Cart ID");
}


/* =====================================================
   GET CART DATA
===================================================== */

$query = mysqli_query(
    $conn,
    "SELECT * FROM carts WHERE id='$cart_id' LIMIT 1"
);

if (!$query) {
    die("Database Error: " . mysqli_error($conn));
}

if (mysqli_num_rows($query) == 0) {
    die("Cart Record Not Found");
}

$cart = mysqli_fetch_assoc($query);


/* =====================================================
   CART DETAILS
===================================================== */

$customer_name = isset($cart['customer_name'])
    ? $cart['customer_name']
    : "";

$email = isset($cart['email'])
    ? $cart['email']
    : "";

$mobile = isset($cart['mobile'])
    ? $cart['mobile']
    : "";

$address = isset($cart['address'])
    ? $cart['address']
    : "";

$cake_name = isset($cart['cake_name'])
    ? $cart['cake_name']
    : "";

$quantity = intval($cart['quantity']);

$amount = floatval($cart['total']);


/* =====================================================
   PLACE ORDER
===================================================== */

if (isset($_POST['place_order'])) {

    $payment_method = isset($_POST['payment_method'])
        ? trim($_POST['payment_method'])
        : "";


    /* =================================================
       CHECK PAYMENT METHOD
    ================================================= */

    if ($payment_method == "") {

        $error = "Please select a payment method.";

    } else {


        /* =============================================
           ESCAPE DATA
        ============================================= */

        $customer_name_safe = mysqli_real_escape_string(
            $conn,
            $customer_name
        );

        $cake_name_safe = mysqli_real_escape_string(
            $conn,
            $cake_name
        );

        $mobile_safe = mysqli_real_escape_string(
            $conn,
            $mobile
        );

        $address_safe = mysqli_real_escape_string(
            $conn,
            $address
        );

        $payment_method_safe = mysqli_real_escape_string(
            $conn,
            $payment_method
        );


        /* =============================================
           ORDER STATUS
        ============================================= */

        $status = "Pending";

        $order_date = date("Y-m-d H:i:s");


        /* =============================================
           INSERT ORDER
        ============================================= */

        $insert_order = mysqli_query(
            $conn,

            "INSERT INTO orders
            (
                customer_name,
                cake_name,
                quantity,
                amount,
                status,
                order_date
            )

            VALUES
            (
                '$customer_name_safe',
                '$cake_name_safe',
                '$quantity',
                '$amount',
                '$status',
                '$order_date'
            )"
        );


        /* =============================================
           CHECK ORDER
        ============================================= */

        if (!$insert_order) {

            $error =
                "Order Insert Error: " .
                mysqli_error($conn);

        } else {


            /* =========================================
               GET ORDER ID
            ========================================= */

            $order_id = mysqli_insert_id($conn);


            if ($order_id <= 0) {

                $error = "Order ID Not Generated.";

            } else {


                /* =====================================
                   INSERT DELIVERY RECORD
                ===================================== */

                $delivery_person = "";

                $delivery_status = "Pending";

                $delivery_date = date("Y-m-d H:i:s");


                $delivery_person_safe =
                    mysqli_real_escape_string(
                        $conn,
                        $delivery_person
                    );

                $delivery_status_safe =
                    mysqli_real_escape_string(
                        $conn,
                        $delivery_status
                    );


                $insert_delivery = mysqli_query(
                    $conn,

                    "INSERT INTO delivery
                    (
                        order_id,
                        customer_name,
                        mobile,
                        address,
                        delivery_person,
                        delivery_status,
                        delivery_date
                    )

                    VALUES
                    (
                        '$order_id',
                        '$customer_name_safe',
                        '$mobile_safe',
                        '$address_safe',
                        '$delivery_person_safe',
                        '$delivery_status_safe',
                        '$delivery_date'
                    )"
                );


                /* =====================================
                   CHECK DELIVERY
                ===================================== */

                if (!$insert_delivery) {

                    $error =
                        "Delivery Record Error: " .
                        mysqli_error($conn);

                } else {


                    /* =================================
                       DELETE CART
                    ================================= */

                    $delete_cart = mysqli_query(
                        $conn,

                        "DELETE FROM carts
                         WHERE id='$cart_id'"
                    );


                    if (!$delete_cart) {

                        $error =
                            "Cart Delete Error: " .
                            mysqli_error($conn);

                    } else {

                        /* =============================
                           SUCCESS
                        ============================= */

                        $success = true;

                    }

                }

            }

        }

    }

}

?>


<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
Payment | Swiffin Cake Shop
</title>


<!-- Bootstrap -->

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<!-- Font Awesome -->

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
rel="stylesheet"
>


<style>

/* =====================================================
   BODY
===================================================== */

*{
    box-sizing:border-box;
}

body{

    margin:0;

    padding:0;

    background:#000;

    color:#fff;

    font-family:Arial, Helvetica, sans-serif;

}


/* =====================================================
   MAIN CONTAINER
===================================================== */

.payment-container{

    width:92%;

    max-width:700px;

    margin:50px auto;

}


/* =====================================================
   PAYMENT BOX
===================================================== */

.payment-box{

    background:#111;

    border:2px solid #E88F2A;

    border-radius:25px;

    padding:35px;

    box-shadow:
    0 0 25px rgba(232,143,42,.35),
    0 0 60px rgba(232,143,42,.10);

}


/* =====================================================
   TITLE
===================================================== */

.title{

    text-align:center;

    color:#E88F2A;

    font-size:32px;

    font-weight:bold;

    margin-bottom:10px;

}


.subtitle{

    text-align:center;

    color:#aaa;

    margin-bottom:30px;

}


/* =====================================================
   SUMMARY
===================================================== */

.summary{

    background:#1b1b1b;

    border:1px solid #333;

    border-radius:15px;

    padding:20px;

    margin-bottom:25px;

}


.summary-row{

    display:flex;

    justify-content:space-between;

    align-items:center;

    gap:20px;

    padding:11px 0;

    border-bottom:1px solid #333;

}


.summary-row:last-child{

    border-bottom:none;

}


.summary-row span:first-child{

    color:#aaa;

}


.summary-row span:last-child{

    color:#fff;

    font-weight:bold;

    text-align:right;

}


.total{

    color:#E88F2A !important;

    font-size:22px;

}


/* =====================================================
   PAYMENT TITLE
===================================================== */

.payment-title{

    color:#E88F2A;

    font-size:21px;

    font-weight:bold;

    margin-bottom:15px;

}


/* =====================================================
   PAYMENT OPTION
===================================================== */

.payment-option{

    background:#1b1b1b;

    border:1px solid #444;

    border-radius:12px;

    padding:15px;

    margin-bottom:12px;

    cursor:pointer;

}


.payment-option:hover{

    border-color:#E88F2A;

}


.payment-option input{

    margin-right:10px;

}


.payment-option label{

    cursor:pointer;

    font-weight:bold;

}


/* =====================================================
   PLACE ORDER BUTTON
===================================================== */

.place-btn{

    width:100%;

    border:none;

    background:#E88F2A;

    color:#fff;

    padding:15px;

    border-radius:30px;

    font-size:18px;

    font-weight:bold;

    margin-top:20px;

}


.place-btn:hover{

    background:#d67d18;

}


/* =====================================================
   ERROR
===================================================== */

.error{

    background:#3a1111;

    border:1px solid #dc3545;

    color:#ff6b6b;

    padding:12px;

    border-radius:10px;

    text-align:center;

    margin-bottom:20px;

}


/* =====================================================
   SUCCESS BOX
===================================================== */

.success-box{

    text-align:center;

    padding:20px;

}


/* =====================================================
   SUCCESS ICON
===================================================== */

.success-icon{

    width:100px;

    height:100px;

    border-radius:50%;

    background:#198754;

    color:#fff;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:55px;

    margin:0 auto 25px;

    box-shadow:
    0 0 25px rgba(25,135,84,.5);

}


/* =====================================================
   SUCCESS TITLE
===================================================== */

.success-title{

    color:#28a745;

    font-size:32px;

    font-weight:bold;

    margin-bottom:10px;

}


.success-message{

    color:#bbb;

    font-size:17px;

    margin-bottom:25px;

}


/* =====================================================
   ORDER ID
===================================================== */

.order-id-box{

    background:#1b1b1b;

    border:1px solid #E88F2A;

    border-radius:15px;

    padding:18px;

    margin-bottom:20px;

}


.order-id-box small{

    display:block;

    color:#aaa;

    margin-bottom:5px;

}


.order-id-box strong{

    color:#E88F2A;

    font-size:28px;

}


/* =====================================================
   HOME BUTTON
===================================================== */

.home-btn{

    display:block;

    width:100%;

    background:#E88F2A;

    color:#fff;

    text-decoration:none;

    padding:14px;

    border-radius:30px;

    font-weight:bold;

    font-size:17px;

    margin-top:20px;

}


.home-btn:hover{

    background:#d67d18;

    color:#fff;

}


/* =====================================================
   MOBILE
===================================================== */

@media(max-width:600px){

    .payment-box{

        padding:22px;

    }

    .title{

        font-size:27px;

    }

    .summary-row{

        flex-direction:column;

        align-items:flex-start;

        gap:5px;

    }

    .summary-row span:last-child{

        text-align:left;

    }

}

</style>

</head>


<body>


<div class="payment-container">

<div class="payment-box">


<?php if ($success) { ?>


<!-- =================================================
     ORDER SUCCESS
================================================= -->

<div class="success-box">


<!-- GREEN CHECK -->

<div class="success-icon">

<i class="fas fa-check"></i>

</div>


<!-- SUCCESS TITLE -->

<div class="success-title">

Order Successful!

</div>


<!-- SUCCESS MESSAGE -->

<div class="success-message">

Your order has been placed successfully.

<br>

Thank you for ordering from

<strong>
SWIFFIN CAKE SHOP
</strong>

</div>


<!-- ORDER ID -->

<div class="order-id-box">

<small>
Your Order ID
</small>

<strong>

#<?php echo $order_id; ?>

</strong>

</div>


<!-- ORDER DETAILS -->

<div class="summary">


<div class="summary-row">

<span>
Customer Name
</span>

<span>

<?php
echo htmlspecialchars($customer_name);
?>

</span>

</div>


<div class="summary-row">

<span>
Cake Name
</span>

<span>

<?php
echo htmlspecialchars($cake_name);
?>

</span>

</div>


<div class="summary-row">

<span>
Quantity
</span>

<span>

<?php
echo $quantity;
?>

</span>

</div>


<div class="summary-row">

<span>
Payment Method
</span>

<span>

<?php
echo htmlspecialchars($payment_method);
?>

</span>

</div>


<div class="summary-row">

<span>
Total Amount
</span>

<span class="total">

₹<?php
echo number_format($amount,2);
?>

</span>

</div>


<div class="summary-row">

<span>
Order Status
</span>

<span class="text-warning">

Pending

</span>

</div>


</div>


<!-- HOME -->

<a
href="index1.php"
class="home-btn"
>

<i class="fas fa-home"></i>

&nbsp; Back To Home

</a>


</div>


<?php } else { ?>


<!-- =================================================
     PAYMENT PAGE
================================================= -->

<div class="title">

<i class="fas fa-credit-card"></i>

Payment

</div>


<div class="subtitle">

Select your preferred payment method

</div>


<?php if ($error != "") { ?>

<div class="error">

<i class="fas fa-circle-exclamation"></i>

<?php
echo htmlspecialchars($error);
?>

</div>

<?php } ?>


<!-- =================================================
     ORDER SUMMARY
================================================= -->

<div class="summary">


<div class="summary-row">

<span>
Customer Name
</span>

<span>

<?php
echo htmlspecialchars($customer_name);
?>

</span>

</div>


<div class="summary-row">

<span>
Mobile
</span>

<span>

<?php
echo htmlspecialchars($mobile);
?>

</span>

</div>


<div class="summary-row">

<span>
Address
</span>

<span>

<?php
echo htmlspecialchars($address);
?>

</span>

</div>


<div class="summary-row">

<span>
Cake
</span>

<span>

<?php
echo htmlspecialchars($cake_name);
?>

</span>

</div>


<div class="summary-row">

<span>
Quantity
</span>

<span>

<?php
echo $quantity;
?>

</span>

</div>


<div class="summary-row">

<span>
Total Amount
</span>

<span class="total">

₹<?php
echo number_format($amount,2);
?>

</span>

</div>


</div>


<!-- =================================================
     PAYMENT FORM
================================================= -->

<form method="POST">


<input
type="hidden"
name="cart_id"
value="<?php echo $cart_id; ?>"
>


<div class="payment-title">

<i class="fas fa-wallet"></i>

Payment Method

</div>


<!-- COD -->

<div class="payment-option">

<input
type="radio"
name="payment_method"
value="Cash on Delivery"
id="cod"
required
>

<label for="cod">

<i class="fas fa-money-bill-wave"></i>

&nbsp; Cash on Delivery

</label>

</div>


<!-- UPI -->

<div class="payment-option">

<input
type="radio"
name="payment_method"
value="UPI Payment"
id="upi"
>

<label for="upi">

<i class="fas fa-mobile-screen-button"></i>

&nbsp; UPI Payment

</label>

</div>


<!-- CARD -->

<div class="payment-option">

<input
type="radio"
name="payment_method"
value="Credit / Debit Card"
id="card"
>

<label for="card">

<i class="fas fa-credit-card"></i>

&nbsp; Credit / Debit Card

</label>

</div>


<!-- PHONEPE -->

<div class="payment-option">

<input
type="radio"
name="payment_method"
value="PhonePe"
id="phonepe"
>

<label for="phonepe">

<i class="fas fa-mobile-screen"></i>

&nbsp; PhonePe

</label>

</div>


<!-- GOOGLE PAY -->

<div class="payment-option">

<input
type="radio"
name="payment_method"
value="Google Pay"
id="googlepay"
>

<label for="googlepay">

<i class="fab fa-google-pay"></i>

&nbsp; Google Pay

</label>

</div>


<!-- PLACE ORDER -->

<button
type="submit"
name="place_order"
class="place-btn"
>

<i class="fas fa-check-circle"></i>

&nbsp; Place Order

</button>


</form>


<?php } ?>


</div>

</div>


</body>

</html>