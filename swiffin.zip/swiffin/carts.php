<?php

session_start();
include "config.php";


/* =====================================================
   CHECK LOGIN
===================================================== */

if (!isset($_SESSION['email']) || empty($_SESSION['email'])) {

    echo "<script>
        alert('Please Login First');
        window.location='login.php';
    </script>";

    exit();
}

$logged_email = trim($_SESSION['email']);


/* =====================================================
   CHECK CART ID
===================================================== */

if (!isset($_GET['id'])) {
    die("Cart ID Not Found");
}

$cart_id = intval($_GET['id']);

if ($cart_id <= 0) {
    die("Invalid Cart ID");
}


/* =====================================================
   GET CART
   ONLY LOGGED-IN USER'S CART
===================================================== */

$logged_email_safe = mysqli_real_escape_string(
    $conn,
    $logged_email
);

$query = mysqli_query(
    $conn,
    "SELECT * FROM carts
     WHERE id='$cart_id'
     AND email='$logged_email_safe'
     LIMIT 1"
);

if (!$query) {
    die("Database Error: " . mysqli_error($conn));
}

if (mysqli_num_rows($query) == 0) {

    echo "<script>
        alert('Cart not found or this cart does not belong to your account.');
        window.location='product.php';
    </script>";

    exit();
}

$cart = mysqli_fetch_assoc($query);


/* =====================================================
   CART DATA
===================================================== */

$cake_name = $cart['cake_name'];
$quantity  = intval($cart['quantity']);
$price     = floatval($cart['price']);
$total     = floatval($cart['total']);

$customer_name = $cart['customer_name'] ?? "";
$email         = $cart['email'] ?? "";
$mobile        = $cart['mobile'] ?? "";
$address       = $cart['address'] ?? "";


/* =====================================================
   GET CAKE DETAILS
===================================================== */

$cake_name_safe = mysqli_real_escape_string(
    $conn,
    $cake_name
);

$cake_query = mysqli_query(
    $conn,
    "SELECT * FROM cake
     WHERE cake_name='$cake_name_safe'
     LIMIT 1"
);

$image    = "";
$category = "";
$flavour  = "";
$weight   = "";
$status   = "";

if ($cake_query && mysqli_num_rows($cake_query) > 0) {

    $cake = mysqli_fetch_assoc($cake_query);

    $image    = $cake['image'] ?? "";
    $category = $cake['category'] ?? "";
    $flavour  = $cake['flavour'] ?? "";
    $weight   = $cake['weight'] ?? "";
    $status   = $cake['status'] ?? "";
}


/* =====================================================
   SAVE CUSTOMER DETAILS
===================================================== */

if (isset($_POST['save_details'])) {

    $customer_name = trim($_POST['customer_name'] ?? "");
    $email         = trim($_POST['email'] ?? "");
    $mobile        = trim($_POST['mobile'] ?? "");
    $address       = trim($_POST['address'] ?? "");


    /* =================================================
       VALIDATION
    ================================================= */

    if (
        empty($customer_name) ||
        empty($email) ||
        empty($mobile) ||
        empty($address)
    ) {

        echo "<script>
            alert('Please fill all customer details');
            window.history.back();
        </script>";

        exit();
    }


    /* =================================================
       EMAIL VALIDATION
    ================================================= */

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        echo "<script>
            alert('Please enter a valid email');
            window.history.back();
        </script>";

        exit();
    }


    /* =================================================
       MOBILE VALIDATION
    ================================================= */

    if (!preg_match('/^[0-9]{10}$/', $mobile)) {

        echo "<script>
            alert('Please enter valid 10 digit mobile number');
            window.history.back();
        </script>";

        exit();
    }


    /* =================================================
       ESCAPE DATA
    ================================================= */

    $customer_name_safe = mysqli_real_escape_string(
        $conn,
        $customer_name
    );

    $email_safe = mysqli_real_escape_string(
        $conn,
        $email
    );

    $mobile_safe = mysqli_real_escape_string(
        $conn,
        $mobile
    );

    $address_safe = mysqli_real_escape_string(
        $conn,
        $address
    );


    /* =================================================
       UPDATE CART
       ALSO CHECK OWNER EMAIL
    ================================================= */

    $update = mysqli_query(
        $conn,
        "UPDATE carts SET
            customer_name='$customer_name_safe',
            email='$email_safe',
            mobile='$mobile_safe',
            address='$address_safe'
         WHERE id='$cart_id'
         AND email='$logged_email_safe'"
    );


    if (!$update) {

        die(
            "Customer Details Error: " .
            mysqli_error($conn)
        );
    }


    /* =================================================
       GO TO CHECKOUT
    ================================================= */

    header(
        "Location: checkout.php?cart_id=" . $cart_id
    );

    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Your Cart | Swiffin Cake Shop</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
rel="stylesheet">


<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    background:#000;
    color:#fff;
    font-family:Arial,sans-serif;
}


/* HEADER */

.cart-header{
    text-align:center;
    padding:40px 15px 20px;
}

.cart-header h1{
    color:#E88F2A;
    font-size:38px;
    font-weight:bold;
}

.cart-header p{
    color:#aaa;
}


/* MAIN */

.cart-container{
    width:92%;
    max-width:1150px;
    margin:auto;
    margin-bottom:60px;
}


/* BOX */

.cart-box{
    background:#111;
    border:1px solid #E88F2A;
    border-radius:22px;
    padding:30px;

    box-shadow:
    0 0 25px rgba(232,143,42,.25);
}


/* IMAGE */

.cake-image{
    width:100%;
    height:370px;
    object-fit:cover;
    border-radius:18px;
    border:2px solid #E88F2A;
}


/* CAKE NAME */

.cake-name{
    color:#E88F2A;
    font-size:30px;
    font-weight:bold;
    margin:20px 0;
}


/* DETAILS */

.detail{
    background:#1b1b1b;
    border:1px solid #333;
    border-radius:10px;
    padding:13px 16px;
    margin-bottom:10px;
}

.detail span{
    display:block;
    color:#999;
    font-size:13px;
    margin-bottom:4px;
}

.detail strong{
    color:#fff;
    font-size:16px;
}

.price{
    color:#E88F2A !important;
    font-size:23px !important;
}


/* FORM TITLE */

.form-title{
    color:#E88F2A;
    font-size:23px;
    font-weight:bold;
    margin-bottom:20px;
}


/* INPUT */

.form-label{
    color:#E88F2A;
    font-weight:bold;
}

.form-control{
    background:#080808;
    color:#fff;
    border:1px solid #444;
    padding:13px;
    border-radius:9px;
}

.form-control:focus{
    background:#080808;
    color:#fff;
    border-color:#E88F2A;
    box-shadow:0 0 8px rgba(232,143,42,.3);
}

.form-control::placeholder{
    color:#777;
}


/* CHECKOUT BUTTON */

.checkout-btn{
    width:100%;
    border:none;
    background:#E88F2A;
    color:#fff;
    padding:15px;
    border-radius:30px;
    font-size:18px;
    font-weight:bold;
    margin-top:10px;
}

.checkout-btn:hover{
    background:#d67d18;
}


/* BACK */

.back-link{
    display:block;
    text-align:center;
    color:#E88F2A;
    text-decoration:none;
    font-weight:bold;
    margin-top:20px;
}

.back-link:hover{
    color:#fff;
}


/* MOBILE */

@media(max-width:768px){

    .cart-box{
        padding:20px;
    }

    .cake-image{
        height:280px;
    }

    .cart-header h1{
        font-size:30px;
    }

}

</style>

</head>


<body>


<!-- =================================================
     HEADER
================================================= -->

<div class="cart-header">

<h1>

<i class="fas fa-shopping-cart"></i>

Your Cart

</h1>

<p>
Review your cake and enter delivery details
</p>

</div>


<!-- =================================================
     MAIN
================================================= -->

<div class="cart-container">

<div class="cart-box">

<div class="row g-4">


<!-- =================================================
     CAKE
================================================= -->

<div class="col-lg-5">


<?php if (!empty($image)) { ?>

<img
src="img/<?php echo htmlspecialchars($image); ?>"
class="cake-image"
alt="Cake">

<?php } else { ?>

<div
style="
height:370px;
border:2px solid #E88F2A;
border-radius:18px;
display:flex;
align-items:center;
justify-content:center;
color:#888;
">

<i class="fas fa-cake-candles fa-4x"></i>

</div>

<?php } ?>


<h2 class="cake-name">

<?php echo htmlspecialchars($cake_name); ?>

</h2>


<div class="detail">

<span>Category</span>

<strong>
<?php echo htmlspecialchars($category); ?>
</strong>

</div>


<div class="detail">

<span>Flavour</span>

<strong>
<?php echo htmlspecialchars($flavour); ?>
</strong>

</div>


<div class="detail">

<span>Weight</span>

<strong>
<?php echo htmlspecialchars($weight); ?>
</strong>

</div>


<div class="detail">

<span>Quantity</span>

<strong>
<?php echo htmlspecialchars($quantity); ?>
</strong>

</div>


<div class="detail">

<span>Price</span>

<strong class="price">

₹<?php echo number_format($price,2); ?>

</strong>

</div>


<div class="detail">

<span>Total Amount</span>

<strong class="price">

₹<?php echo number_format($total,2); ?>

</strong>

</div>


</div>


<!-- =================================================
     CUSTOMER DETAILS
================================================= -->

<div class="col-lg-7">


<div class="form-title">

<i class="fas fa-user"></i>

Customer Details

</div>


<form method="POST">


<!-- NAME -->

<div class="mb-3">

<label class="form-label">

Customer Name

</label>

<input
type="text"
name="customer_name"
class="form-control"
placeholder="Enter Your Name"
value="<?php echo htmlspecialchars($customer_name); ?>"
required>

</div>


<!-- EMAIL -->

<div class="mb-3">

<label class="form-label">

Email

</label>

<input
type="email"
name="email"
class="form-control"
placeholder="Enter Your Email"
value="<?php echo htmlspecialchars($email); ?>"
required>

</div>


<!-- MOBILE -->

<div class="mb-3">

<label class="form-label">

Mobile Number

</label>

<input
type="text"
name="mobile"
class="form-control"
placeholder="Enter 10 Digit Mobile Number"
value="<?php echo htmlspecialchars($mobile); ?>"
maxlength="10"
pattern="[0-9]{10}"
required>

</div>


<!-- ADDRESS -->

<div class="mb-3">

<label class="form-label">

Delivery Address

</label>

<textarea
name="address"
class="form-control"
rows="5"
placeholder="Enter Complete Delivery Address"
required><?php echo htmlspecialchars($address); ?></textarea>

</div>


<!-- BUTTON -->

<button
type="submit"
name="save_details"
class="checkout-btn">

<i class="fas fa-arrow-right"></i>

Proceed To Checkout

</button>


</form>


<a
href="product.php"
class="back-link">

<i class="fas fa-arrow-left"></i>

Continue Shopping

</a>


</div>

</div>

</div>

</div>


</body>

</html>