<?php
session_start();
include "config.php";

if (!isset($_GET['id'])) {
    die("Product ID Not Found");
}

$id = (int)$_GET['id'];

$query = "SELECT * FROM cake WHERE id='$id'";
$result = mysqli_query($conn, $query);

if (!$result) {
    die(mysqli_error($conn));
}

if (mysqli_num_rows($result) == 0) {
    die("Cake Not Found");
}

$cake = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Cart | Swiffin Cake Shop</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<style>

body{
    background:#000;
    color:#fff;
    font-family:Arial,sans-serif;
}

.cart-box{
    background:#1b1b1b;
    border-radius:20px;
    padding:30px;
    margin-top:60px;
    box-shadow:0 0 20px rgba(255,153,0,.25);
}

.cart-img{
    width:100%;
    height:320px;
    object-fit:cover;
    border-radius:15px;
}

.form-control{
    background:#2b2b2b;
    color:#fff;
    border:1px solid #555;
}

.form-control:focus{
    background:#2b2b2b;
    color:#fff;
    border-color:#E88F2A;
    box-shadow:none;
}

.btn-theme{
    background:#E88F2A;
    color:#fff;
    font-weight:bold;
}

.btn-theme:hover{
    background:#d97b11;
    color:#fff;
}

.price{
    font-size:30px;
    color:#E88F2A;
    font-weight:bold;
}

.stock{
    color:#00ff66;
    font-weight:bold;
}

</style>

</head>

<body>

<div class="container">

<div class="cart-box">

<div class="row">

<div class="col-lg-5">

<img src="img/<?php echo $cake['image']; ?>" class="cart-img">

</div>

<div class="col-lg-7">

<h2 class="text-warning">
<?php echo $cake['cake_name']; ?>
</h2>

<p>

<b>Category :</b>

<?php echo $cake['category']; ?>

</p>

<p>

<b>Flavour :</b>

<?php echo $cake['flavour']; ?>

</p>

<p>

<b>Weight :</b>

<?php echo $cake['weight']; ?>

</p>

<p>

<?php echo $cake['description']; ?>

</p>

<div class="price">

₹<?php echo $cake['price']; ?>

</div>

<p class="stock">

Available Stock :

<?php echo $cake['stock']; ?>

</p>

<hr>

<form id="cartForm">


<input type="hidden" name="cake_id"
 value="<?php echo $cake['id']; ?>">
 
<input type="hidden" name="cake_name"
value="<?php echo $cake['cake_name']; ?>">

<input type="hidden" name="price"
id="price"
value="<?php echo $cake['price']; ?>">

<div class="mb-3">

<label>Customer Name</label>

<input type="text"
class="form-control"
name="customer_name"
required>

</div>

<div class="mb-3">

<label>Email</label>

<div class="input-group">

<input type="email"
class="form-control"
name="email"
id="email"
required>

<button
type="button"
class="btn btn-theme"
id="sendOtp">

Send OTP

</button>

</div>

</div>

<div class="mb-3">

<label>OTP</label>

<div class="input-group">

<input
type="text"
class="form-control"
name="otp"
id="otp"
maxlength="6"
required>

<button
type="button"
class="btn btn-success"
id="verifyOtp">

Verify

</button>

</div>

</div>

<div class="mb-3">

<label>Quantity</label>

<input
type="number"
class="form-control"
name="quantity"
id="quantity"
value="1"
min="1"
max="<?php echo $cake['stock']; ?>"
required>

</div>

<div class="mb-3">

<label>Total</label>

<input
type="text"
class="form-control"
id="total"
readonly>

</div>

<div id="msg"></div>
<button type="submit" class="btn btn-theme w-100">
    <i class="fas fa-shopping-cart"></i> Add To Cart
</button>

</form>

</div>

</div>

</div>

</div>

<script>

var verified = false;

// Total Calculate
function calculateTotal()
{
    var qty = parseInt($("#quantity").val()) || 1;
    var price = parseFloat($("#price").val()) || 0;

    $("#total").val("₹" + (qty * price).toFixed(2));
}

calculateTotal();

$("#quantity").on("keyup change", function(){
    calculateTotal();
});

// Send OTP
$("#sendOtp").click(function(){

    if($("#email").val()=="")
    {
        alert("Please Enter Email");
        return;
    }

    $.ajax({

        url:"send_otp.php",
        type:"POST",

        data:{
            email:$("#email").val()
        },

        success:function(response){

            $("#msg").html(
                "<div class='alert alert-info mt-3'>"+response+"</div>"
            );

        }

    });

});

// Verify OTP
$("#verifyOtp").click(function(){

    $.ajax({

        url:"verify_otp.php",
        type:"POST",

        data:{
            otp:$("#otp").val()
        },

        success:function(response){

            if(response=="OTP Verified")
            {
                verified=true;

                $("#msg").html(
                    "<div class='alert alert-success mt-3'>OTP Verified Successfully</div>"
                );
            }
            else
            {
                verified=false;

                $("#msg").html(
                    "<div class='alert alert-danger mt-3'>"+response+"</div>"
                );
            }

        }

    });

});

// Add To Cart
$("#cartForm").submit(function(e){

    e.preventDefault();

    if(!verified)
    {
        alert("Please Verify OTP First");
        return;
    }

    $.ajax({

        url:"cart_insert.php",
        type:"POST",

        data:$("#cartForm").serialize(),

        success:function(response){

            $("#msg").html(
                "<div class='alert alert-success mt-3'>"+response+"</div>"
            );

            verified=false;

        }

    });

});

</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>