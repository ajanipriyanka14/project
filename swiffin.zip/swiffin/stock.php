<?php
session_start();
include "config.php";

/* ================= UPDATE STOCK ================= */

if (isset($_POST['update_stock'])) {

    $id = intval($_POST['id']);
    $stock = intval($_POST['stock']);

    if ($stock < 0) {
        $stock = 0;
    }

    if ($stock > 0) {
        $status = "Available";
    } else {
        $status = "Out of Stock";
    }

    $sql = "UPDATE cake
            SET stock='$stock', status='$status'
            WHERE id='$id'";

    if (mysqli_query($conn, $sql)) {

        echo "<script>
                alert('Stock Updated Successfully');
                window.location='stock.php';
              </script>";
        exit();

    } else {

        echo "<script>
                alert('Stock Update Failed');
              </script>";
    }
}

/* ================= GET CAKES ================= */

$result = mysqli_query(
    $conn,
    "SELECT * FROM cake ORDER BY id DESC"
);

if (!$result) {
    die("Database Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Stock Management | Swiffin Cake Shop</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
rel="stylesheet">

<style>

body{
    margin:0;
    padding:0;
    background:#000;
    color:#fff;
    font-family:Arial,sans-serif;
}

/* ================= MAIN ================= */

.main{
    width:95%;
    max-width:1200px;
    margin:40px auto;
}

/* ================= TITLE ================= */

.page-title{
    text-align:center;
    margin-bottom:30px;
}

.page-title h2{
    color:#E88F2A;
    font-weight:bold;
}

.page-title p{
    color:#aaa;
}

/* ================= BOX ================= */

.stock-box{
    background:#111;
    border:1px solid #E88F2A;
    border-radius:18px;
    padding:25px;

    box-shadow:
        0 0 20px rgba(232,143,42,.25);
}

/* ================= TABLE ================= */

.table{
    margin:0;
}

.table thead th{
    background:#E88F2A !important;
    color:#fff !important;
    text-align:center;
    vertical-align:middle;
    border-color:#000;
}

.table tbody td{
    background:#1b1b1b !important;
    color:#fff !important;
    text-align:center;
    vertical-align:middle;
    border-color:#333;
}

/* ================= IMAGE ================= */

.cake-img{
    width:70px;
    height:70px;
    object-fit:cover;
    border-radius:10px;
    border:2px solid #E88F2A;
}

/* ================= STOCK INPUT ================= */

.stock-input{
    width:90px;
    background:#000;
    color:#fff;
    border:1px solid #E88F2A;
    border-radius:7px;
    padding:7px;
    text-align:center;
}

.stock-input:focus{
    outline:none;
    border-color:#fff;
}

/* ================= UPDATE BUTTON ================= */

.update-btn{
    background:#E88F2A;
    color:#fff;
    border:none;
    border-radius:20px;
    padding:8px 15px;
    font-weight:bold;
}

.update-btn:hover{
    background:#d67d18;
}

/* ================= STATUS ================= */

.available{
    color:#28a745;
    font-weight:bold;
}

.out-stock{
    color:#dc3545;
    font-weight:bold;
}

/* ================= BACK BUTTON ================= */

.back-btn{
    display:inline-block;
    margin-top:25px;
    background:#E88F2A;
    color:#fff;
    text-decoration:none;
    padding:10px 25px;
    border-radius:25px;
    font-weight:bold;
}

.back-btn:hover{
    background:#d67d18;
    color:#fff;
}

/* ================= MOBILE ================= */

@media(max-width:768px){

    .main{
        width:98%;
    }

    .stock-box{
        padding:10px;
    }

    .table{
        font-size:13px;
    }

}

</style>

</head>

<body>

<div class="main">

<!-- ================= TITLE ================= -->

<div class="page-title">

<h2>
    <i class="fas fa-boxes-stacked"></i>
    Stock Management
</h2>

<p>
    Manage cake stock and availability
</p>

</div>


<!-- ================= STOCK TABLE ================= -->

<div class="stock-box">

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>ID</th>

<th>Image</th>

<th>Cake Name</th>

<th>Category</th>

<th>Price</th>

<th>Stock</th>

<th>Status</th>

<th>Action</th>

</tr>

</thead>

<tbody>

<?php

if (mysqli_num_rows($result) > 0) {

while ($row = mysqli_fetch_assoc($result)) {

?>

<tr>

<!-- ID -->

<td>
<?php echo $row['id']; ?>
</td>


<!-- IMAGE -->

<td>

<?php

if (!empty($row['image'])) {

?>

<img
src="img/<?php echo htmlspecialchars($row['image']); ?>"
class="cake-img"
alt="Cake">

<?php

} else {

?>

<span>No Image</span>

<?php

}

?>

</td>


<!-- CAKE NAME -->

<td>
<strong>
<?php echo htmlspecialchars($row['cake_name']); ?>
</strong>
</td>


<!-- CATEGORY -->

<td>
<?php echo htmlspecialchars($row['category']); ?>
</td>


<!-- PRICE -->

<td>
₹<?php echo number_format($row['price'],2); ?>
</td>


<!-- STOCK -->

<td>

<strong>
<?php echo intval($row['stock']); ?>
</strong>

</td>


<!-- STATUS -->

<td>

<?php

if (intval($row['stock']) > 0) {

?>

<span class="available">
<i class="fas fa-circle-check"></i>
Available
</span>

<?php

} else {

?>

<span class="out-stock">
<i class="fas fa-circle-xmark"></i>
Out of Stock
</span>

<?php

}

?>

</td>


<!-- UPDATE -->

<td>

<form method="POST">

<input
type="hidden"
name="id"
value="<?php echo $row['id']; ?>">

<input
type="number"
name="stock"
class="stock-input"
min="0"
value="<?php echo intval($row['stock']); ?>"
required>

<button
type="submit"
name="update_stock"
class="update-btn">

<i class="fas fa-save"></i>
Update

</button>

</form>

</td>

</tr>

<?php

}

} else {

?>

<tr>

<td colspan="8">

No Cake Found

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>


<!-- ================= BACK ================= -->

<div class="text-center">

<a
href="admin_dashboard.php"
class="back-btn">

<i class="fas fa-arrow-left"></i>

Back to Dashboard

</a>

</div>

</div>

</body>

</html>