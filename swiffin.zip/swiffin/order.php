<?php
include "config.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Orders | Swiffin Cake Shop</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#000;
    color:#fff;
    font-family:Arial, sans-serif;
}

h2{
    color:#E88F2A;
    text-align:center;
    margin:30px 0;
    font-weight:bold;
}

.table-box{
    background:#1b1b1b;
    border-radius:15px;
    padding:20px;
    box-shadow:0 0 20px rgba(232,143,42,.35);
}

.table{
    color:#fff;
    margin-bottom:0;
}

.table th{
    background:#E88F2A;
    color:#fff !important;
    text-align:center;
}

.table td{
    background:#222;
    color:#fff !important;
    text-align:center;
    vertical-align:middle;
}

.badge{
    padding:8px 12px;
    font-size:14px;
}

</style>

</head>

<body>

<div class="container mt-5">

<h2>All Customer Orders</h2>

<div class="table-box">

<table class="table table-bordered table-hover">

<thead>

<tr>

<th>Order ID</th>
<th>Customer Name</th>
<th>Cake Name</th>
<th>Quantity</th>
<th>Amount</th>
<th>Status</th>
<th>Order Date</th>

</tr>

</thead>

<tbody>

<?php

$query = "SELECT * FROM orders ORDER BY id DESC";

$result = mysqli_query($conn,$query);

while($row=mysqli_fetch_assoc($result))
{
?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['customer_name']; ?></td>

<td><?php echo $row['cake_name']; ?></td>

<td><?php echo $row['quantity']; ?></td>

<td>₹<?php echo number_format($row['amount'],2); ?></td>

<td>

<?php

if($row['status']=="Pending")
{
    echo "<span class='badge bg-warning text-dark'>Pending</span>";
}
elseif($row['status']=="Preparing")
{
    echo "<span class='badge bg-info'>Preparing</span>";
}
elseif($row['status']=="Out For Delivery")
{
    echo "<span class='badge bg-primary'>Out For Delivery</span>";
}
elseif($row['status']=="Delivered")
{
    echo "<span class='badge bg-success'>Delivered</span>";
}
else
{
    echo "<span class='badge bg-secondary'>".$row['status']."</span>";
}

?>

</td>

<td><?php echo $row['order_date']; ?></td>

</tr>

<?php
}
?>

</tbody>

</table>

</div>

</div>

</body>
</html>