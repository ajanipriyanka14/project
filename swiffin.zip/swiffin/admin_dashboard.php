<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: admin.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>

<h1>Welcome Admin</h1>
<h3><?php echo $_SESSION['admin']; ?></h3>

<hr>

<a href="add_cake.php">Add Cake</a><br><br>
<a href="view_cake.php">View Cake</a><br><br>
<a href="edit_cake.php">edit Cake</a><br><br>
<a href="delete_cake.php">delete Cake</a><br><br>
<a href="order.php">Orders</a><br><br>
<a href="payment.php">payment </a><br><br>
<a href="customer.php">Customers </a><br><br>
<a href="carts.php">carts</a><br><br>

<a href="logout.php">Logout</a>

</body>
</html>
