
<?php

session_start();

include "config.php";


/* =====================================================
   GET CURRENT SETTINGS
===================================================== */

$query = mysqli_query(
    $conn,
    "SELECT * FROM settings WHERE id=1 LIMIT 1"
);

if (!$query) {

    die(
        "Settings Database Error: " .
        mysqli_error($conn)
    );

}

$settings = mysqli_fetch_assoc($query);


/* =====================================================
   UPDATE SETTINGS
===================================================== */

if (isset($_POST['save_settings'])) {

    $shop_name = mysqli_real_escape_string(
        $conn,
        $_POST['shop_name']
    );

    $admin_name = mysqli_real_escape_string(
        $conn,
        $_POST['admin_name']
    );

    $email = mysqli_real_escape_string(
        $conn,
        $_POST['email']
    );

    $mobile = mysqli_real_escape_string(
        $conn,
        $_POST['mobile']
    );

    $address = mysqli_real_escape_string(
        $conn,
        $_POST['address']
    );


    $update = mysqli_query(
        $conn,

        "UPDATE settings SET

        shop_name='$shop_name',
        admin_name='$admin_name',
        email='$email',
        mobile='$mobile',
        address='$address'

        WHERE id=1"
    );


    if ($update) {

        echo "<script>
                alert('Settings Updated Successfully');
                window.location='setting.php';
              </script>";

        exit();

    } else {

        die(
            "Settings Update Error: " .
            mysqli_error($conn)
        );

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Settings | SWIFFIN CAKE SHOP
</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
rel="stylesheet"
>


<style>

*{
    box-sizing:border-box;
}


body{

    margin:0;

    background:#000;

    color:#fff;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

}


/* =====================================================
   MAIN
===================================================== */

.main{

    width:95%;

    max-width:1000px;

    margin:50px auto;

}


/* =====================================================
   TITLE
===================================================== */

.page-title{

    text-align:center;

    margin-bottom:30px;

}


.page-title h2{

    color:#E88F2A;

    font-weight:bold;

}


.page-title p{

    color:#aaa;

}


/* =====================================================
   SETTINGS BOX
===================================================== */

.settings-box{

    background:#111;

    border:1px solid #E88F2A;

    border-radius:20px;

    padding:30px;

    box-shadow:
    0 0 25px
    rgba(232,143,42,.20);

}


/* =====================================================
   SECTION TITLE
===================================================== */

.section-title{

    color:#E88F2A;

    font-size:22px;

    font-weight:bold;

    margin-bottom:25px;

}


/* =====================================================
   LABEL
===================================================== */

.form-label{

    color:#fff;

    font-weight:bold;

}


/* =====================================================
   INPUT
===================================================== */

.form-control{

    background:#000 !important;

    color:#fff !important;

    border:1px solid #444 !important;

    padding:12px;

}


.form-control:focus{

    border-color:#E88F2A !important;

    box-shadow:
    0 0 8px
    rgba(232,143,42,.25) !important;

}


/* =====================================================
   BUTTON
===================================================== */

.save-btn{

    background:#E88F2A;

    color:#fff;

    border:none;

    border-radius:25px;

    padding:12px 30px;

    font-weight:bold;

}


.save-btn:hover{

    background:#d67d18;

    color:#fff;

}


/* =====================================================
   BACK
===================================================== */

.back-btn{

    display:inline-block;

    margin-top:25px;

    background:#E88F2A;

    color:#fff;

    text-decoration:none;

    padding:11px 25px;

    border-radius:25px;

    font-weight:bold;

}


.back-btn:hover{

    background:#d67d18;

    color:#fff;

}


/* =====================================================
   MOBILE
===================================================== */

@media(max-width:600px){

    .settings-box{

        padding:20px;

    }

}

</style>

</head>


<body>


<div class="main">


<!-- =====================================================
     TITLE
===================================================== -->

<div class="page-title">

<h2>

<i class="fas fa-cog"></i>

&nbsp; Settings

</h2>

<p>

Manage Swiffin Cake Shop Settings

</p>

</div>


<!-- =====================================================
     SETTINGS FORM
===================================================== -->

<div class="settings-box">


<div class="section-title">

<i class="fas fa-store"></i>

&nbsp; Shop Information

</div>


<form method="POST">


<div class="row g-3">


<!-- SHOP NAME -->

<div class="col-md-6">

<label class="form-label">

Shop Name

</label>

<input
type="text"
name="shop_name"
class="form-control"
value="<?php echo htmlspecialchars($settings['shop_name']); ?>"
required
>

</div>


<!-- ADMIN NAME -->

<div class="col-md-6">

<label class="form-label">

Admin Name

</label>

<input
type="text"
name="admin_name"
class="form-control"
value="<?php echo htmlspecialchars($settings['admin_name']); ?>"
required
>

</div>


<!-- EMAIL -->

<div class="col-md-6">

<label class="form-label">

Email

</label>

<input
type="email"
name="email"
class="form-control"
value="<?php echo htmlspecialchars($settings['email']); ?>"
required
>

</div>


<!-- MOBILE -->

<div class="col-md-6">

<label class="form-label">

Mobile

</label>

<input
type="text"
name="mobile"
class="form-control"
value="<?php echo htmlspecialchars($settings['mobile']); ?>"
required
>

</div>


<!-- ADDRESS -->

<div class="col-12">

<label class="form-label">

Shop Address

</label>

<textarea
name="address"
class="form-control"
rows="4"
required
><?php echo htmlspecialchars($settings['address']); ?></textarea>

</div>


<!-- BUTTON -->

<div class="col-12 text-center mt-4">

<button
type="submit"
name="save_settings"
class="save-btn"
>

<i class="fas fa-save"></i>

&nbsp; Save Settings

</button>

</div>


</div>


</form>


</div>


<!-- =====================================================
     BACK BUTTON
===================================================== -->

<div class="text-center">

<a
href="admin_dashboard.php"
class="back-btn"
>

<i class="fas fa-arrow-left"></i>

&nbsp; Back To Dashboard

</a>

</div>


</div>


<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>


</body>

</html>

