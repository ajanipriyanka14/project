<?php

include "config.php";

if (!isset($_GET['cake_name'])) {
    die("Cake Name Not Found");
}

$cake_name = mysqli_real_escape_string(
    $conn,
    $_GET['cake_name']
);

$query = mysqli_query(
    $conn,
    "SELECT *
     FROM feedback
     WHERE cake_name='$cake_name'
     ORDER BY id DESC"
);

if (!$query) {
    die("Database Error: " . mysqli_error($conn));
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
Reviews | Swiffin Cake Shop
</title>

<style>

*{
    box-sizing:border-box;
}

body{

    margin:0;

    background:#000;

    color:#fff;

    font-family:Arial, Helvetica, sans-serif;

}

.container{

    width:92%;

    max-width:900px;

    margin:50px auto;

}

.title{

    text-align:center;

    color:#E88F2A;

    font-size:32px;

    font-weight:bold;

    margin-bottom:10px;

}

.subtitle{

    text-align:center;

    color:#aaa;

    margin-bottom:30px;

}

.review-box{

    background:#111;

    border:1px solid #E88F2A;

    border-radius:18px;

    padding:25px;

    margin-bottom:20px;

    box-shadow:0 0 15px rgba(232,143,42,.15);

}

.cake-name{

    color:#E88F2A;

    font-size:22px;

    font-weight:bold;

    margin-bottom:10px;

}

.customer{

    color:#fff;

    font-weight:bold;

}

.stars{

    color:#E88F2A;

    font-size:22px;

    margin:8px 0;

}

.message{

    color:#ddd;

    font-size:16px;

    line-height:1.6;

}

.date{

    color:#777;

    font-size:13px;

    margin-top:10px;

}

.no-review{

    background:#111;

    border:1px solid #333;

    border-radius:15px;

    padding:30px;

    text-align:center;

    color:#aaa;

}

.back-btn{

    display:block;

    width:220px;

    margin:30px auto;

    padding:12px;

    text-align:center;

    background:#E88F2A;

    color:#fff;

    text-decoration:none;

    border-radius:25px;

    font-weight:bold;

}

.back-btn:hover{

    background:#d67d18;

    color:#fff;

}

</style>

</head>

<body>

<div class="container">

<div class="title">

⭐ Customer Reviews

</div>

<div class="subtitle">

Reviews for

<strong style="color:#fff;">

<?php echo htmlspecialchars($cake_name); ?>

</strong>

</div>


<?php

if (mysqli_num_rows($query) > 0) {

    while ($row = mysqli_fetch_assoc($query)) {

?>

<div class="review-box">

<div class="cake-name">

<?php

echo htmlspecialchars(
    $row['cake_name']
);

?>

</div>

<div class="customer">

👤

<?php

echo htmlspecialchars(
    $row['customer_name']
);

?>

</div>

<div class="stars">

<?php

$rating = intval($row['rating']);

for ($i = 1; $i <= 5; $i++) {

    if ($i <= $rating) {

        echo "★";

    } else {

        echo "☆";

    }

}

?>

</div>

<div class="message">

<?php

echo htmlspecialchars(
    $row['message']
);

?>

</div>

<div class="date">

📅

<?php

echo date(
    "d-m-Y h:i A",
    strtotime($row['feedback_date'])
);

?>

</div>

</div>

<?php

    }

} else {

?>

<div class="no-review">

<h3 style="color:#E88F2A;">

No Reviews Yet

</h3>

<p>

This cake has not received any reviews yet.

</p>

</div>

<?php

}

?>

<a href="product.php" class="back-btn">

← Back To Cakes

</a>

</div>

</body>

</html>