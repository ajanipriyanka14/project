<?php

session_start();
include "config.php";


/* =====================================================
   CHECK CUSTOMER LOGIN
===================================================== */

if (
    !isset($_SESSION['customer']) ||
    $_SESSION['customer'] !== true
) {

    echo "<script>
        alert('Please Login First');
        window.location='login.php';
    </script>";

    exit();
}


/* =====================================================
   CUSTOMER SESSION
===================================================== */

$customer_email =
    trim($_SESSION['customer_email'] ?? '');

$customer_name =
    trim($_SESSION['customer_name'] ?? '');


if ($customer_email == "") {

    echo "<script>
        alert('Please Login First');
        window.location='login.php';
    </script>";

    exit();
}


/* =====================================================
   CHECK REQUEST
===================================================== */

if (!isset($_POST['add_to_cart'])) {
    die("Invalid Request");
}


/* =====================================================
   GET DATA
===================================================== */

$cake_id =
    intval($_POST['cake_id'] ?? 0);

$quantity =
    intval($_POST['quantity'] ?? 1);


if ($cake_id <= 0) {
    die("Invalid Cake ID");
}

if ($quantity <= 0) {
    $quantity = 1;
}


/* =====================================================
   GET CAKE
===================================================== */

$stmt = mysqli_prepare(
    $conn,
    "SELECT *
     FROM cake
     WHERE id = ?
     LIMIT 1"
);

if (!$stmt) {
    die("Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $cake_id
);

mysqli_stmt_execute($stmt);

$result =
    mysqli_stmt_get_result($stmt);


if (!$result) {
    die("Database Error: " . mysqli_error($conn));
}


if (mysqli_num_rows($result) == 0) {
    die("Cake Not Found");
}


$cake =
    mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);


/* =====================================================
   CAKE DATA
===================================================== */

$cake_name =
    $cake['cake_name'];

$price =
    floatval($cake['price']);

$stock =
    intval($cake['stock']);

$status =
    $cake['status'];


/* =====================================================
   STOCK CHECK
===================================================== */

if (
    $stock <= 0 ||
    $status != "Available"
) {

    echo "<script>
        alert('This Cake is Out of Stock!');
        window.location='product.php';
    </script>";

    exit();
}


if ($quantity > $stock) {

    echo "<script>
        alert('Only $stock Cake(s) Available');
        window.location='product.php';
    </script>";

    exit();
}


/* =====================================================
   TOTAL
===================================================== */

$total =
    $quantity * $price;


/* =====================================================
   INSERT INTO CART
===================================================== */

$stmt = mysqli_prepare(
    $conn,

    "INSERT INTO carts
    (
        customer_name,
        email,
        cake_name,
        cake_id,
        quantity,
        price,
        total
    )
    VALUES (?, ?, ?, ?, ?, ?, ?)"
);


if (!$stmt) {
    die("Prepare Error: " . mysqli_error($conn));
}


mysqli_stmt_bind_param(
    $stmt,
    "sssiidd",
    $customer_name,
    $customer_email,
    $cake_name,
    $cake_id,
    $quantity,
    $price,
    $total
);


/* =====================================================
   EXECUTE
===================================================== */

if (!mysqli_stmt_execute($stmt)) {

    die(
        "Cart Insert Error: " .
        mysqli_stmt_error($stmt)
    );
}


$cart_id =
    mysqli_insert_id($conn);

mysqli_stmt_close($stmt);


/* =====================================================
   GO TO CART
===================================================== */

header(
    "Location: carts.php?id=" . $cart_id
);

exit();

?>