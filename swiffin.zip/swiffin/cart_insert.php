<?php
include "config.php";

if(isset($_POST['customer_name']))
{
    $cake_id       = $_POST['cake_id'];
    $customer_name = $_POST['customer_name'];
    $email         = $_POST['email'];
    $cake_name     = $_POST['cake_name'];
    $quantity      = $_POST['quantity'];
    $price         = $_POST['price'];
    $otp           = $_POST['otp'];

    // Cake Stock Check
    $check = mysqli_query($conn,"SELECT stock FROM cake WHERE id='$cake_id'");

    if(mysqli_num_rows($check)==0)
    {
        die("Cake Not Found");
    }

    $cake = mysqli_fetch_assoc($check);

    if($cake['stock'] < $quantity)
    {
        die("Only ".$cake['stock']." Cake(s) Available");
    }

    $total = $quantity * $price;

    // Insert Cart
    $insert = mysqli_query($conn,"
    INSERT INTO carts
    (customer_name,email,cake_name,quantity,price,total,otp,otp_status)
    VALUES
    ('$customer_name',
     '$email',
     '$cake_name',
     '$quantity',
     '$price',
     '$total',
     '$otp',
     'Verified')
    ");

    if($insert)
    {
        // Update Stock
        mysqli_query($conn,"
        UPDATE cake
        SET stock = stock - $quantity
        WHERE id='$cake_id'
        ");

        // Auto Status Update
        mysqli_query($conn,"
        UPDATE cake
        SET status='Out of Stock'
        WHERE id='$cake_id'
        AND stock<=0
        ");

        echo "🎉 Cake Added To Cart Successfully";
    }
    else
    {
        echo "Database Error : ".mysqli_error($conn);
    }
}
else
{
    echo "Invalid Request";
}
?>