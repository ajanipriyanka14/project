<?php

session_start();
include "config.php";

if (!isset($_POST['add_to_cart'])) {
    die("Invalid Request");
}

$cake_id = intval($_POST['cake_id']);
$quantity = intval($_POST['quantity']);

if ($cake_id <= 0) {
    die("Invalid Cake ID");
}

if ($quantity <= 0) {
    $quantity = 1;
}

/* GET CAKE */

$query = mysqli_query(
    $conn,
    "SELECT * FROM cake WHERE id='$cake_id' LIMIT 1"
);

if (!$query) {
    die("Database Error: " . mysqli_error($conn));
}

if (mysqli_num_rows($query) == 0) {
    die("Cake Not Found");
}

$cake = mysqli_fetch_assoc($query);

$cake_name = $cake['cake_name'];
$price = floatval($cake['price']);
$stock = intval($cake['stock']);
$status = $cake['status'];

/* STOCK CHECK */

if ($stock <= 0 || $status != "Available") {

    echo "<script>
        alert('This Cake is Out of Stock!');
        window.location='product.php';
    </script>";

    exit();
}

if ($quantity > $stock) {

    echo "<script>
        alert('Only $stock Cake(s) Available');
        window.location='product.php';
    </script>";

    exit();
}

/* TOTAL */

$total = $quantity * $price;

/* INSERT CART */

$stmt = mysqli_prepare(
    $conn,
    "INSERT INTO carts
    (cake_name, quantity, price, total)
    VALUES (?, ?, ?, ?)"
);

mysqli_stmt_bind_param(
    $stmt,
    "sidd",
    $cake_name,
    $quantity,
    $price,
    $total
);

if (!mysqli_stmt_execute($stmt)) {
    die("Cart Insert Error: " . mysqli_error($conn));
}

/* GET NEW CART ID */

$cart_id = mysqli_insert_id($conn);

mysqli_stmt_close($stmt);

/* IMPORTANT */

if ($cart_id <= 0) {
    die("Cart ID Not Generated");
}

/* GO TO CART */

header("Location: carts.php?id=" . $cart_id);
exit();

?>