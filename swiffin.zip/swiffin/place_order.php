<?php

session_start();
include "config.php";


/* =====================================================
   CHECK CART ID
===================================================== */

if (!isset($_POST['cart_id']) && !isset($_GET['cart_id'])) {

    die("Cart ID Not Found");

}

if (isset($_POST['cart_id'])) {

    $cart_id = intval($_POST['cart_id']);

} else {

    $cart_id = intval($_GET['cart_id']);

}

if ($cart_id <= 0) {

    die("Invalid Cart ID");

}


/* =====================================================
   GET PAYMENT METHOD
===================================================== */

$payment_method = "";

if (isset($_POST['payment_method'])) {

    $payment_method = trim($_POST['payment_method']);

} elseif (isset($_GET['payment_method'])) {

    $payment_method = trim($_GET['payment_method']);

}

if ($payment_method == "") {

    $payment_method = "Cash on Delivery";

}


/* =====================================================
   GET CART DATA
===================================================== */

$cart_query = mysqli_query(
    $conn,
    "SELECT * FROM carts WHERE id='$cart_id' LIMIT 1"
);

if (!$cart_query) {

    die(
        "Cart Database Error: " .
        mysqli_error($conn)
    );

}

if (mysqli_num_rows($cart_query) == 0) {

    die("Cart Record Not Found");

}

$cart = mysqli_fetch_assoc($cart_query);


/* =====================================================
   CART DETAILS
===================================================== */

$customer_name = $cart['customer_name'];
$email         = $cart['email'];
$cake_name     = $cart['cake_name'];
$quantity      = intval($cart['quantity']);
$amount        = floatval($cart['total']);


/* =====================================================
   MOBILE AND ADDRESS
===================================================== */

$mobile = isset($cart['mobile'])
        ? trim($cart['mobile'])
        : "";

$address = isset($cart['address'])
         ? trim($cart['address'])
         : "";


/*
   Delivery table ma mobile/address NOT NULL chhe.
   Jo cart ma blank hoy to pan record save thay
   etle temporary value muki rahya chhiye.
*/

if ($mobile == "") {

    $mobile = "Not Provided";

}

if ($address == "") {

    $address = "Not Provided";

}


/* =====================================================
   ORDER DATA
===================================================== */

$status = "Pending";

$order_date = date("Y-m-d H:i:s");


/* =====================================================
   ESCAPE DATA
===================================================== */

$customer_name_safe = mysqli_real_escape_string(
    $conn,
    $customer_name
);

$cake_name_safe = mysqli_real_escape_string(
    $conn,
    $cake_name
);

$status_safe = mysqli_real_escape_string(
    $conn,
    $status
);

$mobile_safe = mysqli_real_escape_string(
    $conn,
    $mobile
);

$address_safe = mysqli_real_escape_string(
    $conn,
    $address
);

$payment_method_safe = mysqli_real_escape_string(
    $conn,
    $payment_method
);


/* =====================================================
   INSERT ORDER
===================================================== */

$insert_order = mysqli_query(
    $conn,

    "INSERT INTO orders
    (
        customer_name,
        cake_name,
        quantity,
        amount,
        status,
        order_date
    )
    VALUES
    (
        '$customer_name_safe',
        '$cake_name_safe',
        '$quantity',
        '$amount',
        '$status_safe',
        '$order_date'
    )"
);


/* =====================================================
   CHECK ORDER INSERT
===================================================== */

if (!$insert_order) {

    die(
        "Order Insert Error: " .
        mysqli_error($conn)
    );

}


/* =====================================================
   GET NEW ORDER ID
===================================================== */

$new_order_id = mysqli_insert_id($conn);


if ($new_order_id <= 0) {

    die("Order ID Not Generated");

}


/* =====================================================
   INSERT DELIVERY RECORD
===================================================== */

$delivery_status = "Pending";


$delivery_insert = mysqli_query(
    $conn,

    "INSERT INTO delivery
    (
        order_id,
        customer_name,
        mobile,
        address,
        delivery_person,
        delivery_status,
        delivery_date
    )
    VALUES
    (
        '$new_order_id',
        '$customer_name_safe',
        '$mobile_safe',
        '$address_safe',
        NULL,
        '$delivery_status',
        NULL
    )"
);


/* =====================================================
   CHECK DELIVERY INSERT
===================================================== */

if (!$delivery_insert) {

    die(
        "<h2 style='color:red;'>Delivery Record Not Saved</h2>" .
        "<p><b>Error:</b> " .
        mysqli_error($conn) .
        "</p>"
    );

}


/* =====================================================
   DELETE CART
===================================================== */

$delete_cart = mysqli_query(
    $conn,

    "DELETE FROM carts
     WHERE id='$cart_id'"
);


if (!$delete_cart) {

    die(
        "Cart Delete Error: " .
        mysqli_error($conn)
    );

}

?>


<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
Order Confirmed | Swiffin Cake Shop
</title>


<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
rel="stylesheet"
>


<style>

*{
    box-sizing:border-box;
}

body{

    margin:0;
    padding:0;

    background:#000;

    color:#fff;

    font-family:
    Arial,
    Helvetica,
    sans-serif;

}


/* ================= CONTAINER ================= */

.success-container{

    width:92%;

    max-width:700px;

    margin:70px auto;

}


/* ================= SUCCESS BOX ================= */

.success-box{

    background:#111;

    border:2px solid #E88F2A;

    border-radius:25px;

    padding:45px 35px;

    text-align:center;

    box-shadow:
    0 0 25px rgba(232,143,42,.35),
    0 0 60px rgba(232,143,42,.12);

}


/* ================= SUCCESS ICON ================= */

.success-icon{

    width:90px;

    height:90px;

    margin:0 auto 20px;

    background:#28a745;

    border-radius:50%;

    display:flex;

    align-items:center;

    justify-content:center;

    color:#fff;

    font-size:50px;

    box-shadow:
    0 0 20px rgba(40,167,69,.4);

}


/* ================= HEADING ================= */

.success-box h1{

    color:#E88F2A;

    font-size:34px;

    font-weight:bold;

    margin-bottom:12px;

}


/* ================= MESSAGE ================= */

.success-message{

    color:#ccc;

    font-size:17px;

    margin-bottom:30px;

}


/* ================= ORDER ID ================= */

.order-id{

    background:#000;

    border:1px solid #E88F2A;

    border-radius:12px;

    padding:15px;

    margin-bottom:25px;

}


.order-id span{

    color:#aaa;

    display:block;

    font-size:14px;

    margin-bottom:5px;

}


.order-id strong{

    color:#E88F2A;

    font-size:25px;

}


/* ================= DETAILS ================= */

.order-details{

    background:#1b1b1b;

    border:1px solid #333;

    border-radius:15px;

    padding:20px;

    text-align:left;

}


.detail-row{

    display:flex;

    justify-content:space-between;

    align-items:center;

    gap:20px;

    padding:13px 0;

    border-bottom:1px solid #333;

}


.detail-row:last-child{

    border-bottom:none;

}


.detail-label{

    color:#aaa;

}


.detail-value{

    color:#fff;

    font-weight:bold;

    text-align:right;

}


.amount{

    color:#E88F2A !important;

    font-size:22px;

}


.status{

    color:#ffc107 !important;

}


/* ================= HOME BUTTON ================= */

.home-btn{

    display:block;

    width:100%;

    margin-top:30px;

    padding:15px;

    background:#E88F2A;

    color:#fff;

    text-decoration:none;

    border-radius:30px;

    font-size:18px;

    font-weight:bold;

}


.home-btn:hover{

    background:#d67d18;

    color:#fff;

}


/* ================= MOBILE ================= */

@media(max-width:600px){

    .success-box{

        padding:30px 20px;

    }


    .success-box h1{

        font-size:27px;

    }


    .detail-row{

        flex-direction:column;

        align-items:flex-start;

        gap:5px;

    }


    .detail-value{

        text-align:left;

    }

}

</style>

</head>


<body>


<div class="success-container">

<div class="success-box">


<!-- SUCCESS ICON -->

<div class="success-icon">

<i class="fas fa-check"></i>

</div>


<!-- SUCCESS MESSAGE -->

<h1>

Order Confirmed Successfully!

</h1>


<p class="success-message">

Thank you for ordering from

<strong>
SWIFFIN CAKE SHOP
</strong>

<br>

Your order has been placed successfully.

</p>


<!-- ORDER ID -->

<div class="order-id">

<span>
Your Order ID
</span>

<strong>

#<?php echo $new_order_id; ?>

</strong>

</div>


<!-- ORDER DETAILS -->

<div class="order-details">


<!-- CUSTOMER -->

<div class="detail-row">

<div class="detail-label">
Customer Name
</div>

<div class="detail-value">

<?php

echo htmlspecialchars(
    $customer_name
);

?>

</div>

</div>


<!-- CAKE -->

<div class="detail-row">

<div class="detail-label">
Cake Name
</div>

<div class="detail-value">

<?php

echo htmlspecialchars(
    $cake_name
);

?>

</div>

</div>


<!-- QUANTITY -->

<div class="detail-row">

<div class="detail-label">
Quantity
</div>

<div class="detail-value">

<?php

echo $quantity;

?>

</div>

</div>


<!-- PAYMENT -->

<div class="detail-row">

<div class="detail-label">
Payment Method
</div>

<div class="detail-value">

<?php

echo htmlspecialchars(
    $payment_method
);

?>

</div>

</div>


<!-- AMOUNT -->

<div class="detail-row">

<div class="detail-label">
Total Amount
</div>

<div class="detail-value amount">

₹<?php

echo number_format(
    $amount,
    2
);

?>

</div>

</div>


<!-- STATUS -->

<div class="detail-row">

<div class="detail-label">
Order Status
</div>

<div class="detail-value status">

<?php

echo $status;

?>

</div>

</div>


<!-- DATE -->

<div class="detail-row">

<div class="detail-label">
Order Date
</div>

<div class="detail-value">

<?php

echo date(
    "d-m-Y h:i A",
    strtotime($order_date)
);

?>

</div>

</div>


</div>

<!-- RATE & REVIEW BUTTON -->

<a
href="feedback.php?order_id=<?php echo $new_order_id; ?>"
class="home-btn"
style="background:#28a745;"
>
⭐ Rate & Review
</a>


<!-- HOME BUTTON -->

<a
href="index1.php"
class="home-btn"
>

<i class="fas fa-home"></i>

Back To Home

</a>


</div>

</div>


</body>

</html>

