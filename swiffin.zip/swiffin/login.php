<?php

session_start();

include 'config.php';
if(isset($_POST['login']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM login 
              WHERE name='$name' 
              AND email='$email' 
              AND password='$password'";

    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result) > 0)
    {
        $row = mysqli_fetch_assoc($result);

        $_SESSION['name'] = $row['name'];
        $_SESSION['email'] = $row['email'];

        echo "<script>
        alert('Login Successfully');
        window.location='index1.php';
        </script>";
        exit();
    }
    else
    {
        echo "<script>alert('Invalid Name, Email or Password');</script>";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Swiffin Cake Shop Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel ="stylesheet" href="css/login.css">

<style>

body{
    background:#fff0f5;
}

.login-box{
    width:400px;
    margin:80px auto;
    background:white;
    padding:30px;
    border-radius:15px;
    box-shadow:0px 0px 15px gray;
}

h2{
    text-align:center;
    color:#d63384;
}

.btn-cake{
    background:#d63384;
    color:white;
    width:100%;
}

.btn-cake:hover{
    background:#b02a6f;
    color:white;
}

a{
    color:#d63384;
    text-decoration:none;
}

</style>

</head>

<body>

<div class="container mt-5">

<div class="card p-4 mx-auto" style="width:400px">

<h2 class="text-center">swiffin cake login</h2>

<form method="POST" action="login.php">


<label>name</label>
<input type="name" name="name" class="form-control" required>

<br>

<label>email</label>
<input type="email" name="email" class="form-control" required>

<br>

<label>password</label>
<input type="password" name="password" class="form-control" required>

<br>

<input type="submit" name="login" value="Login" class="btn btn-primary w-100">

<br><br>

<p class="text-center">
    Don't have an account?
    <a href="register.php">Register</a>
</p>

</form>

</div>

</div>

</body>
</html>