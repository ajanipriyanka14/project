```php
<?php

include "config.php";

/* ================= GET FEEDBACK ================= */

$query = mysqli_query(
    $conn,
    "SELECT * FROM feedback ORDER BY id DESC"
);

if (!$query) {
    die("Database Error: " . mysqli_error($conn));
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>
View Feedback | Swiffin Cake Shop
</title>


<style>

*{
    box-sizing:border-box;
}

body{

    margin:0;

    padding:0;

    background:#000;

    color:#fff;

    font-family:Arial,sans-serif;

}


/* ================= MAIN ================= */

.container{

    width:95%;

    max-width:1250px;

    margin:40px auto;

}


/* ================= TITLE ================= */

.title{

    text-align:center;

    margin-bottom:30px;

}

.title h2{

    color:#E88F2A;

    font-weight:bold;

    margin-bottom:8px;

}

.title p{

    color:#aaa;

}


/* ================= BOX ================= */

.feedback-box{

    background:#111;

    border:1px solid #E88F2A;

    border-radius:18px;

    padding:25px;

    box-shadow:
    0 0 25px rgba(232,143,42,.25);

}


/* ================= TABLE ================= */

.table-responsive{

    overflow-x:auto;

}

table{

    width:100%;

    border-collapse:collapse;

}

th{

    background:#E88F2A;

    color:#fff;

    padding:14px;

    text-align:center;

    white-space:nowrap;

}

td{

    background:#1b1b1b;

    color:#fff;

    padding:14px;

    text-align:center;

    border-bottom:1px solid #333;

    vertical-align:middle;

}


/* ================= REVIEW ================= */

.review-text{

    max-width:300px;

    color:#ccc;

    text-align:left;

    line-height:1.5;

}


/* ================= STARS ================= */

.stars{

    color:#ffc107;

    font-size:20px;

    white-space:nowrap;

}


/* ================= DATE ================= */

.date{

    color:#aaa;

    white-space:nowrap;

}


/* ================= NO DATA ================= */

.no-data{

    text-align:center;

    color:#aaa;

    padding:30px;

}


/* ================= BACK BUTTON ================= */

.back-btn{

    display:inline-block;

    margin-top:25px;

    padding:12px 25px;

    background:#E88F2A;

    color:#fff;

    text-decoration:none;

    border-radius:25px;

    font-weight:bold;

}

.back-btn:hover{

    background:#d67d18;

    color:#fff;

}


/* ================= MOBILE ================= */

@media(max-width:700px){

    .feedback-box{

        padding:15px;

    }

    th,td{

        padding:10px;

        font-size:14px;

    }

}

</style>

</head>


<body>


<div class="container">


<!-- ================= TITLE ================= -->

<div class="title">

<h2>

⭐ Customer Feedback

</h2>

<p>

View customer ratings and reviews

</p>

</div>


<!-- ================= FEEDBACK TABLE ================= -->

<div class="feedback-box">


<div class="table-responsive">


<table>


<thead>

<tr>

<th>
ID
</th>

<th>
Order ID
</th>

<th>
Customer
</th>

<th>
Email
</th>

<th>
Cake
</th>

<th>
Rating
</th>

<th>
Review
</th>

<th>
Date
</th>

</tr>

</thead>


<tbody>


<?php

if (mysqli_num_rows($query) > 0) {

    while ($row = mysqli_fetch_assoc($query)) {

?>


<tr>


<td>

<?php

echo $row['id'];

?>

</td>


<td>

#<?php

echo $row['order_id'];

?>

</td>


<td>

<?php

echo htmlspecialchars(
    $row['customer_name']
);

?>

</td>


<td>

<?php

echo htmlspecialchars(
    $row['email']
);

?>

</td>


<td>

<?php

echo htmlspecialchars(
    $row['cake_name']
);

?>

</td>


<td>

<div class="stars">

<?php

$rating = intval($row['rating']);

for ($i = 1; $i <= 5; $i++) {

    if ($i <= $rating) {

        echo "★";

    } else {

        echo "☆";

    }

}

?>

</div>

</td>


<td>

<div class="review-text">

<?php

echo nl2br(
    htmlspecialchars(
        $row['message']
    )
);

?>

</div>

</td>


<td>

<div class="date">

<?php

if (!empty($row['feedback_date'])) {

    echo date(
        "d-m-Y h:i A",
        strtotime(
            $row['feedback_date']
        )
    );

} else {

    echo "-";

}

?>

</div>

</td>


</tr>


<?php

    }

} else {

?>


<tr>

<td
colspan="8"
class="no-data">

No Customer Feedback Found

</td>

</tr>


<?php

}

?>


</tbody>

</table>


</div>

</div>


<!-- ================= BACK ================= -->

<div style="text-align:center;">

<a
href="admin_dashboard.php"
class="back-btn">

← Back to Dashboard

</a>

</div>


</div>


</body>

</html>
```
