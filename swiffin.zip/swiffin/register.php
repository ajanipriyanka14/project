<?php
session_start();
include 'config.php';

if(isset($_POST['register']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $mobail = $_POST['mobail'];

    $query = "INSERT INTO reg(name,email,password,mobail)
              VALUES('$name','$email','$password','$mobail')";

    if(mysqli_query($conn,$query))
    {
        $_SESSION['name'] = $name;

        header("Location: index1.php");
        exit();
    }
    else
    {
        echo "Error: ".mysqli_error($conn);
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Cake Shop Registration</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel ="stylesheet" href="css/register.css">

<style>
body{
    background:#fff0f5;
}

.register-box{
    width:400px;
    margin:50px auto;
    background:white;
    padding:30px;
    border-radius:15px;
    box-shadow:0px 0px 10px gray;
}

h2{
    text-align:center;
    color:#d63384;
}

.btn-cake{
    background:#d63384;
    color:white;
    width:100%;
}
</style>

</head>

<body>

<div class="register-box">

<h2>🍰 swiffin cake shop Register</h2>

<br>

<form method="post">

<label>Name</label>
<input type="text" name="name" class="form-control" placeholder="Enter Name" required>

<br>

<label>Email</label>
<input type="email" name="email" class="form-control" placeholder="Enter Email" required>

<br>

<label>Password</label>
<input type="password" name="password" class="form-control" placeholder="Enter Password" required>

<br>

<label>Mobile Number</label>
<input type="text" name="mobail" class="form-control" placeholder="Enter Mobile Number" required>

<br>

<button type="submit" name="register" class="btn btn-cake">
Register
</button>

<br><br>

<p class="text-center">
Already have account?
<a href="login.php">Login</a>
</p>

</form>

</div>

</body>
</html>