<?php
include "config.php";

if(!isset($_GET['id']))
{
    die("Invalid Request");
}

$id = (int)$_GET['id'];

if(isset($_POST['delete']))
{
    $query = "DELETE FROM cake WHERE id='$id'";

    if(mysqli_query($conn,$query))
    {
        echo "<script>
        alert('Cake Deleted Successfully');
        window.location='view_cake.php';
        </script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Delete Cake</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#000;
    color:#fff;
}

.box{
    width:450px;
    margin:120px auto;
    background:#1b1b1b;
    padding:30px;
    border-radius:15px;
    text-align:center;
    box-shadow:0 0 20px rgba(232,143,42,.4);
}

h2{
    color:#E88F2A;
}

.btn-delete{
    background:#dc3545;
    color:#fff;
}

.btn-back{
    background:#E88F2A;
    color:#fff;
}

</style>

</head>

<body>

<div class="box">

<h2>Delete Cake</h2>

<p>Are you sure you want to delete this cake?</p>

<form method="post">

<button type="submit" name="delete" class="btn btn-delete">
Delete
</button>

<a href="view_cake.php" class="btn btn-back">
Cancel
</a>

</form>

</div>

</body>
</html>