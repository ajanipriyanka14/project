<?php
include "config.php";

if(isset($_GET['id']))
{
    $id = $_GET['id'];
}
else
{
    die("ID Not Found");
}

$query = "SELECT * FROM cake WHERE id='$id'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{
    $cake_name   = $_POST['cake_name'];
    $category    = $_POST['category'];
    $price       = $_POST['price'];
    $flavour     = $_POST['flavour'];
    $weight      = $_POST['weight'];
    $description = $_POST['description'];
    $stock       = $_POST['stock'];
    $status      = $_POST['status'];

    $update = "UPDATE cake SET
    cake_name='$cake_name',
    category='$category',
    price='$price',
    flavour='$flavour',
    weight='$weight',
    description='$description',
    stock='$stock',
    status='$status'
    WHERE id='$id'";

    $result2 = mysqli_query($conn, $update);

    if($result2)
    {
        header("Location:view_cake.php");
        exit();
    }
    else
    {
        echo "Update Failed";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Cake</title>
</head>

<body>

<h2>Edit Cake</h2>

<form method="post">

Cake Name:<br>
<input type="text" name="cake_name" value="<?php echo $row['cake_name']; ?>" required>
<br><br>

Category:<br>
<input type="text" name="category" value="<?php echo $row['category']; ?>" required>
<br><br>

Price:<br>
<input type="text" name="price" value="<?php echo $row['price']; ?>" required>
<br><br>

Flavour:<br>
<input type="text" name="flavour" value="<?php echo $row['flavour']; ?>" required>
<br><br>

Weight:<br>
<input type="text" name="weight" value="<?php echo $row['weight']; ?>" required>
<br><br>

Description:<br>
<textarea name="description" required><?php echo $row['description']; ?></textarea>
<br><br>

Stock:<br>
<input type="number" name="stock" value="<?php echo $row['stock']; ?>" required>
<br><br>

Status:<br>
<select name="status" required>
    <option value="Available" <?php if($row['status']=="Available") echo "selected"; ?>>
        Available
    </option>

    <option value="Out of Stock" <?php if($row['status']=="Out of Stock") echo "selected"; ?>>
        Out of Stock
    </option>
</select>

<br><br>

<input type="submit" name="update" value="Update Cake">

</form>

</body>
</html>