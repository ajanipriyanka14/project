
<?php

include "config.php";

/* =========================
   ORDER REPORT
========================= */

$total_orders = 0;
$pending_orders = 0;
$delivered_orders = 0;
$cancelled_orders = 0;
$total_sales = 0;

$result = mysqli_query(
    $conn,
    "SELECT * FROM orders"
);

if (!$result) {
    die("Order Database Error: " . mysqli_error($conn));
}

while ($row = mysqli_fetch_assoc($result)) {

    $total_orders++;

    $status = $row['status'];

    if ($status == "Pending") {
        $pending_orders++;
    }

    if ($status == "Delivered") {
        $delivered_orders++;
    }

    if ($status == "Cancelled") {
        $cancelled_orders++;
    }

    $total_sales += floatval($row['amount']);
}


/* =========================
   FEEDBACK REPORT
========================= */

$total_reviews = 0;
$total_rating = 0;

$feedback_query = mysqli_query(
    $conn,
    "SELECT * FROM feedback"
);

if (!$feedback_query) {
    die("Feedback Database Error: " . mysqli_error($conn));
}

while ($feedback = mysqli_fetch_assoc($feedback_query)) {

    $total_reviews++;

    $total_rating += intval($feedback['rating']);
}


/* Average Rating */

$average_rating = 0;

if ($total_reviews > 0) {

    $average_rating =
        $total_rating / $total_reviews;

}


/* =========================
   RECENT ORDERS
========================= */

$recent_orders = mysqli_query(
    $conn,
    "SELECT *
     FROM orders
     ORDER BY id DESC
     LIMIT 10"
);

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
Reports | Swiffin Cake Shop
</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
rel="stylesheet">

<style>

*{
    box-sizing:border-box;
}

body{

    margin:0;

    background:#000;

    color:#fff;

    font-family:Arial, Helvetica, sans-serif;

}

.main{

    width:95%;

    max-width:1250px;

    margin:40px auto;

}

.title{

    text-align:center;

    color:#E88F2A;

    font-size:34px;

    font-weight:bold;

    margin-bottom:10px;

}

.subtitle{

    text-align:center;

    color:#aaa;

    margin-bottom:35px;

}


/* ================= CARDS ================= */

.report-card{

    background:#111;

    border:1px solid #E88F2A;

    border-radius:18px;

    padding:25px;

    text-align:center;

    margin-bottom:25px;

    box-shadow:
    0 0 20px rgba(232,143,42,.20);

}

.report-icon{

    font-size:35px;

    color:#E88F2A;

    margin-bottom:10px;

}

.report-number{

    font-size:32px;

    font-weight:bold;

    color:#fff;

}

.report-label{

    color:#aaa;

    font-size:16px;

}


/* ================= SECTION ================= */

.section-title{

    color:#E88F2A;

    font-size:24px;

    font-weight:bold;

    margin:25px 0 15px;

}


/* ================= TABLE ================= */

.table-box{

    background:#111;

    border:1px solid #333;

    border-radius:18px;

    padding:20px;

    overflow:hidden;

}

.table{

    margin:0;

}

.table thead th{

    background:#E88F2A !important;

    color:#fff !important;

    text-align:center;

}

.table tbody td{

    background:#1b1b1b !important;

    color:#fff !important;

    text-align:center;

    vertical-align:middle;

    border-color:#333;

}


/* ================= STATUS ================= */

.pending{

    color:#ffc107;

    font-weight:bold;

}

.delivered{

    color:#28a745;

    font-weight:bold;

}

.cancelled{

    color:#dc3545;

    font-weight:bold;

}

.other{

    color:#0dcaf0;

    font-weight:bold;

}


/* ================= BACK ================= */

.back-btn{

    display:inline-block;

    margin-top:30px;

    background:#E88F2A;

    color:#fff;

    text-decoration:none;

    padding:12px 28px;

    border-radius:25px;

    font-weight:bold;

}

.back-btn:hover{

    background:#d67d18;

    color:#fff;

}

</style>

</head>


<body>


<div class="main">


<!-- ================= TITLE ================= -->

<div class="title">

<i class="fas fa-chart-column"></i>

&nbsp; Sales & Order Reports

</div>

<div class="subtitle">

Swiffin Cake Shop Report

</div>


<!-- ================= SUMMARY ================= -->

<div class="row">


<!-- TOTAL ORDERS -->

<div class="col-lg-3 col-md-6">

<div class="report-card">

<div class="report-icon">

<i class="fas fa-shopping-bag"></i>

</div>

<div class="report-number">

<?php echo $total_orders; ?>

</div>

<div class="report-label">

Total Orders

</div>

</div>

</div>


<!-- PENDING -->

<div class="col-lg-3 col-md-6">

<div class="report-card">

<div class="report-icon">

<i class="fas fa-clock"></i>

</div>

<div class="report-number">

<?php echo $pending_orders; ?>

</div>

<div class="report-label">

Pending Orders

</div>

</div>

</div>


<!-- DELIVERED -->

<div class="col-lg-3 col-md-6">

<div class="report-card">

<div class="report-icon">

<i class="fas fa-truck"></i>

</div>

<div class="report-number">

<?php echo $delivered_orders; ?>

</div>

<div class="report-label">

Delivered Orders

</div>

</div>

</div>


<!-- SALES -->

<div class="col-lg-3 col-md-6">

<div class="report-card">

<div class="report-icon">

<i class="fas fa-indian-rupee-sign"></i>

</div>

<div class="report-number">

₹<?php echo number_format($total_sales,2); ?>

</div>

<div class="report-label">

Total Sales

</div>

</div>

</div>


</div>


<!-- ================= FEEDBACK ================= -->

<div class="row">


<div class="col-lg-6">

<div class="report-card">

<div class="report-icon">

<i class="fas fa-star"></i>

</div>

<div class="report-number">

<?php echo $total_reviews; ?>

</div>

<div class="report-label">

Total Reviews

</div>

</div>

</div>


<div class="col-lg-6">

<div class="report-card">

<div class="report-icon">

⭐

</div>

<div class="report-number">

<?php echo number_format($average_rating,1); ?>

/ 5

</div>

<div class="report-label">

Average Rating

</div>

</div>

</div>


</div>


<!-- ================= ORDER REPORT ================= -->

<div class="section-title">

<i class="fas fa-list"></i>

Recent Orders

</div>


<div class="table-box">

<div class="table-responsive">

<table class="table table-bordered">


<thead>

<tr>

<th>Order ID</th>

<th>Customer</th>

<th>Cake</th>

<th>Quantity</th>

<th>Amount</th>

<th>Status</th>

<th>Date</th>

</tr>

</thead>


<tbody>

<?php

if (mysqli_num_rows($recent_orders) > 0) {

while ($row = mysqli_fetch_assoc($recent_orders)) {

?>

<tr>

<td>

#<?php echo $row['id']; ?>

</td>


<td>

<?php

echo htmlspecialchars(
    $row['customer_name']
);

?>

</td>


<td>

<?php

echo htmlspecialchars(
    $row['cake_name']
);

?>

</td>


<td>

<?php echo $row['quantity']; ?>

</td>


<td>

₹<?php

echo number_format(
    $row['amount'],
    2
);

?>

</td>


<td>

<?php

if ($row['status'] == "Pending") {

    echo "<span class='pending'>Pending</span>";

}

elseif ($row['status'] == "Delivered") {

    echo "<span class='delivered'>Delivered</span>";

}

elseif ($row['status'] == "Cancelled") {

    echo "<span class='cancelled'>Cancelled</span>";

}

else {

    echo "<span class='other'>".
         htmlspecialchars($row['status']).
         "</span>";

}

?>

</td>


<td>

<?php

echo date(
    "d-m-Y h:i A",
    strtotime($row['order_date'])
);

?>

</td>

</tr>

<?php

}

} else {

?>

<tr>

<td colspan="7">

No Orders Found

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>


<!-- ================= BACK ================= -->

<div class="text-center">

<a
href="admin_dashboard.php"
class="back-btn">

<i class="fas fa-arrow-left"></i>

&nbsp; Back To Dashboard

</a>

</div>


</div>


</body>

</html>
