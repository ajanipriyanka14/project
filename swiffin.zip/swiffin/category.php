<?php

session_start();
include("config.php");

/* =====================================================
   ADMIN LOGIN CHECK
===================================================== */

if (
    !isset($_SESSION['admin']) &&
    !isset($_SESSION['admin_name'])
) {
    header("Location: admin.php");
    exit();
}


/* =====================================================
   SETTINGS
===================================================== */

$image_folder = "img/category/";

$message = "";
$message_type = "";


/* =====================================================
   CREATE IMAGE FOLDER
===================================================== */

if (!is_dir($image_folder)) {
    mkdir($image_folder, 0777, true);
}


/* =====================================================
   UPLOAD MULTIPLE IMAGES
===================================================== */

function uploadMultipleImages($files, $folder)
{
    $uploaded = [];

    if (
        !isset($files['name']) ||
        !is_array($files['name'])
    ) {
        return $uploaded;
    }

    $allowed = [
        "jpg",
        "jpeg",
        "png",
        "webp"
    ];

    foreach ($files['name'] as $key => $original_name) {

        if (
            !isset($files['error'][$key]) ||
            $files['error'][$key] != 0
        ) {
            continue;
        }

        $extension = strtolower(
            pathinfo(
                $original_name,
                PATHINFO_EXTENSION
            )
        );

        if (!in_array($extension, $allowed)) {
            continue;
        }

        $new_name =
            time() .
            "_" .
            uniqid() .
            "." .
            $extension;

        if (
            move_uploaded_file(
                $files['tmp_name'][$key],
                $folder . $new_name
            )
        ) {
            $uploaded[] = $new_name;
        }
    }

    return $uploaded;
}


/* =====================================================
   ADD CATEGORY
===================================================== */

if (isset($_POST['add_category'])) {

    $category_name =
        trim($_POST['category_name'] ?? "");

    $description =
        trim($_POST['description'] ?? "");

    $parent_id =
        intval($_POST['parent_id'] ?? 0);

    $status =
        trim($_POST['status'] ?? "Active");


    if ($category_name == "") {

        $_SESSION['cat_msg'] =
            "Category name is required.";

        $_SESSION['cat_type'] =
            "error";

        header("Location: category.php");
        exit();
    }


    /* =================================================
       DUPLICATE CHECK
    ================================================= */

    $check = mysqli_prepare(
        $conn,
        "SELECT id
         FROM category
         WHERE category_name = ?
         LIMIT 1"
    );

    mysqli_stmt_bind_param(
        $check,
        "s",
        $category_name
    );

    mysqli_stmt_execute($check);

    $check_result =
        mysqli_stmt_get_result($check);

    if (
        mysqli_num_rows($check_result) > 0
    ) {

        mysqli_stmt_close($check);

        $_SESSION['cat_msg'] =
            "This category already exists.";

        $_SESSION['cat_type'] =
            "error";

        header("Location: category.php");
        exit();
    }

    mysqli_stmt_close($check);


    /* =================================================
       GET FIRST IMAGE FOR OLD image COLUMN
    ================================================= */

    $first_image = "";

    if (
        isset($_FILES['images']) &&
        isset($_FILES['images']['name']) &&
        is_array($_FILES['images']['name'])
    ) {

        foreach (
            $_FILES['images']['name']
            as $key => $name
        ) {

            if (
                $_FILES['images']['error'][$key] == 0
            ) {

                $ext = strtolower(
                    pathinfo(
                        $name,
                        PATHINFO_EXTENSION
                    )
                );

                if (
                    in_array(
                        $ext,
                        [
                            "jpg",
                            "jpeg",
                            "png",
                            "webp"
                        ]
                    )
                ) {

                    $first_image =
                        time() .
                        "_" .
                        uniqid() .
                        "." .
                        $ext;

                    if (
                        !move_uploaded_file(
                            $_FILES['images']['tmp_name'][$key],
                            $image_folder . $first_image
                        )
                    ) {
                        $first_image = "";
                    }

                    break;
                }
            }
        }
    }


    /* =================================================
       INSERT CATEGORY
    ================================================= */

    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO category
        (
            category_name,
            parent_id,
            description,
            image,
            status
        )
        VALUES (?, ?, ?, ?, ?)"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "sisss",
        $category_name,
        $parent_id,
        $description,
        $first_image,
        $status
    );


    if (
        mysqli_stmt_execute($stmt)
    ) {

        $category_id =
            mysqli_insert_id($conn);

        mysqli_stmt_close($stmt);


        /* =================================================
           SAVE FIRST IMAGE IN category_images
        ================================================= */

        if ($first_image != "") {

            $img_stmt = mysqli_prepare(
                $conn,
                "INSERT INTO category_images
                (category_id, image)
                VALUES (?, ?)"
            );

            mysqli_stmt_bind_param(
                $img_stmt,
                "is",
                $category_id,
                $first_image
            );

            mysqli_stmt_execute(
                $img_stmt
            );

            mysqli_stmt_close(
                $img_stmt
            );
        }


        /* =================================================
           SAVE REMAINING IMAGES
        ================================================= */

        if (
            isset($_FILES['images']) &&
            is_array($_FILES['images']['name'])
        ) {

            $already_saved = false;

            foreach (
                $_FILES['images']['name']
                as $key => $name
            ) {

                if (
                    $_FILES['images']['error'][$key] != 0
                ) {
                    continue;
                }

                $ext = strtolower(
                    pathinfo(
                        $name,
                        PATHINFO_EXTENSION
                    )
                );

                if (
                    !in_array(
                        $ext,
                        [
                            "jpg",
                            "jpeg",
                            "png",
                            "webp"
                        ]
                    )
                ) {
                    continue;
                }


                /* first uploaded image already saved */

                if (!$already_saved) {

                    $already_saved = true;

                    continue;
                }


                $new_image =
                    time() .
                    "_" .
                    uniqid() .
                    "." .
                    $ext;


                if (
                    move_uploaded_file(
                        $_FILES['images']['tmp_name'][$key],
                        $image_folder . $new_image
                    )
                ) {

                    $img_stmt = mysqli_prepare(
                        $conn,
                        "INSERT INTO category_images
                        (category_id, image)
                        VALUES (?, ?)"
                    );

                    mysqli_stmt_bind_param(
                        $img_stmt,
                        "is",
                        $category_id,
                        $new_image
                    );

                    mysqli_stmt_execute(
                        $img_stmt
                    );

                    mysqli_stmt_close(
                        $img_stmt
                    );
                }
            }
        }


        $_SESSION['cat_msg'] =
            "Category added successfully.";

        $_SESSION['cat_type'] =
            "success";

    } else {

        mysqli_stmt_close($stmt);

        $_SESSION['cat_msg'] =
            "Database Error: " .
            mysqli_error($conn);

        $_SESSION['cat_type'] =
            "error";
    }


    /* =================================================
       PREVENT DOUBLE INSERT
    ================================================= */

    header("Location: category.php");
    exit();
}


/* =====================================================
   UPDATE CATEGORY
===================================================== */

if (isset($_POST['update_category'])) {

    $id =
        intval($_POST['id'] ?? 0);

    $category_name =
        trim($_POST['category_name'] ?? "");

    $description =
        trim($_POST['description'] ?? "");

    $parent_id =
        intval($_POST['parent_id'] ?? 0);

    $status =
        trim($_POST['status'] ?? "Active");


    if (
        $id <= 0 ||
        $category_name == ""
    ) {

        $_SESSION['cat_msg'] =
            "Invalid category.";

        $_SESSION['cat_type'] =
            "error";

        header("Location: category.php");
        exit();
    }


    /* =================================================
       DUPLICATE CHECK
    ================================================= */

    $check = mysqli_prepare(
        $conn,
        "SELECT id
         FROM category
         WHERE category_name = ?
         AND id != ?
         LIMIT 1"
    );

    mysqli_stmt_bind_param(
        $check,
        "si",
        $category_name,
        $id
    );

    mysqli_stmt_execute($check);

    $check_result =
        mysqli_stmt_get_result($check);

    if (
        mysqli_num_rows($check_result) > 0
    ) {

        mysqli_stmt_close($check);

        $_SESSION['cat_msg'] =
            "Another category with this name already exists.";

        $_SESSION['cat_type'] =
            "error";

        header(
            "Location: category.php?edit=" .
            $id
        );

        exit();
    }

    mysqli_stmt_close($check);


    /* =================================================
       UPDATE CATEGORY
    ================================================= */

    $stmt = mysqli_prepare(
        $conn,
        "UPDATE category
         SET
            category_name = ?,
            parent_id = ?,
            description = ?,
            status = ?
         WHERE id = ?"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "sissi",
        $category_name,
        $parent_id,
        $description,
        $status,
        $id
    );


    if (
        mysqli_stmt_execute($stmt)
    ) {

        mysqli_stmt_close($stmt);


        /* =================================================
           ADD NEW MULTIPLE IMAGES
        ================================================= */

        if (
            isset($_FILES['images']) &&
            isset($_FILES['images']['name']) &&
            is_array($_FILES['images']['name'])
        ) {

            $new_images =
                uploadMultipleImages(
                    $_FILES['images'],
                    $image_folder
                );


            foreach (
                $new_images as $new_image
            ) {

                /* First image also update old image column
                   only if old image is empty */

                $old_check = mysqli_query(
                    $conn,
                    "SELECT image
                     FROM category
                     WHERE id = " .
                     intval($id)
                );

                $old_row =
                    mysqli_fetch_assoc(
                        $old_check
                    );


                if (
                    empty(
                        $old_row['image']
                    )
                ) {

                    $up = mysqli_prepare(
                        $conn,
                        "UPDATE category
                         SET image = ?
                         WHERE id = ?"
                    );

                    mysqli_stmt_bind_param(
                        $up,
                        "si",
                        $new_image,
                        $id
                    );

                    mysqli_stmt_execute($up);
                    mysqli_stmt_close($up);
                }


                $img_stmt = mysqli_prepare(
                    $conn,
                    "INSERT INTO category_images
                    (category_id, image)
                    VALUES (?, ?)"
                );

                mysqli_stmt_bind_param(
                    $img_stmt,
                    "is",
                    $id,
                    $new_image
                );

                mysqli_stmt_execute(
                    $img_stmt
                );

                mysqli_stmt_close(
                    $img_stmt
                );
            }
        }


        $_SESSION['cat_msg'] =
            "Category updated successfully.";

        $_SESSION['cat_type'] =
            "success";

    } else {

        mysqli_stmt_close($stmt);

        $_SESSION['cat_msg'] =
            "Database Error: " .
            mysqli_error($conn);

        $_SESSION['cat_type'] =
            "error";
    }


    header("Location: category.php");
    exit();
}


/* =====================================================
   DELETE CATEGORY
===================================================== */

if (isset($_GET['delete'])) {

    $id =
        intval($_GET['delete']);


    /* =================================================
       GET ALL IMAGES
    ================================================= */

    $img_query = mysqli_query(
        $conn,
        "SELECT image
         FROM category_images
         WHERE category_id = "
         . $id
    );


    if ($img_query) {

        while (
            $img =
            mysqli_fetch_assoc(
                $img_query
            )
        ) {

            if (
                !empty($img['image']) &&
                file_exists(
                    $image_folder .
                    $img['image']
                )
            ) {

                unlink(
                    $image_folder .
                    $img['image']
                );
            }
        }
    }


    /* =================================================
       GET OLD category.image
    ================================================= */

    $old_query = mysqli_query(
        $conn,
        "SELECT image
         FROM category
         WHERE id = "
         . $id
    );

    $old_data =
        mysqli_fetch_assoc(
            $old_query
        );


    if (
        !empty($old_data['image']) &&
        file_exists(
            $image_folder .
            $old_data['image']
        )
    ) {

        unlink(
            $image_folder .
            $old_data['image']
        );
    }


    /* =================================================
       DELETE CATEGORY
    ================================================= */

    $stmt = mysqli_prepare(
        $conn,
        "DELETE FROM category
         WHERE id = ?"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $id
    );

    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);


    header("Location: category.php");
    exit();
}


/* =====================================================
   MESSAGE
===================================================== */

if (
    isset(
        $_SESSION['cat_msg']
    )
) {

    $message =
        $_SESSION['cat_msg'];

    $message_type =
        $_SESSION['cat_type']
        ?? "";

    unset(
        $_SESSION['cat_msg'],
        $_SESSION['cat_type']
    );
}


/* =====================================================
   EDIT DATA
===================================================== */

$edit_data = null;

if (isset($_GET['edit'])) {

    $id =
        intval($_GET['edit']);

    $stmt = mysqli_prepare(
        $conn,
        "SELECT *
         FROM category
         WHERE id = ?"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $id
    );

    mysqli_stmt_execute($stmt);

    $edit_result =
        mysqli_stmt_get_result(
            $stmt
        );

    if (
        mysqli_num_rows(
            $edit_result
        ) > 0
    ) {

        $edit_data =
            mysqli_fetch_assoc(
                $edit_result
            );
    }

    mysqli_stmt_close($stmt);
}


/* =====================================================
   PARENT CATEGORIES
===================================================== */

$parent_result = mysqli_query(
    $conn,
    "SELECT *
     FROM category
     WHERE parent_id = 0
     ORDER BY category_name ASC"
);


/* =====================================================
   ALL CATEGORIES
===================================================== */

$result = mysqli_query(
    $conn,
    "SELECT
        c.*,
        p.category_name AS parent_name
     FROM category c
     LEFT JOIN category p
     ON c.parent_id = p.id
     ORDER BY c.id DESC"
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>Category Management | SWIFFIN</title>


<style>

* {
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body {
    font-family:Arial,sans-serif;
    background:#000;
    color:#fff;
}


/* SIDEBAR */

.sidebar {
    position:fixed;
    left:0;
    top:0;
    width:250px;
    height:100vh;
    background:#111;
    border-right:1px solid #333;
    overflow-y:auto;
}

.logo {
    height:75px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#E88F2A;
    font-size:28px;
    font-weight:bold;
    letter-spacing:3px;
    border-bottom:1px solid #333;
}

.admin-box {
    text-align:center;
    padding:20px;
    border-bottom:1px solid #333;
}

.admin-icon {
    width:48px;
    height:48px;
    margin:auto auto 10px;
    border-radius:50%;
    background:#E88F2A;
    color:#000;
    display:flex;
    align-items:center;
    justify-content:center;
}

.admin-box h4 {
    margin-bottom:5px;
}

.admin-box p {
    color:#777;
    font-size:12px;
}

.menu-title {
    color:#666;
    font-size:11px;
    font-weight:bold;
    padding:18px 20px 8px;
    text-transform:uppercase;
}

.sidebar a {
    display:flex;
    align-items:center;
    gap:12px;
    padding:12px 20px;
    color:#bbb;
    text-decoration:none;
    font-size:14px;
}

.sidebar a:hover,
.sidebar a.active {
    background:rgba(232,143,42,.12);
    color:#E88F2A;
    border-left:3px solid #E88F2A;
}

.icon {
    width:22px;
    text-align:center;
}


/* MAIN */

.main {
    margin-left:250px;
    min-height:100vh;
}

.topbar {
    height:75px;
    background:#111;
    border-bottom:1px solid #333;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 30px;
}

.topbar h2 {
    font-size:22px;
}

.topbar p {
    color:#777;
    font-size:12px;
    margin-top:5px;
}

.admin-name {
    color:#aaa;
    font-size:14px;
}

.admin-name span {
    color:#E88F2A;
    font-weight:bold;
}

.logout {
    display:inline-flex;
    background:#E88F2A;
    color:#fff;
    text-decoration:none;
    padding:9px 18px;
    border-radius:5px;
    margin-left:15px;
    font-size:13px;
    font-weight:bold;
}


/* CONTENT */

.content {
    padding:30px;
}

.page-title {
    margin-bottom:25px;
}

.page-title h1 {
    color:#E88F2A;
    font-size:27px;
    margin-bottom:7px;
}

.page-title p {
    color:#777;
    font-size:13px;
}


/* MESSAGE */

.message {
    padding:13px 16px;
    border-radius:6px;
    margin-bottom:20px;
}

.message.success {
    background:#132b18;
    border:1px solid #287a3e;
    color:#65d77c;
}

.message.error {
    background:#2b1111;
    border:1px solid #8b3030;
    color:#ff7777;
}


/* FORM */

.form-box {
    background:#111;
    border:1px solid #333;
    border-radius:8px;
    padding:25px;
    margin-bottom:30px;
}

.form-box h2 {
    font-size:18px;
    margin-bottom:20px;
}

.form-row {
    display:grid;
    grid-template-columns:
        1fr 1.5fr 1fr 180px;
    gap:15px;
    align-items:end;
}

.form-group label {
    display:block;
    color:#E88F2A;
    font-size:13px;
    font-weight:bold;
    margin-bottom:8px;
}

.form-group input,
.form-group select {
    width:100%;
    min-height:44px;
    padding:10px;
    background:#050505;
    color:#fff;
    border:1px solid #444;
    border-radius:5px;
    outline:none;
}

.form-group input[type=file] {
    cursor:pointer;
}

.add-btn,
.update-btn {
    height:44px;
    background:#E88F2A;
    color:#fff;
    border:none;
    border-radius:6px;
    font-weight:bold;
    cursor:pointer;
    padding:0 25px;
}

.add-btn:hover,
.update-btn:hover {
    background:#fff;
    color:#000;
}

.cancel-btn {
    display:inline-flex;
    height:44px;
    min-width:80px;
    align-items:center;
    justify-content:center;
    background:#333;
    color:#fff;
    text-decoration:none;
    border-radius:5px;
    margin-left:5px;
}


/* TABLE */

.table-box {
    background:#111;
    border:1px solid #333;
    border-radius:8px;
    overflow-x:auto;
}

.table-header {
    padding:20px;
    border-bottom:1px solid #333;
    display:flex;
    justify-content:space-between;
}

.count {
    color:#E88F2A;
    font-size:13px;
}

table {
    width:100%;
    border-collapse:collapse;
    min-width:1200px;
}

th {
    background:#151515;
    color:#E88F2A;
    padding:15px;
    text-align:left;
    font-size:12px;
}

td {
    padding:15px;
    border-top:1px solid #222;
    color:#bbb;
    font-size:13px;
    vertical-align:middle;
}

tr:hover {
    background:#161616;
}


/* IMAGES */

.image-list {
    display:flex;
    gap:7px;
    flex-wrap:wrap;
}

.category-image {
    width:70px;
    height:70px;
    object-fit:cover;
    border-radius:8px;
    border:1px solid #444;
}

.category-image:hover {
    border-color:#E88F2A;
}


/* STATUS */

.status-active,
.status-inactive {
    display:inline-block;
    padding:6px 11px;
    border-radius:20px;
    font-size:11px;
    font-weight:bold;
}

.status-active {
    background:rgba(85,204,119,.1);
    color:#55cc77;
}

.status-inactive {
    background:rgba(220,53,69,.1);
    color:#ff6666;
}


/* ACTION */

.action-buttons {
    display:flex;
    gap:8px;
}

.edit-btn,
.delete-btn {
    display:inline-flex;
    align-items:center;
    justify-content:center;
    width:80px;
    height:38px;
    border-radius:5px;
    text-decoration:none;
    font-size:12px;
    font-weight:bold;
}

.edit-btn {
    background:#E88F2A;
    color:#fff;
}

.delete-btn {
    background:#8b0000;
    color:#fff;
}


/* FOOTER */

.footer {
    text-align:center;
    padding:20px;
    color:#555;
    border-top:1px solid #222;
    margin-top:40px;
}

.footer span {
    color:#E88F2A;
}


/* RESPONSIVE */

@media(max-width:1200px) {

    .form-row {
        grid-template-columns:1fr 1fr;
    }

}

@media(max-width:800px) {

    .sidebar {
        width:70px;
    }

    .logo {
        font-size:0;
    }

    .logo::after {
        content:"S";
        font-size:28px;
        color:#E88F2A;
    }

    .admin-box h4,
    .admin-box p,
    .menu-title,
    .sidebar a span:not(.icon) {
        display:none;
    }

    .sidebar a {
        justify-content:center;
        padding:13px 5px;
    }

    .main {
        margin-left:70px;
    }

}

@media(max-width:550px) {

    .form-row {
        grid-template-columns:1fr;
    }

    .add-btn {
        width:100%;
    }

}

</style>

</head>


<body>


<!-- SIDEBAR -->

<div class="sidebar">

<div class="logo">
SWIFFIN
</div>

<div class="admin-box">

<div class="admin-icon">
👤
</div>

<h4>
<?php

echo htmlspecialchars(
    $_SESSION['admin_name']
    ?? $_SESSION['admin']
    ?? 'Admin'
);

?>
</h4>

<p>Administrator</p>

</div>


<div class="menu-title">
Main Menu
</div>

<a href="admin_dashboard.php">
<span class="icon">🏠</span>
<span>Dashboard</span>
</a>


<div class="menu-title">
Cake Management
</div>

<a href="add_cake.php">
<span class="icon">🍰</span>
<span>Add Cake</span>
</a>

<a href="view_cake.php">
<span class="icon">👁️</span>
<span>View Cakes</span>
</a>

<a href="edit_cake.php">
<span class="icon">📝</span>
<span>Edit Cake</span>
</a>

<a href="delete_cake.php">
<span class="icon">🗑️</span>
<span>Delete Cake</span>
</a>

<a
href="category.php"
class="active"
>
<span class="icon">📂</span>
<span>Categories</span>
</a>


<div class="menu-title">
Sales Management
</div>

<a href="order.php">
<span class="icon">📦</span>
<span>Orders</span>
</a>

<a href="customer.php">
<span class="icon">👥</span>
<span>Customers</span>
</a>

<a href="carts.php">
<span class="icon">🛒</span>
<span>Carts</span>
</a>

<a href="payment.php">
<span class="icon">💳</span>
<span>Payments</span>
</a>


<div class="menu-title">
Other Management
</div>

<a href="stock.php">
<span class="icon">📊</span>
<span>Stock</span>
</a>

<a href="delivery.php">
<span class="icon">🚚</span>
<span>Delivery</span>
</a>

<a href="feedback.php">
<span class="icon">⭐</span>
<span>Feedback</span>
</a>

<a href="reports.php">
<span class="icon">📈</span>
<span>Reports</span>
</a>

<a href="offers.php">
<span class="icon">🎁</span>
<span>Offers</span>
</a>

<a href="staff.php">
<span class="icon">👨‍💼</span>
<span>Staff</span>
</a>

<a href="enquiry.php">
<span class="icon">📩</span>
<span>Enquiries</span>
</a>

<a href="settings.php">
<span class="icon">⚙️</span>
<span>Settings</span>
</a>

<a href="logout.php">
<span class="icon">🚪</span>
<span>Logout</span>
</a>

</div>


<!-- MAIN -->

<div class="main">


<div class="topbar">

<div>

<h2>
Category Management
</h2>

<p>
Manage Swiffin Cake Shop Categories
</p>

</div>


<div>

<span class="admin-name">

Welcome,

<span>

<?php

echo htmlspecialchars(
    $_SESSION['admin_name']
    ?? $_SESSION['admin']
    ?? 'Admin'
);

?>

</span>

</span>


<a
href="logout.php"
class="logout"
>
Logout
</a>

</div>

</div>


<div class="content">


<div class="page-title">

<h1>
📂 Category Management
</h1>

<p>
Add, view, edit and delete cake categories.
</p>

</div>


<!-- MESSAGE -->

<?php if ($message != "") { ?>

<div
class="message
<?php echo $message_type; ?>"
>

<?php

echo htmlspecialchars(
    $message
);

?>

</div>

<?php } ?>


<!-- FORM -->

<div class="form-box">


<?php if ($edit_data) { ?>


<h2>
✏️ Edit Category
</h2>


<form
method="POST"
enctype="multipart/form-data"
>


<input
type="hidden"
name="id"
value="<?php
echo $edit_data['id'];
?>"
>


<div class="form-row">


<div class="form-group">

<label>
Category Name
</label>

<input
type="text"
name="category_name"
value="<?php

echo htmlspecialchars(
    $edit_data['category_name']
);

?>"
required
>

</div>


<div class="form-group">

<label>
Description
</label>

<input
type="text"
name="description"
value="<?php

echo htmlspecialchars(
    $edit_data['description']
    ?? ''
);

?>"
>

</div>


<div class="form-group">

<label>
Parent Category
</label>

<select name="parent_id">

<option value="0">
Main Category
</option>

<?php

while (
    $parent =
    mysqli_fetch_assoc(
        $parent_result
    )
) {

if (
    intval($parent['id'])
    ==
    intval($edit_data['id'])
) {
    continue;
}

?>

<option
value="<?php
echo $parent['id'];
?>"

<?php

if (
    intval(
        $edit_data['parent_id']
        ?? 0
    )
    ==
    intval($parent['id'])
) {
    echo "selected";
}

?>
>

<?php

echo htmlspecialchars(
    $parent['category_name']
);

?>

</option>

<?php } ?>

</select>

</div>


<div class="form-group">

<label>
Status
</label>

<select name="status">

<option
value="Active"
<?php

echo (
    ($edit_data['status'] ?? '')
    == 'Active'
)
? 'selected'
: '';

?>
>
Active
</option>

<option
value="Inactive"
<?php

echo (
    ($edit_data['status'] ?? '')
    == 'Inactive'
)
? 'selected'
: '';

?>
>
Inactive
</option>

</select>

</div>

</div>


<div style="margin-top:20px;">

<div class="form-group">

<label>
Add Multiple Images
</label>

<input
type="file"
name="images[]"
multiple
accept=".jpg,.jpeg,.png,.webp"
>

</div>


<br>


<button
type="submit"
name="update_category"
class="update-btn"
>
Update
</button>


<a
href="category.php"
class="cancel-btn"
>
Cancel
</a>

</div>

</form>


<?php } else { ?>


<h2>
➕ Add New Category
</h2>


<form
method="POST"
enctype="multipart/form-data"
>


<div class="form-row">


<div class="form-group">

<label>
Category Name
</label>

<input
type="text"
name="category_name"
placeholder="Example: Birthday Cakes"
required
>

</div>


<div class="form-group">

<label>
Description
</label>

<input
type="text"
name="description"
placeholder="Enter description"
>

</div>


<div class="form-group">

<label>
Parent Category
</label>

<select name="parent_id">

<option value="0">
Main Category
</option>

<?php

while (
    $parent =
    mysqli_fetch_assoc(
        $parent_result
    )
) {

?>

<option
value="<?php
echo $parent['id'];
?>"
>

<?php

echo htmlspecialchars(
    $parent['category_name']
);

?>

</option>

<?php } ?>

</select>

</div>


<div class="form-group">

<label>
Status
</label>

<select name="status">

<option value="Active">
Active
</option>

<option value="Inactive">
Inactive
</option>

</select>

</div>

</div>


<div style="margin-top:20px;">

<div class="form-group">

<label>
Category Images
</label>

<input
type="file"
name="images[]"
multiple
accept=".jpg,.jpeg,.png,.webp"
>

</div>


<br>


<button
type="submit"
name="add_category"
class="add-btn"
>
+ Add Category
</button>

</div>

</form>


<?php } ?>


</div>


<!-- ALL CATEGORIES -->

<div class="table-box">


<div class="table-header">

<h2>
👁️ All Categories
</h2>

<div class="count">

<?php

echo mysqli_num_rows(
    $result
);

?>

Categories

</div>

</div>


<table>

<thead>

<tr>

<th>ID</th>

<th>Category Name</th>

<th>Parent Category</th>

<th>Description</th>

<th>Images</th>

<th>Status</th>

<th>Created Date</th>

<th>Action</th>

</tr>

</thead>


<tbody>


<?php

if (
    mysqli_num_rows($result)
    > 0
) {

while (
    $row =
    mysqli_fetch_assoc(
        $result
    )
) {

?>


<tr>


<td>

<?php
echo $row['id'];
?>

</td>


<td>

<?php

echo htmlspecialchars(
    $row['category_name']
);

?>

</td>


<td>

<?php

if (
    intval(
        $row['parent_id']
    ) == 0
) {

?>

<span
style="
color:#E88F2A;
font-weight:bold;
"
>
Main Category
</span>

<?php

} else {

echo htmlspecialchars(
    $row['parent_name']
    ?? 'Unknown'
);

}

?>

</td>


<td>

<?php

echo htmlspecialchars(
    $row['description']
    ?? ''
);

?>

</td>


<td>

<div class="image-list">


<?php

/* =================================================
   OLD category.image
================================================= */

$shown_images = [];


if (
    !empty(
        $row['image']
    )
) {

    $old_image =
        $row['image'];

    $shown_images[] =
        $old_image;

?>

<img
src="img/category/<?php
echo htmlspecialchars(
    $old_image
);
?>"
class="category-image"
alt="Category"
onerror="this.style.display='none';"
>

<?php

}


/* =================================================
   MULTIPLE category_images
================================================= */

$img_query =
    mysqli_query(
        $conn,
        "SELECT image
         FROM category_images
         WHERE category_id = "
         . intval($row['id']) .
         "
         ORDER BY id ASC"
    );


if ($img_query) {

while (
    $img =
    mysqli_fetch_assoc(
        $img_query
    )
) {

    if (
        in_array(
            $img['image'],
            $shown_images
        )
    ) {
        continue;
    }

    $shown_images[] =
        $img['image'];

?>

<img
src="img/category/<?php
echo htmlspecialchars(
    $img['image']
);
?>"
class="category-image"
alt="Category"
onerror="this.style.display='none';"
>

<?php

}

}


if (
    count($shown_images)
    == 0
) {

?>

<span
style="color:#666;"
>
No Image
</span>

<?php

}

?>

</div>

</td>


<td>

<?php

if (
    ($row['status'] ?? '')
    == 'Active'
) {

?>

<span class="status-active">
Active
</span>

<?php

} else {

?>

<span class="status-inactive">
Inactive
</span>

<?php

}

?>

</td>


<td>

<?php

if (
    !empty(
        $row['created_at']
    )
) {

echo date(
    "d-m-Y",
    strtotime(
        $row['created_at']
    )
);

} else {

echo "-";

}

?>

</td>


<td>

<div class="action-buttons">


<a
href="category.php?edit=<?php
echo $row['id'];
?>"
class="edit-btn"
>
✏️ Edit
</a>


<a
href="category.php?delete=<?php
echo $row['id'];
?>"
class="delete-btn"

onclick="
return confirm(
'Are you sure you want to delete this category?'
);
"
>
🗑️ Delete
</a>


</div>

</td>


</tr>


<?php

}

} else {

?>


<tr>

<td
colspan="8"
style="
text-align:center;
padding:40px;
color:#777;
"
>

No Categories Found

</td>

</tr>


<?php

}

?>


</tbody>

</table>

</div>


</div>


<div class="footer">

© 2026

<span>
SWIFFIN Cake Shop
</span>

| Category Management

</div>


</div>


</body>

</html>

<?php

mysqli_close($conn);

?>