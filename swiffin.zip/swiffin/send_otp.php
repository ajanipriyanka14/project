<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';


if(isset($_POST['email']))
{
    $email = $_POST['email'];

    // Generate OTP
    $otp = rand(100000,999999);

    // Store OTP in session
    $_SESSION['otp'] = $otp;
    $_SESSION['email'] = $email;


    $mail = new PHPMailer(true);

    try
    {
        // SMTP Settings
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;

        // Gmail Account
        $mail->Username = "swiffincake10@gmail.com";
        $mail->Password = "kbcjydfyxvwhsxxg"; 
        // yaha Google ka 16 digit App Password lagana hai

        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;


        // SSL Certificate Fix
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );


        // Sender
        $mail->setFrom(
            "swiffincake10@gmail.com",
            "Swiffin Cake Shop"
        );


        // Receiver
        $mail->addAddress($email);


        // Email Design
        $mail->isHTML(true);
        $mail->Subject = "Swiffin Cake Shop OTP Verification";


        $mail->Body = "
        <h2>Swiffin Cake Shop</h2>
        <p>Your OTP Verification Code is:</p>
        <h1>$otp</h1>
        <p>Please do not share this OTP.</p>
        ";


        $mail->send();

        echo "OTP Sent Successfully";

    }
    catch(Exception $e)
    {
        echo "OTP Failed: " . $mail->ErrorInfo;
    }

}
?>