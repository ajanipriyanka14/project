<?php
session_start();
include "config.php";

/* =========================================================
   SESSION
========================================================= */

$welcome_name = "Welcome";

if (isset($_SESSION['name']) && trim($_SESSION['name']) != "") {
    $welcome_name = "Welcome " . htmlspecialchars($_SESSION['name']);
}


/* =========================================================
   GET ALL CATEGORIES
========================================================= */

$categories = [];

$category_query = mysqli_query(
    $conn,
    "SELECT * FROM category ORDER BY id ASC"
);

if ($category_query) {

    while ($row = mysqli_fetch_assoc($category_query)) {
        $categories[] = $row;
    }
}


/* =========================================================
   CATEGORY NAME
========================================================= */

function categoryName($cat)
{
    if (
        isset($cat['category_name']) &&
        trim($cat['category_name']) != ''
    ) {
        return trim($cat['category_name']);
    }

    if (
        isset($cat['name']) &&
        trim($cat['name']) != ''
    ) {
        return trim($cat['name']);
    }

    if (
        isset($cat['category']) &&
        trim($cat['category']) != ''
    ) {
        return trim($cat['category']);
    }

    return "";
}


/* =========================================================
   IMAGE PATH
========================================================= */

function getImagePath($image)
{
    $image = trim($image);

    if ($image == "") {
        return "img/no-image.jpg";
    }

    $image = str_replace("\\", "/", $image);


    /* FULL URL */

    if (
        strpos($image, "http://") === 0 ||
        strpos($image, "https://") === 0
    ) {
        return $image;
    }


    /* REMOVE EXISTING FOLDER */

    $image = preg_replace(
        '#^(img/|uploads/|images/)#i',
        '',
        $image
    );


    /* IMG */

    if (
        file_exists(
            __DIR__ . "/img/" . $image
        )
    ) {
        return "img/" . $image;
    }


    /* UPLOADS */

    if (
        file_exists(
            __DIR__ . "/uploads/" . $image
        )
    ) {
        return "uploads/" . $image;
    }


    /* IMAGES */

    if (
        file_exists(
            __DIR__ . "/images/" . $image
        )
    ) {
        return "images/" . $image;
    }


    return "img/no-image.jpg";
}


/* =========================================================
   CATEGORY IMAGE
   DIRECTLY FROM category TABLE
========================================================= */

function getCategoryImage($category)
{
    $image = "";

    if (
        isset($category['image']) &&
        trim($category['image']) != ""
    ) {
        $image = trim($category['image']);
    }

    return getImagePath($image);
}


/* =========================================================
   SELECTED CATEGORY
========================================================= */

$selected_category = "";

if (
    isset($_GET['category']) &&
    trim($_GET['category']) != ""
) {
    $selected_category = trim($_GET['category']);
}


/* =========================================================
   FIND SELECTED CATEGORY
========================================================= */

$selected_category_id = 0;
$selected_category_row = null;

if ($selected_category != "") {

    foreach ($categories as $cat) {

        $cat_name = categoryName($cat);

        if (
            strcasecmp(
                trim($cat_name),
                trim($selected_category)
            ) == 0
        ) {

            $selected_category_row = $cat;

            $selected_category_id =
                isset($cat['id'])
                ? (int)$cat['id']
                : 0;

            break;
        }
    }
}


/* =========================================================
   PARENT CATEGORIES
========================================================= */

$parent_categories = [];

foreach ($categories as $cat) {

    $parent_id =
        isset($cat['parent_id'])
        ? (int)$cat['parent_id']
        : 0;

    if ($parent_id == 0) {
        $parent_categories[] = $cat;
    }
}


/* =========================================================
   GET SELECTED CATEGORY CAKES
   FROM cake TABLE
========================================================= */

$cakes = [];

if ($selected_category_id > 0) {

    $category_ids = [
        $selected_category_id
    ];


    /* CHILD CATEGORIES */

    foreach ($categories as $cat) {

        $cat_id =
            isset($cat['id'])
            ? (int)$cat['id']
            : 0;

        $parent_id =
            isset($cat['parent_id'])
            ? (int)$cat['parent_id']
            : 0;


        if (
            $cat_id > 0 &&
            $parent_id == $selected_category_id
        ) {

            $category_ids[] = $cat_id;
        }
    }


    $category_ids =
        array_unique($category_ids);


    $ids =
        implode(
            ",",
            array_map(
                'intval',
                $category_ids
            )
        );


    if ($ids != "") {

        $cake_query = mysqli_query(
            $conn,
            "SELECT *
             FROM cake
             WHERE category IN ($ids)
             ORDER BY id DESC"
        );


        if ($cake_query) {

            while (
                $row =
                mysqli_fetch_assoc($cake_query)
            ) {

                $cakes[] = $row;
            }
        }
    }
}

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>

<?php

if ($selected_category != "") {

    echo htmlspecialchars(
        $selected_category
    ) . " Cakes";

} else {

    echo "Cake Categories";
}

?>

| Swiffin Cake Shop

</title>


<!-- GOOGLE FONT -->

<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Oswald:wght@500;600;700&display=swap"
rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
rel="stylesheet"
>


<!-- BOOTSTRAP ICON -->

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
rel="stylesheet"
>


<!-- BOOTSTRAP -->

<link
href="css/bootstrap.min.css"
rel="stylesheet"
>


<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 0;
    background: #000;
    font-family: 'Open Sans', sans-serif;
}


/* =========================================================
   HEADER
========================================================= */

.top-header {
    background: #fff;
}

.top-header .row {
    min-height: 90px;
}

.welcome-text {
    color: #222;
    font-size: 16px;
    font-weight: 700;
    margin: 0;
}


/* =========================================================
   LOGO
========================================================= */

.logo-area {
    text-decoration: none !important;
    display: flex;
    align-items: center;
    justify-content: center;
}

.logo-area img {
    width: 60px;
    height: 60px;
    object-fit: contain;
}

.logo-text {
    margin: 0 0 0 10px;
    color: #ff9800;
    font-family: 'Oswald', sans-serif;
    font-size: 38px;
    font-weight: 700;
    letter-spacing: 1px;
}


/* =========================================================
   CALL US
========================================================= */

.call-box {
    display: inline-flex;
    align-items: center;
    justify-content: flex-end;
}

.call-box i {
    font-size: 38px;
    color: #E88F2A;
    margin-right: 15px;
}

.call-title {
    font-size: 13px;
    font-weight: 700;
    color: #222;
    margin-bottom: 3px;
}

.call-number {
    font-size: 14px;
    color: #555;
}


/* =========================================================
   NAVBAR
========================================================= */

.navbar {
    background: #fff !important;
    border: none !important;
    box-shadow: 0 2px 10px rgba(0,0,0,.12);
    z-index: 9999;
}

.navbar .nav-link {
    color: #222 !important;
    font-size: 15px;
    font-weight: 600;
    padding: 10px 15px !important;
}

.navbar .nav-link:hover,
.navbar .nav-link.active {
    color: #E88F2A !important;
}


/* =========================================================
   BUTTON
========================================================= */

.btn-primary {
    background: #E88F2A !important;
    border-color: #E88F2A !important;
    color: #fff !important;
}

.btn-primary:hover {
    background: #d67d18 !important;
    border-color: #d67d18 !important;
}


/* =========================================================
   CATEGORY DROPDOWN
========================================================= */

.category-dropdown {
    position: relative;
}

.category-dropdown-menu {
    position: absolute;
    top: 100%;
    left: 0;
    width: 270px;
    background: #fff;
    border-top: 3px solid #E88F2A;
    box-shadow: 0 8px 25px rgba(0,0,0,.25);
    padding: 7px 0;
    display: none;
    z-index: 99999;
}

.category-dropdown:hover .category-dropdown-menu {
    display: block;
}


/* =========================================================
   PARENT
========================================================= */

.category-parent-item {
    position: relative;
}

.category-parent-link {
    width: 100%;
    padding: 12px 18px;
    color: #222 !important;
    background: #fff;
    text-decoration: none !important;
    font-size: 14px;
    font-weight: 600;

    display: flex;
    align-items: center;
    justify-content: space-between;
}

.category-parent-link:hover {
    color: #E88F2A !important;
    background: #FAF3EB;
}


/* =========================================================
   CHILD
========================================================= */

.category-child-menu {
    position: absolute;
    top: 0;
    left: 100%;
    width: 270px;
    background: #fff;
    border-top: 3px solid #E88F2A;
    box-shadow: 0 8px 25px rgba(0,0,0,.25);
    padding: 7px 0;
    display: none;
    z-index: 100000;
}

.category-parent-item:hover .category-child-menu {
    display: block;
}

.category-child-menu a {
    display: block;
    padding: 11px 18px;
    color: #222 !important;
    background: #fff;
    text-decoration: none !important;
    font-size: 14px;
    font-weight: 600;
}

.category-child-menu a:hover {
    color: #E88F2A !important;
    background: #FAF3EB;
}


/* =========================================================
   PAGE HEADER
========================================================= */

.category-header {
    background: #000;
    text-align: center;
    padding: 55px 20px 40px;
    border-bottom: 1px solid #222;
}

.category-header h1 {
    color: #fff !important;
    font-family: 'Oswald', sans-serif;
    font-size: 42px;
    font-weight: 700;
    margin: 0 0 10px;
}

.category-header h1 span {
    color: #E88F2A !important;
}

.category-header p {
    color: #aaa !important;
    font-size: 15px;
    margin: 0;
}


/* =========================================================
   CATEGORY SECTION
========================================================= */

.category-section {
    background: #000;
    padding: 45px 30px 50px;
}

.section-title {
    text-align: center;
    margin-bottom: 35px;
}

.section-title h2 {
    color: #fff !important;
    font-family: 'Oswald', sans-serif;
    font-size: 30px;
    font-weight: 600;
    margin: 0;
}

.section-title span {
    color: #E88F2A !important;
}


/* =========================================================
   CATEGORY GRID
========================================================= */

.category-grid {
    max-width: 1200px;
    margin: auto;

    display: grid;

    grid-template-columns:
        repeat(auto-fit, minmax(180px, 1fr));

    gap: 20px;
}


/* =========================================================
   CATEGORY CARD
========================================================= */

.category-card {
    background: #fff;
    border: 1px solid #fff;
    border-radius: 10px;
    padding: 15px;

    text-align: center;

    text-decoration: none !important;
    color: #000 !important;

    transition: .3s;

    overflow: hidden;
}

.category-card:hover {
    background: #E88F2A;
    transform: translateY(-6px);

    box-shadow:
        0 10px 25px rgba(232,143,42,.30);
}


/* =========================================================
   CATEGORY IMAGE
========================================================= */

.category-image {
    width: 100%;
    height: 150px;

    object-fit: cover;

    display: block;

    border-radius: 8px;

    margin-bottom: 12px;

    transition: .3s;
}

.category-card:hover .category-image {
    transform: scale(1.03);
}


/* =========================================================
   CATEGORY TEXT
========================================================= */

.category-card h3 {
    color: #000 !important;

    font-family: 'Oswald', sans-serif;

    font-size: 19px;
    font-weight: 600;

    margin: 0 0 5px;
}

.category-card:hover h3 {
    color: #fff !important;
}

.category-card p {
    color: #555 !important;

    margin: 0;

    font-size: 13px;
}

.category-card:hover p {
    color: #fff !important;
}


/* =========================================================
   CAKE SECTION
========================================================= */

.cake-section {
    background: #000;
    padding: 20px 30px 70px;
}

.cake-title {
    max-width: 1200px;

    margin: 0 auto 30px;

    border-bottom: 1px solid #333;

    padding-bottom: 15px;
}

.cake-title h2 {
    color: #fff !important;

    font-family: 'Oswald', sans-serif;

    font-size: 30px;

    margin: 0;
}

.cake-title span {
    color: #E88F2A !important;
}


/* =========================================================
   CAKE GRID
========================================================= */

.cake-grid {
    max-width: 1200px;

    margin: auto;

    display: grid;

    grid-template-columns:
        repeat(auto-fit, minmax(500px, 1fr));

    gap: 25px;
}


/* =========================================================
   CAKE CARD
========================================================= */

.cake-card {
    background: #111;

    border: 1px solid #333;

    border-radius: 12px;

    overflow: hidden;

    display: flex;

    align-items: stretch;

    min-height: 240px;

    transition: .3s;
}

.cake-card:hover {
    transform: translateY(-4px);

    border-color: #E88F2A;

    box-shadow:
        0 10px 25px rgba(232,143,42,.15);
}


/* =========================================================
   CAKE IMAGE
========================================================= */

.cake-image {
    width: 220px;
    min-width: 220px;

    height: 220px;

    object-fit: cover;

    display: block;

    border-radius: 20px;

    margin: 10px 20px;
}


/* =========================================================
   CAKE INFO
========================================================= */

.cake-info {
    flex: 1;

    padding: 22px 25px;

    text-align: left;
}

.cake-info h3 {
    color: #fff !important;

    font-family: 'Oswald', sans-serif;

    font-size: 24px;

    margin: 0 0 12px;
}

.cake-description {
    color: #aaa;

    font-size: 15px;

    margin-bottom: 10px;
}

.free-delivery {
    color: #65c466;

    font-size: 14px;

    font-weight: 600;

    margin-bottom: 8px;
}

.cake-price {
    color: #E88F2A !important;

    font-size: 23px;

    font-weight: 700;

    margin: 12px 0;
}


/* =========================================================
   BUTTONS
========================================================= */

.cake-buttons {
    display: flex;

    gap: 10px;

    max-width: 300px;

    margin-top: 15px;
}

.cake-buttons a {
    flex: 1;

    text-align: center;

    padding: 10px 8px;

    border-radius: 10px !important;

    text-decoration: none !important;

    font-weight: 600;

    font-size: 13px;
}

.btn-cart {
    background: transparent !important;

    color: #E88F2A !important;

    border: 1px solid #E88F2A !important;
}

.btn-buy {
    background: #E88F2A !important;

    color: #fff !important;

    border: 1px solid #E88F2A !important;
}

.btn-cart:hover,
.btn-buy:hover {
    background: #d67d18 !important;

    color: #fff !important;
}


/* =========================================================
   NO CAKES
========================================================= */

.no-cakes {
    max-width: 700px;

    margin: 30px auto;

    padding: 50px;

    text-align: center;

    color: #777;

    background: #111;

    border: 1px solid #333;

    border-radius: 10px;
}

.no-cakes h3 {
    color: #fff;

    font-family: 'Oswald', sans-serif;
}

.no-cakes p {
    color: #777;

    margin: 0;
}


/* =========================================================
   FOOTER
========================================================= */

.footer {
    background: #111;

    border-top: 1px solid #333;

    text-align: center;

    padding: 25px;

    color: #777;

    font-size: 14px;
}

.footer span {
    color: #E88F2A;
}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width: 991px) {

    .top-header {
        padding: 10px 0;
    }

    .welcome-area {
        text-align: center;
        margin-bottom: 10px;
    }

    .logo-area {
        margin-bottom: 10px;
    }

    .call-area {
        text-align: center !important;
    }

    .call-box {
        justify-content: center;
    }

    .category-dropdown-menu {
        position: static;

        width: 100%;

        box-shadow: none;

        border-top: none;
    }

    .category-child-menu {
        position: static;

        width: 100%;

        box-shadow: none;

        border-top: none;

        padding-left: 15px;
    }

    .category-dropdown:hover .category-dropdown-menu {
        display: block;
    }

    .category-parent-item:hover .category-child-menu {
        display: block;
    }

    .cake-grid {
        grid-template-columns: 1fr;
    }
}


@media(max-width: 576px) {

    .category-section,
    .cake-section {
        padding-left: 15px;

        padding-right: 15px;
    }

    .category-header h1 {
        font-size: 34px;
    }

    .logo-text {
        font-size: 30px;
    }

    .cake-card {
        display: block;
    }

    .cake-image {
        width: calc(100% - 20px);

        min-width: 0;

        height: 250px;

        margin: 10px;
    }

    .cake-buttons {
        flex-direction: column;

        max-width: 100%;
    }
}

</style>

</head>


<body>


<!-- =========================================================
     TOP HEADER
========================================================= -->

<div class="container-fluid top-header">

    <div class="row align-items-center px-4">


        <!-- WELCOME -->

        <div class="col-lg-2 welcome-area">

            <h5 class="welcome-text">

                <?php
                echo $welcome_name;
                ?>

            </h5>

        </div>


        <!-- LOGO -->

        <div class="col-lg-5 text-center py-2">

            <a
                href="index1.php"
                class="logo-area"
            >

                <img
                    src="img/logo.png"
                    alt="Swiffin Logo"
                >

                <h1 class="logo-text">
                    SWIFFIN
                </h1>

            </a>

        </div>


        <!-- CALL US -->

        <div class="col-lg-4 text-end call-area">

            <div class="call-box">

                <i class="bi bi-phone-vibrate"></i>

                <div class="text-start">

                    <div class="call-title">
                        CALL US
                    </div>

                    <div class="call-number">
                        +91 9876543210
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =========================================================
     NAVBAR
========================================================= -->

<nav
    class="navbar navbar-expand-lg navbar-light sticky-top py-3"
>

    <div class="container">


        <!-- MOBILE -->

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbar"
            aria-controls="navbar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >

            <span class="navbar-toggler-icon"></span>

        </button>


        <div
            class="collapse navbar-collapse"
            id="navbar"
        >

            <ul class="navbar-nav ms-auto">


                <!-- HOME -->

                <li class="nav-item">

                    <a
                        href="index1.php"
                        class="nav-link"
                    >
                        Home
                    </a>

                </li>


                <!-- ABOUT -->

                <li class="nav-item">

                    <a
                        href="about.php"
                        class="nav-link"
                    >
                        About
                    </a>

                </li>


                <!-- CATEGORIES -->

                <li class="nav-item category-dropdown">

                    <a
                        href="cake_categories.php"
                        class="nav-link active"
                    >

                        Categories
                        <span style="font-size:12px;">
                            ⌄
                        </span>

                    </a>


                    <!-- DROPDOWN -->

                    <div class="category-dropdown-menu">

                        <?php

                        foreach (
                            $parent_categories
                            as $parent
                        ) {

                            $parent_name =
                                categoryName($parent);

                            if ($parent_name == "") {
                                continue;
                            }


                            $parent_id =
                                isset($parent['id'])
                                ? (int)$parent['id']
                                : 0;


                            $children = [];


                            foreach (
                                $categories
                                as $child
                            ) {

                                $child_parent_id =
                                    isset($child['parent_id'])
                                    ? (int)$child['parent_id']
                                    : 0;


                                if (
                                    $child_parent_id ==
                                    $parent_id
                                ) {

                                    $children[] =
                                        $child;
                                }
                            }

                        ?>

                            <div class="category-parent-item">

                                <a
                                    href="cake_categories.php?category=<?php
                                    echo urlencode(
                                        $parent_name
                                    );
                                    ?>"
                                    class="category-parent-link"
                                >

                                    <span>

                                        <?php
                                        echo htmlspecialchars(
                                            $parent_name
                                        );
                                        ?>

                                    </span>


                                    <?php

                                    if (
                                        count($children) > 0
                                    ) {

                                    ?>

                                        <span>›</span>

                                    <?php } ?>

                                </a>


                                <?php

                                if (
                                    count($children) > 0
                                ) {

                                ?>

                                    <div
                                        class="category-child-menu"
                                    >

                                        <?php

                                        foreach (
                                            $children
                                            as $child
                                        ) {

                                            $child_name =
                                                categoryName(
                                                    $child
                                                );

                                            if (
                                                $child_name == ""
                                            ) {
                                                continue;
                                            }

                                        ?>

                                            <a
                                                href="cake_categories.php?category=<?php
                                                echo urlencode(
                                                    $child_name
                                                );
                                                ?>"
                                            >

                                                <?php
                                                echo htmlspecialchars(
                                                    $child_name
                                                );
                                                ?>

                                            </a>

                                        <?php } ?>

                                    </div>

                                <?php } ?>

                            </div>

                        <?php } ?>

                    </div>

                </li>


                <!-- CAKES -->

                <li class="nav-item">

                    <a
                        href="product.php"
                        class="nav-link"
                    >
                        Cakes
                    </a>

                </li>


                <!-- CONTACT -->

                <li class="nav-item">

                    <a
                        href="contact.php"
                        class="nav-link"
                    >
                        Contact
                    </a>

                </li>


                <!-- LOGIN -->

                <li class="nav-item">

                    <a
                        href="login.php"
                        class="btn btn-primary rounded-pill ms-3 px-4 fw-bold"
                    >
                        Login
                    </a>

                </li>


                <!-- REGISTER -->

                <li class="nav-item">

                    <a
                        href="register.php"
                        class="btn btn-primary rounded-pill ms-3 px-4 fw-bold"
                    >
                        Register
                    </a>

                </li>


                <!-- LOGOUT -->

                <li class="nav-item">

                    <a
                        href="logout.php"
                        class="btn btn-primary rounded-pill ms-3 px-4 fw-bold"
                    >
                        Logout
                    </a>

                </li>

            </ul>

        </div>

    </div>

</nav>


<!-- =========================================================
     PAGE HEADER
========================================================= -->

<section class="category-header">

    <?php if ($selected_category != "") { ?>

        <h1>

            <?php
            echo htmlspecialchars(
                $selected_category
            );
            ?>

            <span>
                Cakes
            </span>

        </h1>

        <p>

            Explore our delicious

            <?php
            echo htmlspecialchars(
                $selected_category
            );
            ?>

            collection

        </p>

    <?php } else { ?>

        <h1>

            Cake

            <span>
                Categories
            </span>

        </h1>

        <p>
            Explore our delicious collection of cakes
        </p>

    <?php } ?>

</section>


<!-- =========================================================
     CATEGORY CARDS
========================================================= -->

<section class="category-section">

    <div class="section-title">

        <h2>

            Choose Your

            <span>
                Favourite
            </span>

            Category

        </h2>

    </div>


    <div class="category-grid">


        <?php

        foreach (
            $categories
            as $cat
        ) {

            $cat_name =
                categoryName($cat);

            if ($cat_name == "") {
                continue;
            }


            /*
             * IMPORTANT:
             * Image directly category table
             */

            $cat_image_path =
                getCategoryImage($cat);

        ?>


            <a
                href="cake_categories.php?category=<?php
                echo urlencode(
                    $cat_name
                );
                ?>"
                class="category-card"
            >


                <img
                    src="<?php
                    echo htmlspecialchars(
                        $cat_image_path
                    );
                    ?>"
                    alt="<?php
                    echo htmlspecialchars(
                        $cat_name
                    );
                    ?>"
                    class="category-image"
                    onerror="this.src='img/no-image.jpg';"
                >


                <h3>

                    <?php
                    echo htmlspecialchars(
                        $cat_name
                    );
                    ?>

                </h3>


                <p>
                    View Cakes
                </p>


            </a>


        <?php } ?>


    </div>

</section>


<!-- =========================================================
     SELECTED CATEGORY CAKES
========================================================= -->

<?php

if (
    $selected_category != ""
) {

?>

<section class="cake-section">


    <div class="cake-title">

        <h2>

            <?php
            echo htmlspecialchars(
                $selected_category
            );
            ?>

            <span>
                Cakes
            </span>

        </h2>

    </div>


    <?php

    if (
        count($cakes) > 0
    ) {

    ?>

        <div class="cake-grid">


            <?php

            foreach (
                $cakes
                as $cake
            ) {


                /* CAKE ID */

                $cake_id =
                    isset($cake['id'])
                    ? (int)$cake['id']
                    : 0;


                /* CAKE NAME */

                $cake_name = "Cake";

                if (
                    isset($cake['cake_name']) &&
                    trim($cake['cake_name']) != ""
                ) {

                    $cake_name =
                        trim(
                            $cake['cake_name']
                        );
                }


                /* PRICE */

                $price = 0;

                if (
                    isset($cake['price']) &&
                    $cake['price'] !== ""
                ) {

                    $price =
                        (float)$cake['price'];
                }


                /* CAKE IMAGE */

                $image = "";

                if (
                    isset($cake['image']) &&
                    trim($cake['image']) != ""
                ) {

                    $image =
                        trim($cake['image']);
                }


                $image_path =
                    getImagePath($image);

            ?>


                <div class="cake-card">


                    <!-- CAKE IMAGE -->

                    <img
                        src="<?php
                        echo htmlspecialchars(
                            $image_path
                        );
                        ?>"
                        class="cake-image"
                        alt="<?php
                        echo htmlspecialchars(
                            $cake_name
                        );
                        ?>"
                        onerror="this.src='img/no-image.jpg';"
                    >


                    <!-- CAKE INFO -->

                    <div class="cake-info">


                        <h3>

                            <?php
                            echo htmlspecialchars(
                                $cake_name
                            );
                            ?>

                        </h3>


                        <div class="cake-description">

                            <b>
                                Category:
                            </b>

                            <?php
                            echo htmlspecialchars(
                                $selected_category
                            );
                            ?>

                        </div>


                        <div class="free-delivery">

                            ✓ Free Delivery

                        </div>


                        <div class="cake-price">

                            ₹<?php

                            echo number_format(
                                $price,
                                2
                            );

                            ?>

                        </div>


                        <div class="cake-buttons">


                            <a
                                href="cart.php?id=<?php
                                echo $cake_id;
                                ?>"
                                class="btn-cart"
                            >

                                <i
                                    class="fa fa-shopping-cart"
                                ></i>

                                Add to Cart

                            </a>


                            <a
                                href="buy_now.php?id=<?php
                                echo $cake_id;
                                ?>"
                                class="btn-buy"
                            >

                                Buy Now

                            </a>


                        </div>


                    </div>

                </div>


            <?php } ?>


        </div>


    <?php } else { ?>


        <div class="no-cakes">

            <h3>
                No Cakes Available
            </h3>

            <p>
                No cakes have been added
                to this category yet.
            </p>

        </div>


    <?php } ?>


</section>

<?php } ?>


<!-- =========================================================
     FOOTER
========================================================= -->

<div class="footer">

    © 2026

    <span>
        SWIFFIN Cake Shop
    </span>

    . All Rights Reserved.

</div>


<script
    src="js/bootstrap.bundle.min.js"
></script>

</body>

</html>

<?php

mysqli_close($conn);

?>