<?php
session_start();
include "config.php";


/* =====================================================
   CUSTOMER SESSION
===================================================== */

$customer_logged_in = false;
$customer_name = "";
$customer_email = "";

if (
    isset($_SESSION['customer']) &&
    $_SESSION['customer'] === true
) {
    $customer_logged_in = true;

    $customer_name = $_SESSION['customer_name'] ?? "";
    $customer_email = $_SESSION['customer_email'] ?? "";
}


/* =====================================================
   CATEGORY DATA
===================================================== */

$parent_categories = [];

$cat_sql = "
    SELECT *
    FROM category
    WHERE parent_id = 0
    AND status = 'Active'
    ORDER BY category_name ASC
";

$cat_result = mysqli_query($conn, $cat_sql);

if ($cat_result) {

    while ($cat = mysqli_fetch_assoc($cat_result)) {

        $parent_categories[] = $cat;

    }

}


/* =====================================================
   SUB CATEGORIES
===================================================== */

function getSubCategoriesGallery($conn, $parent_id)
{

    $sub_categories = [];

    $parent_id = intval($parent_id);

    $sql = "
        SELECT *
        FROM category
        WHERE parent_id = $parent_id
        AND status = 'Active'
        ORDER BY category_name ASC
    ";

    $result = mysqli_query($conn, $sql);

    if ($result) {

        while ($row = mysqli_fetch_assoc($result)) {

            $sub_categories[] = $row;

        }

    }

    return $sub_categories;
}


/* =====================================================
   SEARCH
===================================================== */

$search = "";

if (isset($_GET['search'])) {

    $search = trim($_GET['search']);

}

$search_safe = mysqli_real_escape_string($conn, $search);


/* =====================================================
   PRODUCT QUERY
===================================================== */

if ($search != "") {

    $query = mysqli_query(
        $conn,
        "SELECT *
         FROM cake
         WHERE stock > 0
         AND status = 'Available'
         AND (
             cake_name LIKE '%$search_safe%'
             OR category LIKE '%$search_safe%'
             OR flavour LIKE '%$search_safe%'
         )
         ORDER BY id DESC"
    );

} else {

    $query = mysqli_query(
        $conn,
        "SELECT *
         FROM cake
         WHERE stock > 0
         AND status = 'Available'
         ORDER BY id DESC"
    );

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Gallery | Swiffin Cake Shop</title>


<!-- BOOTSTRAP -->

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">


<!-- FONT AWESOME -->

<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


<!-- BOOTSTRAP ICONS -->

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
rel="stylesheet">


<!-- GOOGLE FONT -->

<link
href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Oswald:wght@500;600;700&family=Pacifico&display=swap"
rel="stylesheet">


<style>

/* =====================================================
   ROOT
===================================================== */

:root {

    --orange:#E88F2A;
    --orange-dark:#d67d18;
    --black:#111;
    --light:#FAF3EB;

}


/* =====================================================
   BODY
===================================================== */

body {

    margin:0;

    background:#000;

    color:#fff;

    font-family:"Open Sans",Arial,sans-serif;

}


/* =====================================================
   TOPBAR
===================================================== */

.topbar {

    background:#fff !important;

}


.topbar .row {

    min-height:110px;

}


.container-fluid {

    margin-top:0 !important;

}


/* =====================================================
   WELCOME
===================================================== */

.welcome-user {

    display:flex;

    align-items:center;

    gap:10px;

}


.user-icon {

    width:42px;

    height:42px;

    border-radius:50%;

    background:var(--orange);

    color:#fff;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:18px;

    box-shadow:
    0 4px 12px rgba(232,143,42,0.30);

}


.welcome-text {

    display:flex;

    flex-direction:column;

    line-height:1.2;

}


.welcome-text small {

    color:#888;

    font-size:10px;

    text-transform:uppercase;

    letter-spacing:1px;

}


.welcome-text strong {

    color:#222;

    font-size:14px;

    max-width:140px;

    overflow:hidden;

    text-overflow:ellipsis;

    white-space:nowrap;

}


.welcome-guest {

    display:flex;

    align-items:center;

    gap:8px;

    color:#555;

    font-weight:700;

}


.welcome-guest i {

    font-size:28px;

    color:var(--orange);

}


/* =====================================================
   LOGO
===================================================== */

.navbar-brand {

    text-decoration:none !important;

}


.navbar-brand img {

    width:60px;

    height:60px;

    object-fit:contain;

}


.navbar-brand h1 {

    margin:0;

    color:#E88F2A !important;

    font-family:"Oswald",Arial,sans-serif !important;

    font-size:40px !important;

    font-weight:700 !important;

    letter-spacing:.5px;

}


/* =====================================================
   CALL US
===================================================== */

.call-box {

    display:inline-flex;

    align-items:center;

}


.call-icon {

    color:#E88F2A !important;

    font-size:38px;

}


.call-title {

    color:#222 !important;

    font-size:13px !important;

    font-weight:700 !important;

    margin-bottom:3px !important;

}


.call-number {

    color:#222 !important;

    display:block !important;

    font-size:14px !important;

    font-weight:600 !important;

}


/* =====================================================
   NAVBAR
===================================================== */

.navbar {

    background:#fff !important;

}


.navbar .navbar-nav {

    align-items:center;

}


.navbar .nav-link {

    color:#222 !important;

    font-family:"Open Sans",Arial,sans-serif !important;

    font-size:15px !important;

    font-weight:700 !important;

    -webkit-text-stroke:0 !important;

    text-shadow:none !important;

    transition:all .3s ease;

}


.navbar .nav-link:hover {

    color:var(--orange) !important;

}


.navbar .nav-link.active {

    color:var(--orange) !important;

}


.navbar .dropdown-toggle::after {

    vertical-align:middle;

    margin-left:4px;

}


/* =====================================================
   DROPDOWN
===================================================== */

.dropdown-menu {

    min-width:220px;

    border:none;

    border-radius:10px;

    box-shadow:
    0 10px 30px rgba(0,0,0,.15);

}


.dropdown-item {

    padding:10px 15px;

    font-size:14px;

    font-weight:700 !important;

    color:#222 !important;

}


.dropdown-item:hover {

    color:var(--orange) !important;

    background:var(--light);

}


.dropdown-submenu {

    position:relative;

}


.dropdown-submenu > .dropdown-menu {

    top:0;

    left:100%;

    margin-top:0;

    display:none;

}


.dropdown-submenu:hover > .dropdown-menu {

    display:block;

}


/* =====================================================
   CART
===================================================== */

.cart-link {

    display:inline-flex !important;

    align-items:center;

    gap:6px;

    font-weight:700 !important;

}


.cart-link i {

    color:var(--orange);

    font-size:18px;

}


/* =====================================================
   USER DROPDOWN
===================================================== */

.user-dropdown-btn {

    border:none !important;

    background:transparent !important;

    display:flex;

    align-items:center;

    gap:8px;

    color:#222 !important;

    font-family:"Open Sans",Arial,sans-serif !important;

    font-size:14px !important;

    font-weight:700 !important;

    cursor:pointer;

    padding:7px 12px;

    border-radius:25px;

}


.user-dropdown-btn:hover {

    background:var(--light) !important;

    color:var(--orange) !important;

}


.user-dropdown-btn i {

    color:var(--orange) !important;

    font-size:21px;

}


.user-menu {

    min-width:230px;

    padding:10px;

    border:none;

    border-radius:13px;

    box-shadow:
    0 10px 30px rgba(0,0,0,.16);

}


.user-menu .user-info {

    padding:12px;

    border-bottom:1px solid #eee;

    margin-bottom:5px;

}


.user-menu .user-info strong {

    display:block;

    color:#222;

    font-size:15px;

}


.user-menu .user-info small {

    color:#888;

    font-size:11px;

    word-break:break-all;

}


.user-menu .dropdown-item {

    border-radius:8px;

    padding:10px 12px;

}


.user-menu .logout-item {

    color:#dc3545 !important;

}


.user-menu .logout-item:hover {

    background:#fff0f0;

    color:#dc3545 !important;

}


/* =====================================================
   SIGN IN
===================================================== */

.signin-btn {

    display:inline-flex !important;

    align-items:center;

    justify-content:center;

    gap:7px;

    background:var(--orange) !important;

    color:#fff !important;

    border-radius:25px !important;

    padding:9px 18px !important;

    font-size:14px !important;

    font-weight:700 !important;

    border:1px solid var(--orange) !important;

}


.signin-btn:hover {

    background:#fff !important;

    color:var(--orange) !important;

}


/* =====================================================
   REGISTER
===================================================== */

.register-btn {

    display:inline-flex !important;

    align-items:center;

    justify-content:center;

    gap:7px;

    border:1px solid var(--orange) !important;

    color:var(--orange) !important;

    background:#fff !important;

    border-radius:25px !important;

    padding:9px 18px !important;

    font-size:14px !important;

    font-weight:700 !important;

}


.register-btn:hover {

    background:var(--orange) !important;

    color:#fff !important;

}


/* =====================================================
   GALLERY
===================================================== */

.gallery-title {

    padding-top:60px;

    padding-bottom:20px;

}


.gallery-title h5 {

    color:#E88F2A;

    font-weight:700;

    letter-spacing:2px;

}


.gallery-title h1 {

    color:#fff;

    font-weight:700;

    font-size:40px;

}


.gallery-title p {

    color:#aaa;

}


/* =====================================================
   SEARCH
===================================================== */

.search-box {

    width:650px;

    max-width:95%;

    height:55px;

    margin:20px auto 45px;

    display:flex;

    background:#fff;

    border-radius:30px;

    overflow:hidden;

    border:2px solid #ddd;

}


.search-box input {

    flex:1;

    border:none;

    outline:none;

    padding:0 22px;

    font-size:16px;

    color:#222;

}


.search-box button {

    width:65px;

    border:none;

    background:#E88F2A;

    color:#fff;

    font-size:18px;

    cursor:pointer;

}


.search-box button:hover {

    background:#d67d18;

}


/* =====================================================
   PRODUCT CARD
===================================================== */

.product-card {

    background:#111;

    border:2px solid #333;

    border-radius:15px;

    overflow:hidden;

    transition:all .3s ease;

    height:100%;

}


.product-card:hover {

    border-color:#E88F2A;

    box-shadow:
    0 0 20px rgba(232,143,42,.6);

    transform:translateY(-5px);

}


.product-card img {

    width:100%;

    height:230px;

    object-fit:cover;

    display:block;

}


.product-card-body {

    padding:20px;

    text-align:center;

}


.product-card h5 {

    color:#fff;

    font-weight:700;

    margin-bottom:8px;

}


.category {

    color:#aaa;

    margin-bottom:8px;

}


.details {

    color:#ccc;

    font-size:14px;

    margin-bottom:5px;

}


.price {

    color:#E88F2A;

    font-size:20px;

    font-weight:700;

    margin-top:10px;

}


/* =====================================================
   RATING
===================================================== */

.product-rating {

    margin-top:10px;

    margin-bottom:15px;

    font-size:14px;

}


.star {

    color:#E88F2A;

    font-size:17px;

}


.star.empty {

    color:#555;

}


.rating-number {

    color:#fff;

    font-weight:700;

    margin-left:5px;

}


.review-count {

    color:#999;

    margin-left:3px;

}


/* =====================================================
   VIEW BUTTON
===================================================== */

.view-product-btn {

    display:inline-block;

    padding:10px 25px;

    background:#E88F2A;

    color:#fff;

    border-radius:25px;

    text-decoration:none;

    font-weight:900;

    transition:.3s;

}


.view-product-btn:hover {

    background:#fff;

    color:#000;

    transform:translateY(-2px);

}


/* =====================================================
   NO PRODUCT
===================================================== */

.no-product {

    text-align:center;

    padding:70px 20px;

}


.no-product i {

    color:#E88F2A;

    font-size:50px;

    margin-bottom:20px;

}


.no-product h4 {

    color:#fff;

}


.no-product p {

    color:#999;

}


/* =====================================================
   MOBILE
===================================================== */

@media(max-width:991px) {

    .navbar-brand h1 {

        font-size:32px !important;

    }

    .dropdown-submenu > .dropdown-menu {

        position:static;

        margin-left:15px;

        box-shadow:none;

    }

}


@media(max-width:768px) {

    .gallery-title h1 {

        font-size:30px;

    }

    .product-card img {

        height:220px;

    }

    .navbar-brand h1 {

        font-size:28px !important;

    }

    .topbar .row {

        min-height:auto;

    }

}

</style>

</head>


<body>


<!-- =====================================================
     TOPBAR START
===================================================== -->

<div class="container-fluid px-5 topbar">

    <div class="row align-items-center">


        <!-- WELCOME -->

        <div class="col-lg-3">

            <?php if ($customer_logged_in) { ?>

                <div class="welcome-user">

                    <div class="user-icon">

                        <i class="fas fa-user"></i>

                    </div>

                    <div class="welcome-text">

                        <small>
                            Welcome
                        </small>

                        <strong>

                            <?php
                            echo htmlspecialchars(
                                $customer_name
                            );
                            ?>

                        </strong>

                    </div>

                </div>

            <?php } else { ?>

                <div class="welcome-guest">

                    <i class="fas fa-user-circle"></i>

                    <span>
                        Welcome Guest
                    </span>

                </div>

            <?php } ?>

        </div>


        <!-- LOGO -->

        <div class="col-lg-5 text-center py-2">

            <a
                href="index1.php"
                class="navbar-brand d-flex justify-content-center align-items-center"
            >

                <img
                    src="img/logo.png"
                    alt="SWIFFIN Logo"
                    width="60"
                    height="60"
                >

                <h1 class="m-0 ms-2 text-uppercase">

                    SWIFFIN

                </h1>

            </a>

        </div>


        <!-- CALL -->

        <div class="col-lg-4 text-end pe-4">

            <div class="call-box">

                <i
                    class="bi bi-phone-vibrate call-icon me-3"
                ></i>

                <div class="text-start">

                    <h6 class="text-uppercase call-title">
                        CALL US
                    </h6>

                    <span class="call-number">
                        +91 9876543210
                    </span>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =====================================================
     TOPBAR END
===================================================== -->


<!-- =====================================================
     NAVBAR START
===================================================== -->

<nav
    class="navbar navbar-expand-lg bg-white navbar-light shadow-sm sticky-top py-3"
>

    <div class="container">


        <!-- MOBILE BUTTON -->

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbar"
            aria-controls="navbar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >

            <span class="navbar-toggler-icon"></span>

        </button>


        <!-- NAVBAR -->

        <div
            class="collapse navbar-collapse"
            id="navbar"
        >

            <ul class="navbar-nav ms-auto align-items-center">


                <!-- HOME -->

                <li class="nav-item">

                    <a
                        href="index1.php"
                        class="nav-link"
                    >
                        Home
                    </a>

                </li>


                <!-- ABOUT -->

                <li class="nav-item">

                    <a
                        href="about.php"
                        class="nav-link"
                    >
                        About
                    </a>

                </li>


                <!-- CAKES -->

                <li class="nav-item dropdown">

                    <div class="d-flex align-items-center">

                        <a
                            href="product.php"
                            class="nav-link"
                            style="padding-right:2px;"
                        >
                            Cakes
                        </a>


                        <a
                            href="#"
                            class="nav-link dropdown-toggle"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            style="padding-left:2px;"
                        ></a>


                        <ul class="dropdown-menu">

                            <?php foreach (
                                $parent_categories
                                as $parent
                            ) { ?>

                                <?php

                                $parent_id =
                                    intval(
                                        $parent['id']
                                    );

                                $sub_categories =
                                    getSubCategoriesGallery(
                                        $conn,
                                        $parent_id
                                    );

                                ?>


                                <?php if (
                                    count($sub_categories) > 0
                                ) { ?>

                                    <li
                                        class="dropdown-submenu"
                                    >

                                        <a
                                            href="product.php?category=<?php echo $parent_id; ?>"
                                            class="dropdown-item dropdown-toggle"
                                        >

                                            <?php

                                            echo htmlspecialchars(
                                                $parent[
                                                    'category_name'
                                                ]
                                            );

                                            ?>

                                        </a>


                                        <ul class="dropdown-menu">

                                            <?php foreach (
                                                $sub_categories
                                                as $sub
                                            ) { ?>

                                                <li>

                                                    <a
                                                        href="product.php?category=<?php echo intval($sub['id']); ?>"
                                                        class="dropdown-item"
                                                    >

                                                        <?php

                                                        echo htmlspecialchars(
                                                            $sub[
                                                                'category_name'
                                                            ]
                                                        );

                                                        ?>

                                                    </a>

                                                </li>

                                            <?php } ?>

                                        </ul>

                                    </li>


                                <?php } else { ?>


                                    <li>

                                        <a
                                            href="product.php?category=<?php echo $parent_id; ?>"
                                            class="dropdown-item"
                                        >

                                            <?php

                                            echo htmlspecialchars(
                                                $parent[
                                                    'category_name'
                                                ]
                                            );

                                            ?>

                                        </a>

                                    </li>


                                <?php } ?>


                            <?php } ?>

                        </ul>

                    </div>

                </li>


                <!-- GALLERY -->

                <li class="nav-item">

                    <a
                        href="gallery.php"
                        class="nav-link active"
                    >
                        Gallery
                    </a>

                </li>


                <!-- CONTACT -->

                <li class="nav-item">

                    <a
                        href="contact.php"
                        class="nav-link"
                    >
                        Contact
                    </a>

                </li>


                <!-- CART -->

                <?php if ($customer_logged_in) { ?>

                    <li class="nav-item">

                        <a
                            href="carts.php"
                            class="nav-link cart-link"
                        >

                            <i class="fas fa-shopping-cart"></i>

                            Cart

                        </a>

                    </li>

                <?php } ?>


                <!-- LOGGED IN USER -->

                <?php if ($customer_logged_in) { ?>

                    <li class="nav-item dropdown ms-2">

                        <button
                            class="user-dropdown-btn dropdown-toggle"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                        >

                            <i class="fas fa-user-circle"></i>

                            <span>

                                <?php

                                echo htmlspecialchars(
                                    $customer_name
                                );

                                ?>

                            </span>

                        </button>


                        <ul
                            class="dropdown-menu dropdown-menu-end user-menu"
                        >

                            <li>

                                <div class="user-info">

                                    <strong>

                                        <?php

                                        echo htmlspecialchars(
                                            $customer_name
                                        );

                                        ?>

                                    </strong>


                                    <small>

                                        <?php

                                        echo htmlspecialchars(
                                            $customer_email
                                        );

                                        ?>

                                    </small>

                                </div>

                            </li>


                            <li>

                                <a
                                    href="#"
                                    class="dropdown-item"
                                >

                                    <i
                                        class="fas fa-user me-2"
                                    ></i>

                                    My Profile

                                </a>

                            </li>


                            <li>

                                <a
                                    href="carts.php"
                                    class="dropdown-item"
                                >

                                    <i
                                        class="fas fa-shopping-cart me-2"
                                    ></i>

                                    My Cart

                                </a>

                            </li>


                            <li>

                                <hr class="dropdown-divider">

                            </li>


                            <li>

                                <a
                                    href="logout.php"
                                    class="dropdown-item logout-item"
                                >

                                    <i
                                        class="fas fa-sign-out-alt me-2"
                                    ></i>

                                    Sign Out

                                </a>

                            </li>

                        </ul>

                    </li>


                <?php } else { ?>


                    <!-- SIGN IN -->

                    <li class="nav-item ms-2">

                        <a
                            href="login.php"
                            class="btn signin-btn"
                        >

                            <i class="fas fa-sign-in-alt"></i>

                            Sign In

                        </a>

                    </li>


                    <!-- REGISTER -->

                    <li class="nav-item ms-2">

                        <a
                            href="register.php"
                            class="btn register-btn"
                        >

                            <i class="fas fa-user-plus"></i>

                            Register

                        </a>

                    </li>


                <?php } ?>


            </ul>

        </div>

    </div>

</nav>


<!-- =====================================================
     NAVBAR END
===================================================== -->


<!-- =====================================================
     GALLERY HEADING
===================================================== -->

<section class="gallery-title">

    <div class="container text-center">

        <h5>
            OUR GALLERY
        </h5>

        <h1>
            Our Delicious Cakes
        </h1>

        <p>
            Explore our freshly baked cakes collection.
        </p>


        <!-- SEARCH -->

        <form
            method="GET"
            action="gallery.php"
        >

            <div class="search-box">

                <input
                    type="text"
                    name="search"
                    placeholder="Search your favourite cake..."
                    value="<?php
                    echo htmlspecialchars($search);
                    ?>"
                >

                <button type="submit">

                    <i class="fa fa-search"></i>

                </button>

            </div>

        </form>

    </div>

</section>


<!-- =====================================================
     PRODUCTS
===================================================== -->

<section class="pb-5">

    <div class="container">

        <div class="row g-4">


            <?php if (!$query) { ?>


                <div class="col-12 no-product">

                    <i
                        class="fa-solid fa-triangle-exclamation"
                    ></i>

                    <h4>
                        Database Error
                    </h4>

                    <p>

                        <?php
                        echo mysqli_error($conn);
                        ?>

                    </p>

                </div>


            <?php

            } elseif (
                mysqli_num_rows($query) > 0
            ) {

                while (
                    $product =
                    mysqli_fetch_assoc($query)
                ) {


                    /* ================= FEEDBACK ================= */

                    $cake_name =
                        $product['cake_name'];

                    $cake_name_safe =
                        mysqli_real_escape_string(
                            $conn,
                            $cake_name
                        );


                    $feedback_query =
                        mysqli_query(
                            $conn,
                            "SELECT
                                AVG(rating) AS avg_rating,
                                COUNT(*) AS total_reviews
                             FROM feedback
                             WHERE cake_name='$cake_name_safe'"
                        );


                    $feedback_data =
                        mysqli_fetch_assoc(
                            $feedback_query
                        );


                    $avg_rating =
                        !empty(
                            $feedback_data[
                                'avg_rating'
                            ]
                        )
                        ? round(
                            $feedback_data[
                                'avg_rating'
                            ],
                            1
                        )
                        : 0;


                    $total_reviews =
                        $feedback_data[
                            'total_reviews'
                        ] ?? 0;

            ?>


                <!-- CAKE CARD -->

                <div
                    class="col-lg-3 col-md-6 col-sm-12"
                >

                    <div class="product-card">


                        <!-- IMAGE -->

                        <img
                            src="img/<?php
                            echo htmlspecialchars(
                                $product['image']
                            );
                            ?>"
                            alt="<?php
                            echo htmlspecialchars(
                                $product['cake_name']
                            );
                            ?>"
                        >


                        <!-- BODY -->

                        <div class="product-card-body">


                            <!-- NAME -->

                            <h5>

                                <?php

                                echo htmlspecialchars(
                                    $product[
                                        'cake_name'
                                    ]
                                );

                                ?>

                            </h5>


                            <!-- CATEGORY -->

                            <div class="category">

                                <?php

                                echo htmlspecialchars(
                                    $product[
                                        'category'
                                    ]
                                );

                                ?>

                            </div>


                            <!-- FLAVOUR -->

                            <div class="details">

                                <strong>
                                    Flavour:
                                </strong>

                                <?php

                                echo htmlspecialchars(
                                    $product[
                                        'flavour'
                                    ]
                                );

                                ?>

                            </div>


                            <!-- WEIGHT -->

                            <div class="details">

                                <strong>
                                    Weight:
                                </strong>

                                <?php

                                echo htmlspecialchars(
                                    $product[
                                        'weight'
                                    ]
                                );

                                ?>

                            </div>


                            <!-- PRICE -->

                            <div class="price">

                                ₹<?php

                                echo number_format(
                                    $product[
                                        'price'
                                    ],
                                    2
                                );

                                ?>

                            </div>


                            <!-- RATING -->

                            <div class="product-rating">

                                <?php

                                for (
                                    $i = 1;
                                    $i <= 5;
                                    $i++
                                ) {

                                    if (
                                        $i <=
                                        round(
                                            $avg_rating
                                        )
                                    ) {

                                ?>

                                    <span
                                        class="star"
                                    >
                                        ★
                                    </span>

                                <?php

                                    } else {

                                ?>

                                    <span
                                        class="star empty"
                                    >
                                        ★
                                    </span>

                                <?php

                                    }

                                }

                                ?>


                                <?php if (
                                    $total_reviews > 0
                                ) { ?>

                                    <span
                                        class="rating-number"
                                    >

                                        <?php
                                        echo $avg_rating;
                                        ?>

                                    </span>

                                    <span
                                        class="review-count"
                                    >

                                        (<?php
                                        echo $total_reviews;
                                        ?>
                                        Reviews)

                                    </span>

                                <?php } else { ?>

                                    <span
                                        class="review-count"
                                    >
                                        No Reviews
                                    </span>

                                <?php } ?>

                            </div>


                            <!-- VIEW PRODUCT -->

                            <a
                                href="product.php?id=<?php
                                echo $product['id'];
                                ?>"
                                class="view-product-btn"
                            >

                                View Product

                            </a>


                        </div>

                    </div>

                </div>


            <?php

                }

            } else {

            ?>


                <!-- NO CAKE -->

                <div class="col-12 no-product">

                    <i
                        class="fa-solid fa-cake-candles"
                    ></i>

                    <h4>
                        No Cakes Found
                    </h4>

                    <p>
                        Try searching for another cake.
                    </p>

                </div>


            <?php } ?>


        </div>

    </div>

</section>


<!-- =====================================================
     JAVASCRIPT
===================================================== -->

<script
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>


</body>

</html>