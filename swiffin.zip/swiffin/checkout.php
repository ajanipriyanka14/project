<?php

session_start();
include "config.php";

/* ================= CHECK CART ID ================= */

if (!isset($_GET['cart_id'])) {
    die("Cart ID Not Found");
}

$cart_id = intval($_GET['cart_id']);

if ($cart_id <= 0) {
    die("Invalid Cart ID");
}


/* ================= GET CART DATA ================= */

$query = mysqli_query(
    $conn,
    "SELECT * FROM carts WHERE id='$cart_id' LIMIT 1"
);

if (!$query) {
    die("Database Error: " . mysqli_error($conn));
}

if (mysqli_num_rows($query) == 0) {
    die("Cart Record Not Found");
}

$cart = mysqli_fetch_assoc($query);


/* ================= CART DETAILS ================= */

$customer_name = $cart['customer_name'];
$email         = $cart['email'];
$mobile        = $cart['mobile'];
$address       = $cart['address'];

$cake_name     = $cart['cake_name'];
$quantity      = $cart['quantity'];
$price         = $cart['price'];
$total         = $cart['total'];


/* ================= GET CAKE DETAILS ================= */

$cake_name_safe = mysqli_real_escape_string(
    $conn,
    $cake_name
);

$cake_query = mysqli_query(
    $conn,
    "SELECT * FROM cake
     WHERE cake_name='$cake_name_safe'
     LIMIT 1"
);

$image    = "";
$category = "";
$flavour  = "";
$weight   = "";

if ($cake_query && mysqli_num_rows($cake_query) > 0) {

    $cake = mysqli_fetch_assoc($cake_query);

    $image    = $cake['image'];
    $category = $cake['category'];
    $flavour  = $cake['flavour'];
    $weight   = $cake['weight'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Checkout | Swiffin Cake Shop</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
rel="stylesheet">


<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    padding:0;
    background:#000;
    color:#fff;
    font-family:Arial,sans-serif;
}


/* HEADER */

.checkout-header{
    text-align:center;
    padding:40px 15px 20px;
}

.checkout-header h1{
    color:#E88F2A;
    font-size:38px;
    font-weight:bold;
}

.checkout-header p{
    color:#aaa;
}


/* CONTAINER */

.checkout-container{
    width:92%;
    max-width:1100px;
    margin:20px auto 60px;
}


/* BOX */

.checkout-box{
    background:#111;
    border:1px solid #E88F2A;
    border-radius:20px;
    padding:30px;

    box-shadow:
    0 0 25px rgba(232,143,42,.30);
}


/* SECTION TITLE */

.section-title{
    color:#E88F2A;
    font-size:23px;
    font-weight:bold;
    margin-bottom:20px;
}


/* CAKE IMAGE */

.cake-image{
    width:100%;
    height:330px;
    object-fit:cover;
    border-radius:15px;
    border:2px solid #E88F2A;
}


/* CAKE NAME */

.cake-name{
    color:#E88F2A;
    font-size:28px;
    font-weight:bold;
    margin:20px 0;
}


/* DETAILS */

.detail{
    background:#1b1b1b;
    border:1px solid #333;
    border-radius:10px;
    padding:13px 15px;
    margin-bottom:10px;
}

.detail span{
    display:block;
    color:#aaa;
    font-size:13px;
    margin-bottom:4px;
}

.detail strong{
    color:#fff;
    font-size:16px;
}


/* PRICE */

.price{
    color:#E88F2A !important;
    font-size:22px !important;
    font-weight:bold;
}


/* CUSTOMER BOX */

.customer-box{
    background:#1b1b1b;
    border:1px solid #333;
    border-radius:15px;
    padding:20px;
}


/* CUSTOMER DETAIL */

.customer-detail{
    margin-bottom:18px;
}

.customer-detail label{
    display:block;
    color:#E88F2A;
    font-weight:bold;
    margin-bottom:7px;
}

.customer-detail .value{
    background:#080808;
    border:1px solid #444;
    border-radius:8px;
    padding:12px;
    color:#fff;
    min-height:45px;
}


/* PAYMENT BUTTON */

.payment-btn{
    width:100%;
    background:#E88F2A;
    color:#fff;
    border:none;
    padding:15px;
    border-radius:30px;
    font-size:18px;
    font-weight:bold;
    margin-top:20px;
}

.payment-btn:hover{
    background:#d67d18;
}


/* BACK */

.back-link{
    display:block;
    text-align:center;
    margin-top:20px;
    color:#E88F2A;
    text-decoration:none;
    font-weight:bold;
}

.back-link:hover{
    color:#fff;
}


/* MOBILE */

@media(max-width:768px){

    .checkout-box{
        padding:20px;
    }

    .checkout-header h1{
        font-size:30px;
    }

    .cake-image{
        height:280px;
    }

}

</style>

</head>


<body>


<!-- HEADER -->

<div class="checkout-header">

<h1>

<i class="fas fa-shopping-bag"></i>

Checkout

</h1>

<p>
Review your order and customer details
</p>

</div>



<!-- MAIN -->

<div class="checkout-container">

<div class="checkout-box">

<div class="row g-4">


<!-- ================= CAKE ================= -->

<div class="col-lg-5">

<div class="section-title">

<i class="fas fa-cake-candles"></i>

Your Cake

</div>


<?php if (!empty($image)) { ?>

<img
src="img/<?php echo htmlspecialchars($image); ?>"
class="cake-image"
alt="Cake"
>

<?php } else { ?>

<div
style="
height:330px;
border:2px solid #E88F2A;
border-radius:15px;
display:flex;
align-items:center;
justify-content:center;
color:#888;
"
>

<i class="fas fa-cake-candles fa-4x"></i>

</div>

<?php } ?>


<div class="cake-name">

<?php echo htmlspecialchars($cake_name); ?>

</div>


<div class="detail">

<span>Category</span>

<strong>
<?php echo htmlspecialchars($category); ?>
</strong>

</div>


<div class="detail">

<span>Flavour</span>

<strong>
<?php echo htmlspecialchars($flavour); ?>
</strong>

</div>


<div class="detail">

<span>Weight</span>

<strong>
<?php echo htmlspecialchars($weight); ?>
</strong>

</div>


<div class="detail">

<span>Quantity</span>

<strong>
<?php echo htmlspecialchars($quantity); ?>
</strong>

</div>


<div class="detail">

<span>Price</span>

<strong class="price">

₹<?php echo number_format($price,2); ?>

</strong>

</div>


<div class="detail">

<span>Total Amount</span>

<strong class="price">

₹<?php echo number_format($total,2); ?>

</strong>

</div>

</div>



<!-- ================= CUSTOMER ================= -->

<div class="col-lg-7">

<div class="section-title">

<i class="fas fa-user"></i>

Customer Details

</div>


<div class="customer-box">


<!-- NAME -->

<div class="customer-detail">

<label>

<i class="fas fa-user"></i>
Customer Name

</label>

<div class="value">

<?php

echo htmlspecialchars($customer_name);

?>

</div>

</div>


<!-- EMAIL -->

<div class="customer-detail">

<label>

<i class="fas fa-envelope"></i>
Email

</label>

<div class="value">

<?php

echo htmlspecialchars($email);

?>

</div>

</div>


<!-- MOBILE -->

<div class="customer-detail">

<label>

<i class="fas fa-phone"></i>
Mobile Number

</label>

<div class="value">

<?php

echo htmlspecialchars($mobile);

?>

</div>

</div>


<!-- ADDRESS -->

<div class="customer-detail">

<label>

<i class="fas fa-location-dot"></i>
Delivery Address

</label>

<div class="value">

<?php

echo nl2br(
    htmlspecialchars($address)
);

?>

</div>

</div>


<!-- TOTAL -->

<div class="detail">

<span>Order Total</span>

<strong class="price">

₹<?php echo number_format($total,2); ?>

</strong>

</div>


<!-- PAYMENT -->

<a
href="payment.php?cart_id=<?php echo $cart_id; ?>"
class="payment-btn"
style="
display:block;
text-align:center;
text-decoration:none;
"
>

<i class="fas fa-credit-card"></i>

Proceed To Payment

</a>


</div>


<a
href="carts.php?id=<?php echo $cart_id; ?>"
class="back-link"
>

<i class="fas fa-arrow-left"></i>

Back To Cart

</a>


</div>

</div>

</div>

</div>


</body>

</html>